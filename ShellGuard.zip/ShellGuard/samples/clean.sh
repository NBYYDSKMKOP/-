#!/system/bin/sh
# 一个正常的备份脚本
set -e
echo "backup start"

mkdir -p /sdcard/backup
cp -r /data/local/tmp/myapp /sdcard/backup/
rm -rf /data/local/tmp/build
rm -f /tmp/old.log
tar -czf /sdcard/backup/app.tar.gz /data/local/tmp/myapp

echo "backup done"
