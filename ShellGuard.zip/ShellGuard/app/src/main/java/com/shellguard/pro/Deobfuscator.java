package com.shellguard.pro;

import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;

/**
 * 反混淆 / 解密 dump。
 * 只做"还原",不对还原出来的内容做任何执行。
 */
public final class Deobfuscator {

    public static class Decoded {
        public final int layer;
        public final String kind;
        public final String source;
        public final String value;

        public Decoded(int layer, String kind, String source, String value) {
            this.layer = layer;
            this.kind = kind;
            this.source = source;
            this.value = value;
        }
    }

    private static final int MAX_LAYERS = 3;
    private static final int MAX_BLOBS = 40;
    private static final int MAX_VALUE_CHARS = 6000;
    private static final int MAX_INPUT = 600_000;

    private static final Pattern B64 = Pattern.compile("[A-Za-z0-9+/]{16,}={0,2}");
    private static final Pattern B64URL = Pattern.compile("[A-Za-z0-9_\\-]{24,}");
    private static final Pattern HEXRUN = Pattern.compile("(?<![0-9a-fA-Fx\\\\])(?:[0-9a-fA-F]{2}){8,}(?![0-9a-fA-F])");
    private static final Pattern ESC = Pattern.compile("(?:\\\\x[0-9a-fA-F]{2}){4,}");

    private Deobfuscator() {}

    public static List<Decoded> run(String content) {
        List<Decoded> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String src = content.length() > MAX_INPUT ? content.substring(0, MAX_INPUT) : content;
        harvest(src, 1, out, seen);
        return out;
    }

    private static void harvest(String text, int layer, List<Decoded> out, Set<String> seen) {
        if (layer > MAX_LAYERS || out.size() >= MAX_BLOBS) return;

        List<String[]> candidates = new ArrayList<>();   // {kind, raw}
        collect(B64, text, "Base64", candidates, 260);
        collect(B64URL, text, "Base64(URL安全)", candidates, 260);
        collect(ESC, text, "转义序列", candidates, 120);

        // 纯十六进制段(需长度适中,避免误吃普通文本)
        Matcher mh = HEXRUN.matcher(text);
        int hexGuard = 0;
        while (mh.find() && hexGuard++ < 60) {
            String s = mh.group();
            if (s.length() >= 32 && s.length() <= 20000) {
                candidates.add(new String[]{"十六进制", s});
            }
        }

        for (String[] c : candidates) {
            if (out.size() >= MAX_BLOBS) break;
            String kind = c[0];
            String raw = c[1];
            byte[] bytes = decodeBytes(kind, raw);
            if (bytes == null || bytes.length == 0) continue;

            boolean packed = false;
            if (bytes.length > 2 && (bytes[0] & 0xFF) == 0x1F && (bytes[1] & 0xFF) == 0x8B) {
                byte[] un = gunzip(bytes);
                if (un != null) { bytes = un; packed = true; }
            } else if (bytes.length > 2 && (bytes[0] & 0xFF) == 0x78) {
                byte[] un = inflate(bytes);
                if (un != null) { bytes = un; packed = true; }
            }

            if (!isMostlyText(bytes)) continue;

            String value = new String(bytes, Charset.forName("UTF-8"));
            String trimmed = value.length() > MAX_VALUE_CHARS ? value.substring(0, MAX_VALUE_CHARS) + "\n…(已截断)" : value;
            String key = stripped(trimmed);
            if (key.length() < 4 || seen.contains(key)) continue;
            seen.add(key);

            String label = packed ? kind + " + 解压" : kind;
            out.add(new Decoded(layer, label, brief(raw), trimmed));

            if (layer < MAX_LAYERS && looksObfuscated(trimmed)) {
                harvest(trimmed, layer + 1, out, seen);
            }
        }
    }

    private static void collect(Pattern p, String text, String kind, List<String[]> sink, int max) {
        Matcher m = p.matcher(text);
        int n = 0;
        while (m.find() && n++ < max) {
            String s = m.group();
            if (s.length() >= 16) sink.add(new String[]{kind, s});
        }
    }

    private static byte[] decodeBytes(String kind, String raw) {
        try {
            if (kind.startsWith("Base64")) {
                try {
                    return Base64.decode(raw, Base64.DEFAULT);
                } catch (Exception e1) {
                    try {
                        return Base64.decode(raw, Base64.URL_SAFE | Base64.NO_WRAP);
                    } catch (Exception e2) {
                        return null;
                    }
                }
            }
            if ("转义序列".equals(kind)) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                Matcher m = Pattern.compile("\\\\x([0-9a-fA-F]{2})").matcher(raw);
                while (m.find()) bos.write(Integer.parseInt(m.group(1), 16));
                return bos.toByteArray();
            }
            if ("十六进制".equals(kind)) {
                if (raw.length() % 2 != 0) raw = raw.substring(0, raw.length() - 1);
                byte[] b = new byte[raw.length() / 2];
                for (int i = 0; i < b.length; i++) {
                    b[i] = (byte) Integer.parseInt(raw.substring(i * 2, i * 2 + 2), 16);
                }
                return b;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static byte[] gunzip(byte[] in) {
        try (GZIPInputStream gz = new GZIPInputStream(new ByteArrayInputStream(in))) {
            return readAll(gz, 400_000);
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] inflate(byte[] in) {
        try (InflaterInputStream is = new InflaterInputStream(new ByteArrayInputStream(in))) {
            return readAll(is, 400_000);
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] readAll(java.io.InputStream is, int cap) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n, total = 0;
        while ((n = is.read(buf)) > 0) {
            total += n;
            if (total > cap) break;
            bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }

    private static boolean isMostlyText(byte[] b) {
        if (b.length < 4) return false;
        String s;
        try {
            java.nio.charset.CharsetDecoder dec = Charset.forName("UTF-8").newDecoder()
                    .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                    .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT);
            s = dec.decode(java.nio.ByteBuffer.wrap(b)).toString();
        } catch (Exception e) {
            return false;
        }
        if (s.isEmpty()) return false;
        int good = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\n' || c == '\r' || c == '\t') { good++; continue; }
            if (c >= 32 && c < 127) { good++; continue; }
            if (c >= 0x2E80) { good++; continue; }   // CJK / 假名 / 符号区
        }
        return good * 100 / s.length() >= 85;
    }

    private static boolean looksObfuscated(String s) {
        String t = s.trim();
        if (t.length() < 24) return false;
        return t.contains("base64") || t.contains("eval") || t.contains("\\x")
                || t.contains("rm ") || t.contains("sh") || t.contains("http");
    }

    private static String brief(String raw) {
        String s = raw.replaceAll("\\s+", " ").trim();
        if (s.length() > 90) s = s.substring(0, 90) + "…";
        return s;
    }

    private static String stripped(String s) {
        return s.replaceAll("\\s+", "").trim();
    }
}
