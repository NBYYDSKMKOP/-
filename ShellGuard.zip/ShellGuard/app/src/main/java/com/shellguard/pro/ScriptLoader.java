package com.shellguard.pro;

import android.content.Context;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;

/** 读取脚本内容:本地文件 或 网络直链。只读取文本,不执行。 */
public final class ScriptLoader {

    private static final int MAX_BYTES = 6 * 1024 * 1024;

    public static class Loaded {
        public final String name;
        public final String content;
        public final int bytes;
        public final boolean truncated;
        public final String source;

        Loaded(String name, String content, int bytes, boolean truncated, String source) {
            this.name = name;
            this.content = content;
            this.bytes = bytes;
            this.truncated = truncated;
            this.source = source;
        }
    }

    private ScriptLoader() {}

    public static Loaded fromUri(Context ctx, Uri uri) throws Exception {
        String name = queryName(ctx, uri);
        InputStream in = ctx.getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("无法打开该文件");
        try {
            byte[] data = readAll(in);
            boolean cut = data.length >= MAX_BYTES;
            return new Loaded(name, decode(data), data.length, cut, "本地文件");
        } finally {
            try { in.close(); } catch (Exception ignored) {}
        }
    }

    public static Loaded fromUrl(String raw) throws Exception {
        String url = raw.trim();
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://" + url;
        }
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) ShellGuard/1.0");
            conn.setRequestProperty("Accept", "*/*");
            int code = conn.getResponseCode();
            if (code >= 400) throw new Exception("目标返回 HTTP " + code);
            byte[] data = readAll(conn.getInputStream());
            boolean cut = data.length >= MAX_BYTES;
            return new Loaded(guessName(url), decode(data), data.length, cut, "网络直链");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n, total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > MAX_BYTES) {
                bos.write(buf, 0, n - (total - MAX_BYTES));
                break;
            }
            bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }

    /** UTF-8 严格解码失败则退到 GBK,再退 ISO-8859-1,尽量不丢字符 */
    private static String decode(byte[] data) {
        int off = 0;
        if (data.length >= 3 && (data[0] & 0xFF) == 0xEF && (data[1] & 0xFF) == 0xBB
                && (data[2] & 0xFF) == 0xBF) {
            off = 3;
        }
        String s = strictDecode(data, off, "UTF-8");
        if (s != null) return s;
        s = strictDecode(data, off, "GBK");
        if (s != null) return s;
        return new String(data, off, data.length - off, Charset.forName("ISO-8859-1"));
    }

    private static String strictDecode(byte[] data, int off, String charset) {
        try {
            CharsetDecoder dec = Charset.forName(charset).newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT);
            return dec.decode(ByteBuffer.wrap(data, off, data.length - off)).toString();
        } catch (CharacterCodingException e) {
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private static String queryName(Context ctx, Uri uri) {
        String name = null;
        try {
            android.database.Cursor c = ctx.getContentResolver()
                    .query(uri, null, null, null, null);
            if (c != null) {
                try {
                    int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (c.moveToFirst() && idx >= 0) name = c.getString(idx);
                } finally {
                    c.close();
                }
            }
        } catch (Exception ignored) {}
        if (name == null) {
            String last = uri.getLastPathSegment();
            name = last == null ? "所选脚本" : last;
        }
        return name;
    }

    private static String guessName(String url) {
        try {
            String p = url.split("\\?")[0];
            int i = p.lastIndexOf('/');
            String n = i >= 0 ? p.substring(i + 1) : p;
            return n.isEmpty() ? "远程脚本" : n;
        } catch (Exception e) {
            return "远程脚本";
        }
    }
}
