package com.shellguard.pro;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_PICK = 2001;
    private static final String QQ_UIN = "1406238884";
    private static final String GROUP_CODE = "1097504005";
    private static final String GROUP_URL =
            "https://qun.qq.com/universal-share/share?ac=1&authKey=62pbNm1ujA7GNx1LG2I9cWTROflD72RKdNuGtazUqo6UtepJ0c9zOTgY2Uv1zluT"
            + "&busi_data=eyJncm91cENvZGUiOiIxMDk3NTA0MDA1IiwidG9rZW4iOiJUcVkxNlBCZVZ0Z0RpRitLcGFpeEltMmcyV3Q1M0xXd0lXSUQwR2h0QmY0clhjbzVpVjc5OVZ1OUl4Rk8rREFsIiwidWluIjoiMTQwNjIzODg4NCJ9"
            + "&data=hDCuTgWBAmjgUket0IggOFAclrXvTgjQTDGrTOZctyeLVc9UtBJyKBSU4zXNdGzz4thhbU6QPO_QV_Ip05nooA&svctype=4&tempid=h5_group_info";

    private ScrollPage pageHome, pageOther;
    private TextView navHome, navOther;
    private TextView btnPick, tvFileName, btnScan, btnCopy;
    private EditText etPaste, etUrl;
    private LinearLayout cardResult, cardFindings, cardDump, llFindings, llDump;
    private View cardPhoto, cardContact, cardNote, vRing, vHalo;
    private TextView tvHeadline, tvSubline, tvMeta, tvRisk, tvFindingsCount, tvDumpHint;
    private ImageView ivShield, ivPhoto;
    private ProgressBar pbScan;

    private Uri pickedUri;
    private String pickedName;
    private ScanEngine.Result lastResult;
    private String lastFileName = "未命名";
    private boolean scanning = false;
    private ObjectAnimator haloAnim;

    /** 简易结构:ScrollView + 它的内容根 */
    private static class ScrollPage {
        final View root;
        final View content;
        ScrollPage(View root, View content) { this.root = root; this.content = content; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pageHome = new ScrollPage(findViewById(R.id.pageHome), null);
        pageOther = new ScrollPage(findViewById(R.id.pageOther), null);

        navHome = findViewById(R.id.navHome);
        navOther = findViewById(R.id.navOther);
        btnPick = findViewById(R.id.btnPick);
        tvFileName = findViewById(R.id.tvFileName);
        btnScan = findViewById(R.id.btnScan);
        btnCopy = findViewById(R.id.btnCopy);
        etPaste = findViewById(R.id.etPaste);
        etUrl = findViewById(R.id.etUrl);
        cardResult = findViewById(R.id.cardResult);
        cardFindings = findViewById(R.id.cardFindings);
        cardDump = findViewById(R.id.cardDump);
        llFindings = findViewById(R.id.llFindings);
        llDump = findViewById(R.id.llDump);
        cardPhoto = findViewById(R.id.cardPhoto);
        cardContact = findViewById(R.id.cardContact);
        cardNote = findViewById(R.id.cardNote);
        vRing = findViewById(R.id.vRing);
        vHalo = findViewById(R.id.vHalo);
        tvHeadline = findViewById(R.id.tvHeadline);
        tvSubline = findViewById(R.id.tvSubline);
        tvMeta = findViewById(R.id.tvMeta);
        tvRisk = findViewById(R.id.tvRisk);
        tvFindingsCount = findViewById(R.id.tvFindingsCount);
        tvDumpHint = findViewById(R.id.tvDumpHint);
        ivShield = findViewById(R.id.ivShield);
        ivPhoto = findViewById(R.id.ivPhoto);
        pbScan = findViewById(R.id.pbScan);

        btnPick.setOnClickListener(v -> pickFile());
        btnScan.setOnClickListener(v -> startScan());
        btnCopy.setOnClickListener(v -> copyReport());
        navHome.setOnClickListener(v -> switchPage(true));
        navOther.setOnClickListener(v -> switchPage(false));
        findViewById(R.id.btnQq).setOnClickListener(v -> openQq());
        findViewById(R.id.btnGroup).setOnClickListener(v -> openGroup());

        touch(btnPick); touch(btnScan); touch(btnCopy);
        touch(findViewById(R.id.btnQq)); touch(findViewById(R.id.btnGroup));
        touch(navHome); touch(navOther);

        startHalo();
        loadPhoto();
        resetVerdictUI();
    }

    /* ==================== 交互反馈 ==================== */

    private void touch(View v) {
        v.setOnTouchListener((view, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
            } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(140)
                        .setInterpolator(new OvershootInterpolator(2.2f)).start();
            }
            return false;
        });
        v.setClickable(true);
    }

    /* ==================== 页面切换 ==================== */

    private void switchPage(boolean home) {
        View in = home ? pageHome.root : pageOther.root;
        View out = home ? pageOther.root : pageHome.root;

        navHome.setBackgroundResource(home ? R.drawable.bg_nav_active : R.drawable.bg_nav_idle);
        navOther.setBackgroundResource(home ? R.drawable.bg_nav_idle : R.drawable.bg_nav_active);
        navHome.setTextColor(getResources().getColor(home ? R.color.text_primary : R.color.text_muted));
        navOther.setTextColor(getResources().getColor(home ? R.color.text_muted : R.color.text_primary));

        if (in.getVisibility() == View.VISIBLE) {
            if (!home) entranceOther();
            return;
        }
        out.animate().alpha(0f).translationY(-dp(14)).setDuration(150).withEndAction(() -> {
            out.setVisibility(View.GONE);
            out.setAlpha(1f);
            out.setTranslationY(0);
        }).start();

        in.setAlpha(0f);
        in.setTranslationY(dp(22));
        in.setVisibility(View.VISIBLE);
        in.animate().alpha(1f).translationY(0).setDuration(240)
                .setStartDelay(70).setInterpolator(new DecelerateInterpolator()).start();

        if (!home) entranceOther();
    }

    private void entranceOther() {
        cardPhoto.setAlpha(0f);
        cardPhoto.setScaleX(0.9f);
        cardPhoto.setScaleY(0.9f);
        cardPhoto.setTranslationY(dp(18));
        cardPhoto.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0)
                .setDuration(380).setInterpolator(new OvershootInterpolator(0.9f)).start();

        cardContact.setAlpha(0f);
        cardContact.setTranslationY(dp(30));
        cardContact.animate().alpha(1f).translationY(0).setStartDelay(110).setDuration(320).start();

        cardNote.setAlpha(0f);
        cardNote.setTranslationY(dp(30));
        cardNote.animate().alpha(1f).translationY(0).setStartDelay(200).setDuration(320).start();

        // 图片轻微呼吸
        ObjectAnimator breath = ObjectAnimator.ofFloat(cardPhoto, "scaleX", 1f, 1.02f);
        breath.setDuration(2600);
        breath.setRepeatCount(3);
        breath.setRepeatMode(ValueAnimator.REVERSE);
        breath.setInterpolator(new AccelerateDecelerateInterpolator());
        breath.start();
    }

    /* ==================== 其他页资源 ==================== */

    private void loadPhoto() {
        new Thread(() -> {
            try {
                Bitmap raw = BitmapFactory.decodeResource(getResources(), R.drawable.anime_heroine);
                if (raw == null) return;
                Bitmap rounded = roundCorners(raw, Math.min(raw.getWidth(), raw.getHeight()) * 0.075f);
                runOnUiThread(() -> ivPhoto.setImageBitmap(rounded));
            } catch (Throwable ignored) {
            }
        }).start();
    }

    private static Bitmap roundCorners(Bitmap src, float radius) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, src.getWidth(), src.getHeight()), radius, radius, p);
        return out;
    }

    private void openQq() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=" + QQ_UIN + "&version=1&src_type=web"));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://wpa.qq.com/msgrd?v=3&uin=" + QQ_UIN + "&site=qq&menu=yes")));
            } catch (Exception e2) {
                toast("没有找到可用的 QQ,号码是 " + QQ_UIN);
            }
        }
    }

    private void openGroup() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin="
                            + GROUP_CODE + "&card_type=group&source=qrcode")));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(GROUP_URL)));
            } catch (Exception e2) {
                toast("没有找到可用的浏览器");
            }
        }
    }

    /* ==================== 盾牌 ==================== */

    private void startHalo() {
        haloAnim = ObjectAnimator.ofFloat(vHalo, "alpha", 1f, 0.35f);
        haloAnim.setDuration(1500);
        haloAnim.setRepeatCount(ValueAnimator.INFINITE);
        haloAnim.setRepeatMode(ValueAnimator.REVERSE);
        haloAnim.start();
    }

    private void resetVerdictUI() {
        tintShield(Color.parseColor("#3BE3D6"));
        tvHeadline.setText("等待检测");
        tvSubline.setText("选个脚本或丢个下载链接进来,它会把里面藏的东西全翻给你看。");
        tvMeta.setText("");
        tvRisk.setText("");
    }

    private void tintShield(int color) {
        ivShield.setColorFilter(color, PorterDuff.Mode.SRC_IN);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(withAlpha(color, 38));
        ring.setStroke(dp(2), withAlpha(color, 170));
        vRing.setBackground(ring);
        ivShield.animate().cancel();
        ivShield.setScaleX(0.6f);
        ivShield.setScaleY(0.6f);
        ivShield.animate().scaleX(1f).scaleY(1f).setDuration(420)
                .setInterpolator(new OvershootInterpolator(1.8f)).start();
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    /* ==================== 选文件 ==================== */

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "text/plain", "text/x-sh", "application/x-sh",
                "application/x-shellscript", "application/octet-stream", "*/*"});
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Exception e) {
            toast("打不开文件选择器");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            pickedUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(pickedUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            pickedName = pickedUri.getLastPathSegment();
            tvFileName.setText("已选择:" + shortName(pickedName));
            tvFileName.setTextColor(getResources().getColor(R.color.accent_cyan));
            etUrl.setText("");
        }
    }

    private static String shortName(String s) {
        if (s == null) return "所选文件";
        int i = s.lastIndexOf('/');
        return i >= 0 ? s.substring(i + 1) : s;
    }

    /* ==================== 检测 ==================== */

    private void startScan() {
        if (scanning) return;
        final String url = etUrl.getText().toString().trim();
        final String paste = etPaste.getText().toString();
        final Uri uri = pickedUri;

        if (url.isEmpty() && uri == null && paste.trim().isEmpty()) {
            toast("先选个文件,或粘一段脚本,或丢个下载链接进来");
            return;
        }

        hideKeyboard();
        setScanning(true);

        new Thread(() -> {
            try {
                ScriptLoader.Loaded loaded;
                if (!url.isEmpty()) {
                    loaded = ScriptLoader.fromUrl(url);
                } else if (uri != null) {
                    loaded = ScriptLoader.fromUri(MainActivity.this, uri);
                } else {
                    loaded = new ScriptLoader.Loaded("粘贴的脚本内容", paste,
                            paste.getBytes().length, false, "手动粘贴");
                }
                ScanEngine.Result result = ScanEngine.scan(loaded.content);
                runOnUiThread(() -> render(loaded, result));
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    setScanning(false);
                    toast(friendly(e));
                });
            }
        }, "shell-scan").start();
    }

    private static String friendly(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return "读取失败,换个文件或链接再试";
        if (m.contains("Unable to resolve host") || m.contains("UnknownHost"))
            return "域名解析不了,检查一下链接";
        if (m.contains("timeout") || m.contains("timed out") || m.contains("Timeout"))
            return "连接超时,这个地址可能不通";
        if (m.startsWith("目标返回 HTTP")) return m + ",对方可能禁止了直接下载";
        return m;
    }

    private void setScanning(boolean on) {
        scanning = on;
        btnScan.setEnabled(!on);
        btnScan.setText(on ? "检测中…" : "开始检测");
        if (on) {
            cardResult.setVisibility(View.VISIBLE);
            cardResult.setAlpha(0f);
            cardResult.animate().alpha(1f).setDuration(180).start();
            pbScan.setVisibility(View.VISIBLE);
            cardFindings.setVisibility(View.GONE);
            cardDump.setVisibility(View.GONE);
            tintShield(Color.parseColor("#8B7CFF"));
            tvHeadline.setText("正在拆开这个脚本…");
            tvSubline.setText("规则匹配 + 混淆还原 + 二次扫描,稍等一秒。");
            tvMeta.setText("");
            tvRisk.setText("");
        } else {
            pbScan.setVisibility(View.GONE);
        }
    }

    /* ==================== 渲染结果 ==================== */

    private void render(ScriptLoader.Loaded loaded, ScanEngine.Result r) {
        scanning = false;
        btnScan.setEnabled(true);
        btnScan.setText("开始检测");
        pbScan.setVisibility(View.GONE);

        lastResult = r;
        lastFileName = loaded.name == null ? "未命名" : loaded.name;

        int tone;
        String iconPrefix;
        if (r.verdict == ScanEngine.VERDICT_DANGER) {
            tone = Color.parseColor("#FF3B5C");
            iconPrefix = "X ";
        } else if (r.verdict == ScanEngine.VERDICT_SUSPECT) {
            tone = Color.parseColor("#FFB020");
            iconPrefix = "⚠ ";
        } else {
            tone = Color.parseColor("#2FE08A");
            iconPrefix = "√ ";
        }
        tintShield(tone);

        tvHeadline.setText(iconPrefix + r.headline());
        tvHeadline.setTextColor(tone);
        tvSubline.setText(r.subline());

        StringBuilder meta = new StringBuilder();
        meta.append("文件  ").append(lastFileName).append("\n");
        meta.append("来源  ").append(loaded.source).append("\n");
        meta.append("规模  ").append(fmtSize(loaded.bytes)).append(" · ")
            .append(r.lines).append(" 行 · ").append(r.chars).append(" 字符\n");
        meta.append(String.format(Locale.CHINA, "耗时  %.2f 秒 · 命中 %d 条", r.millis / 1000.0, r.findings.size()));
        if (loaded.truncated || r.truncated) meta.append("\n提示  文件较大,已按前一部分内容扫描");
        tvMeta.setText(meta.toString());

        StringBuilder risk = new StringBuilder();
        risk.append("风险指数  ").append(r.riskScore).append(" / 100\n");
        risk.append("严重 ").append(r.count(Finding.CRITICAL))
            .append("    高危 ").append(r.count(Finding.HIGH))
            .append("    中危 ").append(r.count(Finding.MEDIUM))
            .append("    低危 ").append(r.count(Finding.LOW));
        tvRisk.setText(risk.toString());
        tvRisk.setTextColor(tone);

        cardResult.setVisibility(View.VISIBLE);
        cardResult.setAlpha(0f);
        cardResult.setTranslationY(dp(16));
        cardResult.animate().alpha(1f).translationY(0).setDuration(300).start();

        renderFindings(r);
        renderDump(r);

        if (r.verdict == ScanEngine.VERDICT_DANGER) {
            tvSubline.setText(r.subline() + "\n结论:不要在任何设备上运行这个文件。");
        }
    }

    private void renderFindings(ScanEngine.Result r) {
        llFindings.removeAllViews();
        if (r.findings.isEmpty()) {
            cardFindings.setVisibility(View.VISIBLE);
            tvFindingsCount.setText("0 项");
            LayoutInflater inf = LayoutInflater.from(this);
            View v = inf.inflate(R.layout.item_finding, llFindings, false);
            TextView sev = v.findViewById(R.id.tvSev);
            TextView title = v.findViewById(R.id.tvTitle);
            TextView cat = v.findViewById(R.id.tvCat);
            TextView detail = v.findViewById(R.id.tvDetail);
            sev.setText("安全");
            sev.setBackground(pill("#2FE08A"));
            sev.setTextColor(Color.parseColor("#04120A"));
            title.setText("没有命中任何风险规则");
            cat.setText("规则库:" + RuleSet.all().size() + " 条 · 覆盖格机 / 混淆 / 后门 / 提权 / 外传");
            detail.setText("这个脚本没有出现毁灭性指令、混淆载荷、后门或系统篡改特征。不过静态检测不能覆盖一切,来源不明的脚本仍然建议先看清楚再跑。");
            llFindings.addView(v);
            return;
        }

        cardFindings.setVisibility(View.VISIBLE);
        tvFindingsCount.setText(r.findings.size() + " 项");
        LayoutInflater inf = LayoutInflater.from(this);
        for (int i = 0; i < r.findings.size(); i++) {
            Finding f = r.findings.get(i);
            View v = inf.inflate(R.layout.item_finding, llFindings, false);
            TextView sev = v.findViewById(R.id.tvSev);
            TextView title = v.findViewById(R.id.tvTitle);
            TextView line = v.findViewById(R.id.tvLine);
            TextView cat = v.findViewById(R.id.tvCat);
            TextView detail = v.findViewById(R.id.tvDetail);
            TextView snippet = v.findViewById(R.id.tvSnippet);

            sev.setText(Finding.sevName(f.severity));
            sev.setBackground(pill(Finding.sevColor(f.severity)));
            sev.setTextColor(f.severity >= Finding.MEDIUM
                    ? Color.parseColor("#1A0206") : Color.parseColor("#04121A"));

            title.setText(f.title);
            line.setText(f.line > 0 ? "L" + f.line : "");
            cat.setText(f.category + "  ·  " + f.origin);
            detail.setText(f.detail);

            if (f.snippet != null && !f.snippet.isEmpty()) {
                snippet.setVisibility(View.VISIBLE);
                snippet.setText(f.snippet);
            }
            llFindings.addView(v);
            stagger(v, i);
        }
    }

    private void renderDump(ScanEngine.Result r) {
        llDump.removeAllViews();
        if (r.decoded.isEmpty()) {
            cardDump.setVisibility(View.GONE);
            return;
        }
        cardDump.setVisibility(View.VISIBLE);
        tvDumpHint.setText("共还原出 " + r.decoded.size()
                + " 段被编码 / 加密隐藏的内容。下面是还原后的明文,只展示、不执行。");

        LayoutInflater inf = LayoutInflater.from(this);
        for (int i = 0; i < r.decoded.size(); i++) {
            Deobfuscator.Decoded d = r.decoded.get(i);
            View v = inf.inflate(R.layout.item_dump, llDump, false);
            TextView kind = v.findViewById(R.id.tvKind);
            TextView layer = v.findViewById(R.id.tvLayer);
            TextView source = v.findViewById(R.id.tvSource);
            TextView value = v.findViewById(R.id.tvValue);

            kind.setText(d.kind);
            layer.setText("第 " + d.layer + " 层 · 原始:" + d.source);
            source.setText("还原长度:" + d.value.length() + " 字符");
            value.setText(d.value);
            llDump.addView(v);
            stagger(v, i);
        }
    }

    private void stagger(View v, int index) {
        v.setAlpha(0f);
        v.setTranslationY(dp(14));
        v.animate().alpha(1f).translationY(0)
                .setStartDelay(Math.min(360, index * 45L))
                .setDuration(260).start();
    }

    private GradientDrawable pill(String colorHex) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(6));
        g.setColor(Color.parseColor(colorHex));
        return g;
    }

    /* ==================== 复制报告 ==================== */

    private void copyReport() {
        if (lastResult == null) {
            toast("先跑一次检测吧");
            return;
        }
        String text = lastResult.report(lastFileName);
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("Shell 防格机检测报告", text));
                toast("完整报告已复制到剪贴板");
            }
        } catch (Exception e) {
            toast("复制失败,换个方式试试");
        }
    }

    /* ==================== 工具 ==================== */

    private void hideKeyboard() {
        try {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            View f = getCurrentFocus();
            if (imm != null && f != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static String fmtSize(int bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.CHINA, "%.1f KB", bytes / 1024.0);
        return String.format(Locale.CHINA, "%.2f MB", bytes / 1048576.0);
    }

    @Override
    protected void onDestroy() {
        if (haloAnim != null) haloAnim.cancel();
        super.onDestroy();
    }
}
