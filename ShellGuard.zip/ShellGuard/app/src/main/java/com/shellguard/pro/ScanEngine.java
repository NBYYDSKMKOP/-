package com.shellguard.pro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 检测引擎。
 * 纯文本静态分析:规则匹配 + 结构化语义判定 + 反混淆后二次扫描。
 * 全程不执行被检测脚本的任何内容,不访问脚本中出现的任何地址。
 */
public final class ScanEngine {

    public static final int VERDICT_SAFE = 0;
    public static final int VERDICT_SUSPECT = 1;
    public static final int VERDICT_DANGER = 2;

    private static final int MAX_SCAN_CHARS = 2_000_000;
    private static final int MAX_PER_RULE = 12;
    private static final int MAX_FINDINGS = 300;

    public static class Result {
        public final List<Finding> findings;
        public final List<Deobfuscator.Decoded> decoded;
        public final int lines;
        public final int chars;
        public final int riskScore;
        public final int verdict;
        public final long millis;
        public final boolean truncated;

        Result(List<Finding> f, List<Deobfuscator.Decoded> d, int lines, int chars,
               int riskScore, int verdict, long millis, boolean truncated) {
            this.findings = f;
            this.decoded = d;
            this.lines = lines;
            this.chars = chars;
            this.riskScore = riskScore;
            this.verdict = verdict;
            this.millis = millis;
            this.truncated = truncated;
        }

        public int count(int severity) {
            int n = 0;
            for (Finding f : findings) if (f.severity == severity) n++;
            return n;
        }

        public String headline() {
            switch (verdict) {
                case VERDICT_DANGER: return "检测到恶意 / 高危脚本";
                case VERDICT_SUSPECT: return "存在可疑代码,建议人工复核";
                default: return "未发现格机或恶意指令";
            }
        }

        public String subline() {
            switch (verdict) {
                case VERDICT_DANGER:
                    return "该文件包含可直接毁坏设备或系统的指令,请勿在任何设备上运行。";
                case VERDICT_SUSPECT:
                    return "未发现明确的毁灭性指令,但存在可疑写法,运行前请逐条确认来源与用途。";
                default:
                    return "常规静态扫描未命中破坏性、混淆或后门特征,仍建议只运行可信来源的脚本。";
            }
        }

        public String report(String filename) {
            StringBuilder sb = new StringBuilder();
            sb.append("Shell 防格机检测报告\n");
            sb.append("文件: ").append(filename == null ? "(未命名)" : filename).append("\n");
            sb.append("结论: ").append(headline()).append("\n");
            sb.append("风险指数: ").append(riskScore).append("/100\n");
            sb.append("规模: ").append(lines).append(" 行 / ").append(chars).append(" 字符\n");
            sb.append(String.format(Locale.CHINA, "耗时: %.2f 秒\n", millis / 1000.0));
            sb.append("严重 ").append(count(Finding.CRITICAL))
              .append(" / 高危 ").append(count(Finding.HIGH))
              .append(" / 中危 ").append(count(Finding.MEDIUM))
              .append(" / 低危 ").append(count(Finding.LOW)).append("\n");
            sb.append("----------------------------------------\n");
            if (findings.isEmpty()) {
                sb.append("未命中任何风险规则。\n");
            } else {
                for (Finding f : findings) sb.append(f.toReportLine()).append("\n");
            }
            if (!decoded.isEmpty()) {
                sb.append("----------------------------------------\n");
                sb.append("解密 / 反混淆 dump(共 ").append(decoded.size()).append(" 段)\n");
                for (Deobfuscator.Decoded d : decoded) {
                    sb.append("[").append(d.layer).append(" 层 · ").append(d.kind).append("] ")
                      .append(d.source).append("\n");
                    sb.append(d.value).append("\n----\n");
                }
            }
            sb.append("----------------------------------------\n");
            sb.append("本报告由 Shell 防格机检测本地生成,仅供参考。\n");
            return sb.toString();
        }
    }

    private static final Pattern RM_CMD = Pattern.compile(
            "(?m)(?:^|[;&|(`\\n{\"'])\\s*(?:(?:sudo|busybox|toybox)\\s+|su\\s+-c\\s+)?rm\\s+([^\\n;&|`)]+)");

    /** 只有整个被删掉才算毁灭级:目标等于这些路径本身,或这些路径下的 /* */
    private static final Set<String> FATAL_ROOTS = new HashSet<>(java.util.Arrays.asList(
            "/", "/*", "/.", "/..", "/*.*", "~", "~/", "~/*", "$HOME", "${HOME}", "$HOME/",
            "/system", "/vendor", "/boot", "/recovery", "/data", "/storage", "/sdcard",
            "/storage/emulated", "/storage/emulated/0", "/etc", "/bin", "/sbin", "/lib",
            "/lib64", "/usr", "/proc", "/sys", "/dev", "/mnt", "/opt", "/root", "/var",
            "/cache", "/init", "/firmware", "/persist", "/metadata", "/oem", "/product",
            "/system_ext", "/dev/block"
    ));

    /** 只要落在这些子树里就是毁灭级(系统与用户数据的核心) */
    private static final String[] FATAL_SUBTREES = {
            "/data/data", "/data/system", "/data/misc", "/data/app", "/data/user",
            "/data/dalvik-cache", "/dev/block", "/system", "/vendor", "/boot", "/recovery",
            "/proc", "/sys", "/etc", "/bin", "/sbin", "/lib", "/usr", "/init",
            "/storage/emulated/0/Android", "/metadata"
    };

    private ScanEngine() {}

    public static Result scan(String raw) {
        long t0 = System.currentTimeMillis();
        boolean truncated = false;
        String content = raw == null ? "" : raw.replace("\r\n", "\n").replace('\r', '\n');
        if (content.length() > MAX_SCAN_CHARS) {
            content = content.substring(0, MAX_SCAN_CHARS);
            truncated = true;
        }

        List<Finding> findings = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        Set<String> lowTitles = new HashSet<>();
        int[] lineStarts = buildLineStarts(content);

        // 1) 规则库匹配
        List<Rule> rules = RuleSet.all();
        for (Rule rule : rules) {
            Matcher m = rule.pattern.matcher(content);
            int n = 0;
            while (m.find() && n < MAX_PER_RULE) {
                int line = lineAt(content, lineStarts, m.start());
                String snippet = lineText(content, m.start());
                Finding f = new Finding(rule.severity, rule.category, rule.title, rule.detail,
                        line, snippet, "原文");
                if (seen.add(f.key())) {
                    if (rule.severity == Finding.LOW && !lowTitles.add(rule.title)) continue;
                    findings.add(f);
                    n++;
                }
            }
        }

        // 2) 结构化语义判定:rm 递归删除
        checkRm(content, lineStarts, findings, seen, "原文");

        // 3) 反混淆 / 解密 dump
        List<Deobfuscator.Decoded> decoded = Deobfuscator.run(content);

        // 4) 对解密结果二次扫描
        for (Deobfuscator.Decoded d : decoded) {
            String tag = "解密第" + d.layer + "层";
            int[] ls = buildLineStarts(d.value);
            for (Rule rule : rules) {
                Matcher m = rule.pattern.matcher(d.value);
                int n = 0;
                while (m.find() && n < MAX_PER_RULE) {
                    int off = m.start();
                    Finding f = new Finding(rule.severity, rule.category, rule.title,
                            rule.detail + "(来自混淆载荷还原)", lineAt(d.value, ls, off),
                            lineText(d.value, off), tag);
                    if (seen.add(f.key())) {
                        if (rule.severity == Finding.LOW && !lowTitles.add(rule.title)) continue;
                        findings.add(f);
                        n++;
                    }
                }
            }
            checkRm(d.value, ls, findings, seen, tag);
        }

        // 5) 组合特征判定
        checkCompound(content, decoded, findings, seen);

        // 6) 启发式分析
        heuristics(content, findings, seen);

        // 7) 汇总
        Collections.sort(findings);
        if (findings.size() > MAX_FINDINGS) {
            findings = new ArrayList<>(findings.subList(0, MAX_FINDINGS));
        }

        int risk = riskScore(findings, content, decoded);
        int verdict = VERDICT_SAFE;
        for (Finding f : findings) {
            if (f.severity >= Finding.HIGH) { verdict = VERDICT_DANGER; break; }
            if (f.severity >= Finding.MEDIUM) verdict = VERDICT_SUSPECT;
        }
        if (verdict == VERDICT_SAFE && risk >= 45) verdict = VERDICT_SUSPECT;

        int lines = countLines(content);
        return new Result(findings, decoded, lines, content.length(), risk, verdict,
                System.currentTimeMillis() - t0, truncated);
    }

    /* ---------------- rm 结构化判定 ---------------- */

    private static void checkRm(String text, int[] lineStarts, List<Finding> out,
                               Set<String> seen, String origin) {
        Matcher m = RM_CMD.matcher(text);
        int guard = 0;
        while (m.find() && guard++ < 400) {
            String args = m.group(1);
            String[] toks = args.trim().split("\\s+");
            boolean rec = false, force = false;
            List<String> targets = new ArrayList<>();
            for (String tk : toks) {
                String t = tk.replace("\"", "").replace("'", "");
                if (t.isEmpty()) continue;
                if (t.startsWith("-")) {
                    String fl = t.replace("-", "");
                    if (fl.contains("r") || fl.contains("R")) rec = true;
                    if (fl.contains("f")) force = true;
                } else {
                    targets.add(t);
                }
            }
            if (!rec) continue;

            for (String target : targets) {
                String norm = target;
                while (norm.length() > 1 && norm.endsWith("/")) norm = norm.substring(0, norm.length() - 1);
                String bare = norm.replace("/*", "").replace("*", "");

                String wildRoot = null;
                if (norm.endsWith("/*")) wildRoot = norm.substring(0, norm.length() - 2);
                else if (norm.endsWith("*") && norm.length() > 1) wildRoot = norm.substring(0, norm.length() - 1);

                boolean wipeRoot = FATAL_ROOTS.contains(norm) || FATAL_ROOTS.contains(target)
                        || (wildRoot != null && FATAL_ROOTS.contains(wildRoot))
                        || (norm.startsWith("/") && norm.contains("*") && norm.indexOf('*') <= 2);
                boolean killAll = "*".equals(norm) || ".".equals(norm) || "./*".equals(norm);

                boolean fatalSub = false;
                String hit = null;
                for (String p : FATAL_SUBTREES) {
                    if (bare.equals(p) || norm.startsWith(p + "/") || bare.startsWith(p + "/")) {
                        fatalSub = true;
                        hit = p;
                        break;
                    }
                }

                if (wipeRoot) {
                    int line = lineAt(text, lineStarts, m.start());
                    Finding f = new Finding(Finding.CRITICAL, RuleSet.C_DESTROY,
                            "递归强制删除根目录 rm -rf " + norm,
                            "递归删除从根开始的所有内容,系统与全部数据会被清空,设备将无法正常开机。这是最典型的格机指令。",
                            line, lineText(text, m.start()), origin);
                    if (seen.add(f.key())) out.add(f);
                } else if (fatalSub) {
                    int line = lineAt(text, lineStarts, m.start());
                    Finding f = new Finding(Finding.CRITICAL, RuleSet.C_DESTROY,
                            "递归删除系统关键目录 rm -rf " + norm,
                            "递归删除 " + hit + " 路径下的内容,会破坏系统运行必需的文件或用户核心数据,可能导致系统崩溃、无法开机或数据永久丢失。",
                            line, lineText(text, m.start()), origin);
                    if (seen.add(f.key())) out.add(f);
                } else if (killAll) {
                    int line = lineAt(text, lineStarts, m.start());
                    Finding f = new Finding(Finding.MEDIUM, RuleSet.C_DESTROY,
                            "递归删除当前目录全部内容 rm -rf " + norm,
                            "无条件递归删除目标目录下全部内容,请确认这个目录里没有你要保留的数据。",
                            line, lineText(text, m.start()), origin);
                    if (seen.add(f.key())) out.add(f);
                }
            }
        }
    }

    /* ---------------- 组合特征 ---------------- */

    private static void checkCompound(String content, List<Deobfuscator.Decoded> decoded,
                                      List<Finding> out, Set<String> seen) {
        String low = content.toLowerCase(Locale.ROOT);
        boolean dynamicExec = low.contains("eval") || low.contains("| sh") || low.contains("|sh")
                || low.contains("| bash") || low.contains("|bash") || low.contains("exec ");
        boolean encoded = !decoded.isEmpty() || low.contains("base64") || low.contains("\\x");

        if (dynamicExec && encoded) {
            Finding f = new Finding(Finding.CRITICAL, RuleSet.C_OBFUSCATE,
                    "混淆载荷 + 动态执行(高度疑似恶意)",
                    "脚本先把内容编码隐藏,再用 eval 或管道交给 shell 执行。真实行为在运行时才展开,静态完全看不出——这是恶意脚本规避查杀的标志性结构。",
                    0, "eval / 管道执行 + 编码载荷", "组合特征");
            if (seen.add(f.key())) out.add(f);
        }

        int destroyedInDecoded = 0;
        for (Finding f : out) {
            if (f.origin != null && f.origin.startsWith("解密") && f.severity >= Finding.HIGH) {
                destroyedInDecoded++;
            }
        }
        if (destroyedInDecoded > 0) {
            Finding f = new Finding(Finding.CRITICAL, RuleSet.C_DESTROY,
                    "解密后暴露毁灭性指令",
                    "该脚本把真正的破坏性命令藏在编码/加密载荷里,还原后出现了高危或毁灭性指令。请在上方「解密 / 反混淆 dump」面板查看还原出来的原始内容。",
                    0, "混淆层内含高危指令", "组合特征");
            if (seen.add(f.key())) out.add(f);
        }

        int highPlus = 0;
        for (Finding f : out) if (f.severity >= Finding.HIGH) highPlus++;
        if (highPlus >= 5) {
            Finding f = new Finding(Finding.HIGH, RuleSet.C_DESTROY,
                    "高危指令密集出现",
                    "同一脚本中命中 " + highPlus + " 处高危及以上指令,属于明显的批量破坏型脚本特征。",
                    0, "高危指令 " + highPlus + " 处", "组合特征");
            if (seen.add(f.key())) out.add(f);
        }
    }

    /* ---------------- 启发式 ---------------- */

    private static void heuristics(String content, List<Finding> out, Set<String> seen) {
        int invisible = 0;
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '\u200b' || c == '\u200c' || c == '\u200d' || c == '\u2060'
                    || c == '\ufeff' || c == '\u00ad') invisible++;
        }
        if (invisible >= 3) {
            Finding f = new Finding(Finding.HIGH, RuleSet.C_OBFUSCATE,
                    "大量不可见字符(" + invisible + " 个)",
                    "脚本里混入了大量零宽字符,肉眼完全看不见,通常用于隐藏内容或干扰人工审查。",
                    0, "不可见字符 " + invisible + " 个", "启发式");
            if (seen.add(f.key())) out.add(f);
        }

        String[] lines = content.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            if (lines[i].length() > 5000) {
                Finding f = new Finding(Finding.MEDIUM, RuleSet.C_OBFUSCATE,
                        "超长单行内容(" + lines[i].length() + " 字符)",
                        "某一行长度异常,通常是压缩或编码后的载荷被塞进一行。建议用解密面板还原查看。",
                        i + 1, lines[i].substring(0, Math.min(160, lines[i].length())) + "…", "启发式");
                if (seen.add(f.key())) out.add(f);
                break;
            }
        }

        if (content.length() > 2000) {
            int encoded = 0, total = 0;
            for (int i = 0; i < content.length(); i++) {
                char c = content.charAt(i);
                if (c == '\n' || c == ' ' || c == '\t') continue;
                total++;
                if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
                        || c == '+' || c == '/' || c == '=') encoded++;
            }
            if (total > 0 && (encoded * 100 / total) >= 82) {
                Finding f = new Finding(Finding.HIGH, RuleSet.C_OBFUSCATE,
                        "整体呈编码形态",
                        "文件 " + (encoded * 100 / total) + "% 的字符都是编码字符集,正文几乎没有可读命令,极可能是整体被编码隐藏的载荷。",
                        0, "编码字符占比 " + (encoded * 100 / total) + "%", "启发式");
                if (seen.add(f.key())) out.add(f);
            }
        }
    }

    /* ---------------- 工具 ---------------- */

    private static int riskScore(List<Finding> findings, String content,
                                 List<Deobfuscator.Decoded> decoded) {
        int score = 0;
        for (Finding f : findings) {
            switch (f.severity) {
                case Finding.CRITICAL: score += 26; break;
                case Finding.HIGH: score += 11; break;
                case Finding.MEDIUM: score += 5; break;
                case Finding.LOW: score += 2; break;
                default: break;
            }
        }
        score += Math.min(15, decoded.size() * 4);
        return Math.min(100, score);
    }

    private static int[] buildLineStarts(String s) {
        List<Integer> starts = new ArrayList<>();
        starts.add(0);
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '\n') starts.add(i + 1);
        }
        int[] arr = new int[starts.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = starts.get(i);
        return arr;
    }

    private static int lineOf(int[] starts, int offset) {
        int lo = 0, hi = starts.length - 1, ans = 0;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (starts[mid] <= offset) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans + 1;
    }

    /** 匹配起点落在换行符上时,行号要归属到下一行 */
    private static int lineAt(String content, int[] starts, int matchStart) {
        int off = matchStart;
        if (off >= 0 && off < content.length() && content.charAt(off) == '\n') off++;
        return lineOf(starts, off);
    }

    private static String lineText(String content, int offset) {
        if (offset >= 0 && offset < content.length() && content.charAt(offset) == '\n') offset++;
        int start = content.lastIndexOf('\n', Math.max(0, offset - 1));
        start = start < 0 ? 0 : start + 1;
        int end = content.indexOf('\n', offset);
        if (end < 0) end = content.length();
        String line = content.substring(Math.min(start, content.length()), Math.min(end, content.length()));
        line = line.trim();
        if (line.length() > 200) line = line.substring(0, 200) + "…";
        return line;
    }

    private static int countLines(String s) {
        if (s.isEmpty()) return 0;
        int n = 1;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '\n') n++;
        return n;
    }
}
