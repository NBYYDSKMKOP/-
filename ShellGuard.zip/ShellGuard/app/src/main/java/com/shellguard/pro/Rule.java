package com.shellguard.pro;

import java.util.regex.Pattern;

/** 单条检测规则 */
public class Rule {

    public final String category;
    public final int severity;
    public final String title;
    public final String detail;
    public final Pattern pattern;

    public Rule(String category, int severity, String title, String detail, String regex) {
        this.category = category;
        this.severity = severity;
        this.title = title;
        this.detail = detail;
        this.pattern = Pattern.compile(regex);
    }
}
