package com.shellguard.pro;

import java.util.ArrayList;
import java.util.List;

/**
 * 检测规则库。
 * 全部为只读的静态文本匹配 + 结构化语义判定,不执行被检测脚本中的任何内容。
 */
public final class RuleSet {

    public static final String C_DESTROY   = "毁灭性指令";
    public static final String C_DISK      = "磁盘与分区破坏";
    public static final String C_OBFUSCATE = "混淆与加密载荷";
    public static final String C_BACKDOOR  = "后门与远程控制";
    public static final String C_SYSTEM    = "系统篡改与提权";
    public static final String C_EXFIL     = "信息收集与外传";
    public static final String C_RESOURCE  = "资源耗尽与瘫痪";
    public static final String C_ANDROID   = "安卓系统特性";

    private RuleSet() {}

    public static List<Rule> all() {
        List<Rule> r = new ArrayList<>();

        /* ================= 毁灭性指令 ================= */
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "格式化文件系统 mkfs",
                "mkfs 会把整个分区重新格式化,数据 100% 不可恢复。正常脚本绝不会调用。",
                "(?i)\\bmkfs(\\.[a-z0-9]+)?\\b"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "重建文件系统 mke2fs",
                "mke2fs 与 mkfs 同源,直接重建分区文件系统。",
                "(?i)\\bmke2fs\\b"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "抹除分区签名 wipefs",
                "wipefs 抹掉分区表签名,系统将无法挂载该分区。",
                "(?i)\\bwipefs\\b"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "丢弃块设备数据 blkdiscard",
                "blkdiscard 直接告知闪存控制器丢弃整块区域,速度快、不可恢复。",
                "(?i)\\bblkdiscard\\b"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "写内核 SysRq 触发器",
                "向 /proc/sysrq-trigger 写入可强制内核崩溃或立即断电,是典型格机手法。",
                "(?i)/proc/sysrq-trigger"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "抹除块设备 shred",
                "shred 会用随机数据反复覆写目标,用于销毁块设备时数据不可逆。",
                "(?i)\\bshred\\b[^\\n]*(/dev/|/system|/data)"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "挂载点强制卸载 umount /",
                "把根文件系统卸载,系统会立即失去可用的文件系统。",
                "(?i)\\bumount\\s+(-[a-z]+\\s+)*/\\s*(;|$|\\n)"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "移动根目录到 /dev/null",
                "把根下所有内容丢进黑洞设备,等于清空系统。",
                "(?i)\\bmv\\s+[^\\n]*/\\*[^\\n]*\\s/dev/null"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "find / -delete 全盘删除",
                "从根目录递归删除所有文件,是最直接的毁机写法之一。",
                "(?i)\\bfind\\s+/\\s[^\\n]*-delete"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "find / -exec rm 全盘删除",
                "对根目录下每一个文件执行删除命令。",
                "(?i)\\bfind\\s+/\\s[^\\n]*-exec\\s+(rm|unlink)"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "chmod -R 000 洗权限",
                "把根目录整个递归改成无权限,系统与所有应用立即瘫痪。",
                "(?i)\\bchmod\\s+(-[a-zA-Z]+\\s+)*0{3,4}\\s+/(\\s|$|\\*)"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "chmod -R 777 洗权限",
                "把根目录整体改成任何人可读写执行,系统安全模型被彻底摧毁。",
                "(?i)\\bchmod\\s+(-[a-zA-Z]+\\s+)*7{3,4}\\s+/(\\s|$|\\*)"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "chown 根目录接管",
                "把根目录所有权整体转移,通常用于配合后续破坏。",
                "(?i)\\bchown\\s+(-[a-zA-Z]+\\s+)*[^\\n]+\\s+/\\s*(;|$|\\n)"));
        r.add(new Rule(C_DESTROY, Finding.CRITICAL, "truncate 清零系统文件",
                "把系统关键文件截断为 0 字节,等同于删除但更隐蔽。",
                "(?i)\\btruncate\\s+-s\\s*0\\s+/(system|data|vendor|boot|etc|bin|sbin)"));
        r.add(new Rule(C_DESTROY, Finding.HIGH, "echo 覆写系统关键文件",
                "把内容直接重定向覆盖到 /system、/etc 等系统路径下。",
                "(?i)>>?\\s*/(system|vendor|etc|bin|sbin|boot)(/[a-zA-Z0-9_.\\-]+)?\\s*(;|$|\\n)"));

        /* ================= 磁盘与分区破坏 ================= */
        r.add(new Rule(C_DISK, Finding.CRITICAL, "dd 覆写块设备",
                "把零或随机数据写进 /dev/block、/dev/sdX 等块设备,分区数据会被整片覆盖,手机将无法开机。",
                "(?i)\\bdd\\b[^\\n]*\\bof\\s*=\\s*/dev/(block|sd|mmcblk|disk|nvme|ubi|by-name)"));
        r.add(new Rule(C_DISK, Finding.CRITICAL, "重定向写块设备",
                "不通过 dd,直接把数据流重定向进块设备节点,同样是整机毁灭级操作。",
                "(?i)>{1,2}\\s*/dev/(block|sd|mmcblk|disk|nvme|by-name)"));
        r.add(new Rule(C_DISK, Finding.CRITICAL, "刷写镜像 flash_image / erase_image",
                "安卓底层分区刷写与擦除工具,会直接改写分区内容。",
                "(?i)\\b(flash_image|erase_image|dump_image)\\b"));
        r.add(new Rule(C_DISK, Finding.CRITICAL, "fastboot 擦除 / 格式化",
                "fastboot erase、format、-w 会清空设备分区,是刷机界最常见的数据毁灭命令。",
                "(?i)\\bfastboot\\b[^\\n]*\\b(erase|format|-w)\\b"));
        r.add(new Rule(C_DISK, Finding.CRITICAL, "cat 随机数灌块设备",
                "把 /dev/urandom 或 /dev/zero 直接灌进磁盘设备。",
                "(?i)\\bcat\\s+/dev/(urandom|zero|random)\\s*>\\s*/dev/(sd|mmcblk|block|disk)"));
        r.add(new Rule(C_DISK, Finding.CRITICAL, "mount -o remount,rw 重挂根分区",
                "把根分区重新挂成可写,是后续破坏系统分区的标准前置动作。",
                "(?i)\\bmount\\b[^\\n]*remount[^\\n]*[\\s,]/\\s*[^\\n]*rw|\\bmount\\b[^\\n]*rw[^\\n]*remount"));
        r.add(new Rule(C_DISK, Finding.HIGH, "格式化工具族 umount+mkfs 组合",
                "先卸载再格式化,是脚本站一键毁机的典型组合拳。",
                "(?i)\\bumount\\b[^\\n]*\\n[^\\n]*\\bmkfs"));
        r.add(new Rule(C_DISK, Finding.HIGH, "dd 写大文件撑爆存储",
                "向存储写入大量零数据,用于把可用空间占满,导致系统无法写入而崩溃。",
                "(?i)\\bdd\\b[^\\n]*\\bif=/dev/(zero|urandom)\\b[^\\n]*\\bof=/(sdcard|storage|data|mnt)"));
        r.add(new Rule(C_DISK, Finding.HIGH, "blockdev 直接改块设备属性",
                "blockdev 可重设块大小或强制重读分区表,误用会造成分区错乱。",
                "(?i)\\bblockdev\\s+--"));
        r.add(new Rule(C_DISK, Finding.HIGH, "fdisk / parted 改分区表",
                "脚本里直接操作分区表,极易造成整机不可启动。",
                "(?i)\\b(fdisk|sfdisk|parted|gdisk)\\b[^\\n]*(/dev/(sd|mmcblk|block))"));

        /* ================= 混淆与加密载荷 ================= */
        r.add(new Rule(C_OBFUSCATE, Finding.CRITICAL, "base64 解码后直接执行",
                "把编码内容解出来立刻交给 shell 跑,这是混淆恶意脚本最典型的结构。",
                "(?i)base64\\s+(-d|--decode|-D)[^\\n]*\\|\\s*(sudo\\s+)?(ba|z|k|d)?sh\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.CRITICAL, "远程内容管道进 shell",
                "curl / wget 抓到的东西直接管道给 sh,执行的是什么完全不可见,典型的远程载荷投递。",
                "(?i)\\b(curl|wget|busybox\\s+wget)\\b[^\\n|]*\\|\\s*(sudo\\s+)?(ba|z|k|d)?sh\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.CRITICAL, "eval 动态执行拼接命令",
                "eval 会把字符串当命令执行,常用于把真实意图藏在变量和编码里。",
                "(?i)\\beval\\b[^\\n]*(\\$|`|base64|echo|printf)"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "base64 解码",
                "脚本内出现 base64 解码,内容被编码隐藏,需要用本工具的解密面板还原查看。",
                "(?i)\\bbase64\\s+(-d|--decode|-D)\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "openssl 解密",
                "用 openssl enc -d 解密数据,常见于把载荷加密后随脚本下发。",
                "(?i)\\bopenssl\\s+enc\\s+-d\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "xxd 十六进制还原",
                "xxd -r 把十六进制文本还原成二进制,常用于藏可执行内容。",
                "(?i)\\bxxd\\s+-r\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "uudecode 还原",
                "uudecode 还原 uuencode 内容,老式但依然有效的载荷藏匿方式。",
                "(?i)\\buudecode\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "printf 十六进制转义",
                "用 \\xNN 转义拼出真实命令文本,用来绕过关键字检测。",
                "(?i)\\bprintf\\b[^\\n]*\\\\x[0-9a-fA-F]{2}"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "ANSI-C 转义字符串 $'\\xNN'",
                "bash 的 $'\\x..' 语法可内联藏字节,肉眼几乎看不出真实内容。",
                "\\$'[^'\\n]*\\\\x[0-9a-fA-F]{2}"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "内联解释器执行 python/perl/ruby/php",
                "用 -c / -e 在脚本里直接跑一段其他语言的代码,是绕过静态检测的常见手法。",
                "(?i)\\b(python[0-9.]*|perl|ruby|php|node)\\s+(-c|-e|--eval)\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "gzip 解压后执行",
                "解压出来的内容直接执行,载荷被压缩隐藏。",
                "(?i)\\bgzip\\s+-d[^\\n|]*\\|\\s*(ba)?sh"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "修改 IFS 绕过检测",
                "重定义 IFS 分隔符会把一条命令拆成看不出原样的碎片,是经典的检测绕过技巧。",
                "(?i)\\bIFS\\s*="));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "零宽不可见字符藏码",
                "脚本里混入了零宽空格 / 零宽连接符等不可见字符,用于隐藏内容或干扰检测工具。",
                "[\\u200b\\u200c\\u200d\\u2060\\ufeff\\u00ad]"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "alias 劫持常用命令",
                "把 rm、ls 等常用命令重定义,用户以为在执行正常命令,实际跑的是别的逻辑。",
                "(?i)\\balias\\s+\\w+\\s*=\\s*['\"]?(rm|dd|mkfs|cat|ls|cp|mv|chmod|curl|wget)\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "超长 Base64 编码块",
                "出现大段连续编码字符,几乎可以确定是藏起来的载荷,建议用解密面板还原。",
                "[A-Za-z0-9+/]{320,}={0,2}"));
        r.add(new Rule(C_OBFUSCATE, Finding.HIGH, "连续十六进制转义串",
                "大段 \\xNN 连续出现,这是把二进制内容硬编码进脚本的手法。",
                "(?:\\\\x[0-9a-fA-F]{2}){16,}"));
        r.add(new Rule(C_OBFUSCATE, Finding.MEDIUM, "字符反转还原 rev",
                "rev 把文本倒过来输出,常与管道配合还原被反转隐藏的字符串。",
                "(?i)\\brev\\b\\s*\\|"));
        r.add(new Rule(C_OBFUSCATE, Finding.MEDIUM, "tr 字符替换还原",
                "用 tr 做整体字符映射,能把混淆过的文本还原成真实命令。",
                "(?i)\\btr\\s+['\"][^'\"\\n]+['\"]\\s+['\"][^'\"\\n]+['\"]"));
        r.add(new Rule(C_OBFUSCATE, Finding.MEDIUM, "eval 出现",
                "eval 会执行字符串形式的代码,请确认它的输入来源是否可信。",
                "(?i)\\beval\\b"));
        r.add(new Rule(C_OBFUSCATE, Finding.MEDIUM, "export PATH 被改写",
                "改写 PATH 会让系统调用到脚本自带的同名程序,属于环境劫持。",
                "(?i)\\bexport\\s+PATH\\s*="));
        r.add(new Rule(C_OBFUSCATE, Finding.MEDIUM, "大量反斜杠续行拼接",
                "连续多行以反斜杠续行,常被用来把一条危险命令拆散以规避检测。",
                "(?:\\\\\\s*\\n[^\\n]*){6,}"));

        /* ================= 后门与远程控制 ================= */
        r.add(new Rule(C_BACKDOOR, Finding.CRITICAL, "反弹 Shell /dev/tcp",
                "bash 的 /dev/tcp 伪设备可直接建立 TCP 连接,配合重定向就是标准反弹 shell,拿到 shell 的人可远程控制整机。",
                "(?i)/dev/(tcp|udp)/"));
        r.add(new Rule(C_BACKDOOR, Finding.CRITICAL, "nc -e 反弹 shell",
                "netcat 的 -e 参数把 shell 挂到网络连接上,典型远控后门。",
                "(?i)\\b(nc|netcat|ncat|busybox\\s+nc)\\b[^\\n]*(\\s-e\\s|--exec)"));
        r.add(new Rule(C_BACKDOOR, Finding.CRITICAL, "socat exec 反弹",
                "socat 的 exec: 参数同样可把 shell 暴露到网络上。",
                "(?i)\\bsocat\\b[^\\n]*exec:"));
        r.add(new Rule(C_BACKDOOR, Finding.CRITICAL, "bash -i 重定向建链",
                "交互式 shell 加双向重定向,是反弹 shell 的招牌写法。",
                "(?i)\\bbash\\s+-i\\s*>&"));
        r.add(new Rule(C_BACKDOOR, Finding.CRITICAL, "SSH 反向隧道",
                "ssh -R 会把远程端口转发回本机,常被用来穿透内网建立隐蔽通道。",
                "(?i)\\bssh\\b[^\\n]*-R\\s+\\d+"));
        r.add(new Rule(C_BACKDOOR, Finding.HIGH, "硬编码 IP:端口 疑似 C2",
                "脚本中出现固定 IP 加端口,是远控回连地址的典型特征,建议核对这个地址是不是你自己认识的服务。",
                "\\b(?:\\d{1,3}\\.){3}\\d{1,3}:\\d{2,5}\\b"));
        r.add(new Rule(C_BACKDOOR, Finding.MEDIUM, "网络连接工具 nc/ncat",
                "脚本调用了 netcat 系列工具,请确认用途。",
                "(?i)\\b(nc|netcat|ncat|socat)\\b"));
        r.add(new Rule(C_BACKDOOR, Finding.MEDIUM, "telnet 远程登录",
                "telnet 明文远程登录,存在被中间人窃取与后门利用的风险。",
                "(?i)\\btelnet\\b"));
        r.add(new Rule(C_BACKDOOR, Finding.MEDIUM, "写入 shell 启动文件持久化",
                "往 .bashrc / .profile 写入内容,可在每次登录时自动执行,是常见持久化手法。",
                "(?i)>>?\\s*[^\\n]*(\\/)?\\.(bashrc|bash_profile|profile|zshrc)"));
        r.add(new Rule(C_BACKDOOR, Finding.MEDIUM, "crontab 计划任务",
                "写入计划任务实现定时自动执行,是长期驻留的经典方式。",
                "(?i)\\bcrontab\\b\\s+-"));
        r.add(new Rule(C_BACKDOOR, Finding.MEDIUM, "开机自启目录 /etc/init.d",
                "写入 init.d 或 rc.local 让脚本随系统启动,属于持久化行为。",
                "(?i)(/etc/init\\.d/|/etc/rc\\.local|/etc/rc[0-9]\\.d/)"));
        r.add(new Rule(C_BACKDOOR, Finding.MEDIUM, "清除历史记录",
                "清掉命令历史,是规避事后取证的常见动作。",
                "(?i)(\\bhistory\\s+-c\\b|rm\\s+[^\\n]*\\.bash_history)"));
        r.add(new Rule(C_BACKDOOR, Finding.MEDIUM, "自建监听端口",
                "在脚本里开监听端口等待外部连入,需确认是否为授权用途。",
                "(?i)\\b(nc|ncat|socat)\\b[^\\n]*\\s-l\\b|\\b(nc|ncat)\\b[^\\n]*--listen"));

        /* ================= 系统篡改与提权 ================= */
        r.add(new Rule(C_SYSTEM, Finding.CRITICAL, "关闭 SELinux",
                "setenforce 0 关闭安卓的核心强制访问控制,系统防线直接消失,常与提权组合使用。",
                "(?i)\\bsetenforce\\s+0\\b"));
        r.add(new Rule(C_SYSTEM, Finding.HIGH, "读取账号密码文件",
                "/etc/passwd、/etc/shadow 是账号凭据文件,被脚本读取意味着凭据可能外泄。",
                "(?i)\\bcat\\s+/etc/(passwd|shadow|gshadow)"));
        r.add(new Rule(C_SYSTEM, Finding.HIGH, "读取系统私有数据目录",
                "/data/system、/data/misc 存放系统与账号数据库,读取属于越权访问。",
                "(?i)(/data/(system|misc|data)/)"));
        r.add(new Rule(C_SYSTEM, Finding.HIGH, "使用 root 提权",
                "调用 su / sudo 获取 root,脚本将拥有对整机完全控制的能力,请确认来源可信。",
                "(?i)(\\bsu\\s+-c\\b|\\bsudo\\b|\\bsu\\s+root\\b)"));
        r.add(new Rule(C_SYSTEM, Finding.MEDIUM, "调用 magisk 相关",
                "Magisk 相关命令通常用于获取或隐藏 root 权限,存在被滥用风险。",
                "(?i)\\bmagisk\\b"));
        r.add(new Rule(C_SYSTEM, Finding.MEDIUM, "清空防火墙规则",
                "iptables -F 会清掉全部防火墙规则,系统将失去网络层防护。",
                "(?i)\\biptables\\s+(-F|--flush|-X)\\b"));
        r.add(new Rule(C_SYSTEM, Finding.MEDIUM, "改内核运行时参数",
                "向 /proc/sys 写值会即时改变内核行为,错误设置可能导致系统异常。",
                "(?i)>{1,2}\\s*/proc/sys/"));
        r.add(new Rule(C_SYSTEM, Finding.MEDIUM, "批量卸载应用",
                "pm uninstall 批量卸载会移除用户应用甚至系统应用,影响设备可用性。",
                "(?i)\\bpm\\s+uninstall\\b"));
        r.add(new Rule(C_SYSTEM, Finding.MEDIUM, "强制杀死进程",
                "kill -9 / killall -9 强杀进程可能导致数据损坏或系统服务异常。",
                "(?i)\\b(kill|killall)\\s+-9\\b"));
        r.add(new Rule(C_SYSTEM, Finding.MEDIUM, "授予可执行权限",
                "chmod +x 常出现在下载后立即执行的可疑链条里,请核对被赋权文件的来源。",
                "(?i)\\bchmod\\s+(\\+x|[0-7]*[1357][0-7]*)\\b"));
        r.add(new Rule(C_SYSTEM, Finding.LOW, "修改 hosts 文件",
                "改写 hosts 可做域名劫持或屏蔽,请确认这是你自己想要的行为。",
                "(?i)>>?\\s*/etc/hosts\\b"));

        /* ================= 信息收集与外传 ================= */
        r.add(new Rule(C_EXFIL, Finding.HIGH, "POST 上传本地文件到远端",
                "curl / wget 把本地文件内容作为请求体发出去,是数据外传的典型写法,请确认目标地址是自己认识的服务。",
                "(?i)\\b(curl|wget)\\b[^\\n]*(-d|--data|-F|--form|-T|--upload-file)[^\\n]*@"));
        r.add(new Rule(C_EXFIL, Finding.HIGH, "打包后再上传",
                "先 tar/zip 打包再发往远端,属于批量数据外传的常见组合。",
                "(?i)\\b(tar|zip)\\b[^\\n]*\\|[^\\n]*\\b(curl|wget|nc|ncat)\\b"));
        r.add(new Rule(C_EXFIL, Finding.MEDIUM, "下载脚本文件到本地",
                "curl / wget 拉取 .sh 等脚本文件,下载后往往跟着执行,请核对来源域名。",
                "(?i)\\b(curl|wget)\\b[^\\n]*\\s(-O|--output|-o)\\s*[^\\n]*\\.(sh|py|bin|elf|apk)"));
        r.add(new Rule(C_EXFIL, Finding.LOW, "收集系统信息",
                "getprop / dumpsys / cat /proc 等命令用于读取设备指纹信息,单独出现属正常,配合上传则需警惕。",
                "(?i)(\\bgetprop\\b|\\bdumpsys\\b|\\bcat\\s+/proc/|\\buname\\s+-a\\b)"));
        r.add(new Rule(C_EXFIL, Finding.LOW, "脚本内硬编码外部链接",
                "脚本引用了外部网络地址,建议确认这个地址是否为你可信的来源。",
                "(?i)\\bhttps?://[^\\s'\"<>]+"));
        r.add(new Rule(C_EXFIL, Finding.LOW, "访问内网地址",
                "出现 192.168. / 10. / 127.0.0.1 等内网地址,通常用于探测或横向访问。",
                "\\b(192\\.168\\.\\d{1,3}\\.\\d{1,3}|10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}|127\\.0\\.0\\.1)\\b"));

        /* ================= 资源耗尽与瘫痪 ================= */
        r.add(new Rule(C_RESOURCE, Finding.CRITICAL, "Fork 炸弹",
                "自复制进程无限派生,会在极短时间内耗光系统进程与内存,导致设备卡死甚至需要强制重置。",
                "(?i):\\s*\\(\\s*\\)\\s*\\{[^\\n]*:\\s*\\|\\s*:[^\\n]*\\}\\s*;?\\s*:"));
        r.add(new Rule(C_RESOURCE, Finding.CRITICAL, "变体 Fork 炸弹",
                "函数体内自我后台调用形成指数级进程爆炸,与经典 fork 炸弹等价。",
                "(?i)\\b(\\w+)\\s*\\(\\s*\\)\\s*\\{[^\\n]*\\1\\s*\\|[^\\n]*\\1[^\\n]*&[^\\n]*\\}\\s*;?\\s*\\1"));
        r.add(new Rule(C_RESOURCE, Finding.HIGH, "无限循环重刷写 / 重启",
                "在死循环里反复重启或写盘,设备会陷入无法恢复的重启风暴。",
                "(?i)\\bwhile\\s+true\\b[^\\n]*(reboot|poweroff|halt|sync)"));
        r.add(new Rule(C_RESOURCE, Finding.MEDIUM, "死循环 while true",
                "脚本中存在无条件死循环,请确认它有正常的退出条件。",
                "(?i)\\bwhile\\s+true\\b"));
        r.add(new Rule(C_RESOURCE, Finding.MEDIUM, "C 风格空 for 死循环",
                "for(;;) 是无条件死循环,可能导致 CPU 占满。",
                "\\bfor\\s*\\(\\s*;\\s*;\\s*\\)"));
        r.add(new Rule(C_RESOURCE, Finding.MEDIUM, "yes 洪泛输出",
                "yes 会无限输出内容,配合重定向可撑爆存储或管道。",
                "(?i)\\byes\\b[^\\n]*\\|"));
        r.add(new Rule(C_RESOURCE, Finding.HIGH, "无限循环写文件撑爆存储",
                "在循环里持续写入大文件,用于把存储占满导致系统无响应。",
                "(?i)\\b(for|while)\\b[^\\n]*\\n[^\\n]*\\bdd\\b[^\\n]*of="));

        /* ================= 安卓系统特性 ================= */
        r.add(new Rule(C_ANDROID, Finding.MEDIUM, "修改系统设置项",
                "settings put 可直接改写系统级配置,被滥用会改变设备行为。",
                "(?i)\\bsettings\\s+(put|delete)\\b"));
        r.add(new Rule(C_ANDROID, Finding.MEDIUM, "操作 vold 存储服务",
                "vold 是安卓存储守护进程,直接操作它会强制重新挂载或卸载存储。",
                "(?i)\\bvold\\b"));
        r.add(new Rule(C_ANDROID, Finding.HIGH, "改写系统分区内容",
                "对 /system、/vendor、/boot 执行写操作会破坏系统完整性,可能导致无法开机。",
                "(?i)\\b(rm|mv|cp|echo|dd|tee)\\b[^\\n]*(/system/|/vendor/|/boot/|/recovery)"));
        r.add(new Rule(C_ANDROID, Finding.MEDIUM, "清空应用数据目录",
                "删除 /data/data 下内容等于抹掉所有应用数据。",
                "(?i)\\brm\\b[^\\n]*/data/data"));
        r.add(new Rule(C_ANDROID, Finding.LOW, "使用 /data/local/tmp",
                "/data/local/tmp 是可执行权限较宽松的目录,常被当作落地临时载荷的位置。",
                "(?i)/data/local/tmp"));
        r.add(new Rule(C_ANDROID, Finding.LOW, "termux 环境命令",
                "脚本针对 Termux 环境,属于常见安卓脚本运行环境,请确认来源。",
                "(?i)\\btermux-|\\$PREFIX/bin"));

        return r;
    }
}
