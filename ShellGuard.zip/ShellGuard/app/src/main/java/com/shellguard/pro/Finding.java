package com.shellguard.pro;

/** 一条检测发现 */
public class Finding implements Comparable<Finding> {

    public static final int INFO = 0;
    public static final int LOW = 1;
    public static final int MEDIUM = 2;
    public static final int HIGH = 3;
    public static final int CRITICAL = 4;

    public final int severity;
    public final String category;
    public final String title;
    public final String detail;
    public final int line;
    public final String snippet;
    public final String origin;

    public Finding(int severity, String category, String title, String detail,
                   int line, String snippet, String origin) {
        this.severity = severity;
        this.category = category;
        this.title = title;
        this.detail = detail;
        this.line = line;
        this.snippet = snippet == null ? "" : snippet;
        this.origin = origin == null ? "原文" : origin;
    }

    public static String sevName(int s) {
        switch (s) {
            case CRITICAL: return "严重";
            case HIGH: return "高危";
            case MEDIUM: return "中危";
            case LOW: return "低危";
            default: return "提示";
        }
    }

    public static String sevColor(int s) {
        switch (s) {
            case CRITICAL: return "#FF3B5C";
            case HIGH: return "#FF6B4A";
            case MEDIUM: return "#FFB020";
            case LOW: return "#4FC3F7";
            default: return "#8E97B8";
        }
    }

    public String key() {
        return severity + "|" + title + "|" + line + "|" + snippet;
    }

    public String toReportLine() {
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(sevName(severity)).append("] ").append(title);
        if (line > 0) sb.append("  (第 ").append(line).append(" 行)");
        if (origin != null && !"原文".equals(origin)) sb.append("  <").append(origin).append(">");
        if (snippet.length() > 0) sb.append("\n    ").append(snippet);
        return sb.toString();
    }

    @Override
    public int compareTo(Finding o) {
        if (severity != o.severity) return o.severity - severity;
        if (line != o.line) return Integer.compare(line, o.line);
        return title.compareTo(o.title);
    }
}
