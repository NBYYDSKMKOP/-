<?php
// 接收客户端上传的截屏文件官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method Not Allowed');
}

$device_key = isset($_POST['key']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['key']) : '';
if (empty($device_key)) {
    http_response_code(400);
    die('Missing key');
}

// 根据device_key查找用户
require_once __DIR__ . '/db.php';
$device_file = __DIR__ . '/devices/' . $device_key . '.json';

if (!file_exists($device_file)) {
    http_response_code(403);
    die('Unknown device');
}

$device_info = json_decode(file_get_contents($device_file), true);
$user_id = $device_info['user_id'] ?? 0;
$api_key = $device_info['api_key'] ?? '';

if ($user_id <= 0) {
    http_response_code(403);
    die('Invalid device');
}

// 检查是否有文件上传
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    die('No file uploaded');
}

// 创建用户专属目录
$user_dir = __DIR__ . '/screenshots/' . $user_id . '/';
if (!is_dir($user_dir)) {
    mkdir($user_dir, 0755, true);
}

// 保存文件
$filename = $_FILES['file']['name'];  // 使用客户端上传的原始文件名
if (empty($ext)) $ext = 'png';
$filename = 'capture_' . date('Ymd_His') . '.' . $ext;
$filepath = $user_dir . $filename;

if (move_uploaded_file($_FILES['file']['tmp_name'], $filepath)) {
    chmod($filepath, 0644);
    echo json_encode(['success' => true, 'file' => $filename]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Save failed']);
}