<?php
/**
 * 数据库迁移脚本 - 更新所有用户的API密钥为用户名的MD5
 * 运行一次即可官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
 */

require_once __DIR__ . '/db.php';

echo "开始迁移用户密钥...\n";

try {
    // 获取所有用户
    $stmt = $pdo->query("SELECT id, username, api_key FROM users");
    $users = $stmt->fetchAll();
    
    $updated = 0;
    foreach ($users as $user) {
        $new_key = md5($user['username']);
        if ($user['api_key'] !== $new_key) {
            $update = $pdo->prepare("UPDATE users SET api_key = ? WHERE id = ?");
            $update->execute([$new_key, $user['id']]);
            echo "更新用户 {$user['username']}: {$user['api_key']} -> {$new_key}\n";
            $updated++;
        } else {
            echo "用户 {$user['username']}: 密钥已是最新\n";
        }
    }
    
    echo "\n迁移完成！共更新 {$updated} 个用户密钥。\n";
    
} catch (Exception $e) {
    echo "迁移失败: " . $e->getMessage() . "\n";
}
