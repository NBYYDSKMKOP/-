<?php
session_start();
require_once 'db.php';
require_once 'Mailer.php';

$error = '';
$success = '';

// 获取邮箱验证码官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
if (isset($_POST['get_code'])) {
    $email = trim($_POST['email']);
    
    if (empty($email)) {
        $error = '请先填写邮箱地址';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '请输入有效的邮箱地址';
    } else {
        if (isset($_SESSION['code_time']) && time() - $_SESSION['code_time'] < 60) {
            $remaining = 60 - (time() - $_SESSION['code_time']);
            $error = "请等待 {$remaining} 秒后再获取验证码";
        } else {
            // 检查邮箱是否已被注册
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = '该邮箱已被注册';
            } else {
                $code = Mailer::generateCode();
                $pdo->prepare("DELETE FROM verify_codes WHERE email = ? AND type = 'register'")->execute([$email]);
                $stmt = $pdo->prepare("INSERT INTO verify_codes (email, code, type, expires_at) VALUES (?, ?, 'register', DATE_ADD(NOW(), INTERVAL 10 MINUTE))");
                $stmt->execute([$email, $code]);
                
                $mailer = new Mailer();
                if ($mailer->sendRegisterCode($email, $code)) {
                    $_SESSION['code_time'] = time();
                    $success = '验证码已发送，请查收邮件（10分钟内有效）';
                } else {
                    $error = '邮件发送失败，请稍后重试';
                }
            }
        }
    }
}

// 提交注册
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $email = trim($_POST['email']);
    $code = trim($_POST['code']);
    
    if (empty($username)) {
        $error = '请输入用户名';
    } elseif (!preg_match('/^[a-zA-Z0-9_-]{3,20}$/', $username)) {
        $error = '用户名只能包含字母数字下划线和横线，长度3-20';
    } elseif (empty($email)) {
        $error = '请输入邮箱地址';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '请输入有效的邮箱地址';
    } elseif (empty($password)) {
        $error = '请输入密码';
    } elseif (strlen($password) < 6) {
        $error = '密码长度至少6位';
    } elseif ($password !== $password2) {
        $error = '两次密码不一致';
    } elseif (empty($code)) {
        $error = '请输入验证码';
    } else {
        // 验证验证码
        $stmt = $pdo->prepare("SELECT * FROM verify_codes WHERE email = ? AND code = ? AND type = 'register' AND used = 0 AND expires_at > NOW() ORDER BY id DESC LIMIT 1");
        $stmt->execute([$email, $code]);
        $verify = $stmt->fetch();
        
        if (!$verify) {
            $error = '验证码错误或已过期';
        } else {
            // 检查用户名是否已存在
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $error = '此用户名已被占用，请换一个';
            } else {
                // 检查邮箱是否已被注册（二次确认）
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $error = '该邮箱已被注册';
                } else {
                    // 生成专属密钥 - 基于用户名MD5，固定不变
                    $device_key = 'dev_' . md5($username);
                    
                    // 创建用户（同时生成api_key）
                    $api_key = md5($username);
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, device_key, api_key) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$username, $hashed_password, $email, $device_key, $api_key]);
                    
                    // 标记验证码已使用
                    $pdo->prepare("UPDATE verify_codes SET used = 1 WHERE id = ?")->execute([$verify['id']]);
                    
                    // 自动登录
                    $_SESSION['user_id'] = $pdo->lastInsertId();
                    $_SESSION['username'] = $username;
                    $_SESSION['device_key'] = $device_key;
                    
                    header('Location: console.php');
                    exit;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>泽峰远控 - 注册</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { -webkit-text-size-adjust: 100%; text-size-adjust: 100%; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            background: #05080f;
            background-image:
                linear-gradient(rgba(0, 212, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 212, 255, 0.05) 1px, transparent 1px);
            background-size: 32px 32px;
            min-height: 100vh;
            min-height: 100dvh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background:
                radial-gradient(500px 300px at 75% -10%, rgba(124, 92, 255, 0.16), transparent 70%),
                radial-gradient(500px 300px at 20% 110%, rgba(0, 212, 255, 0.14), transparent 70%);
            pointer-events: none;
        }
        .form-box {
            max-width: 420px;
            width: 100%;
            background: linear-gradient(180deg, rgba(12, 19, 34, 0.92), rgba(16, 26, 46, 0.92));
            border: 1px solid rgba(0, 212, 255, 0.2);
            border-radius: 18px;
            padding: 35px 30px;
            box-shadow: 0 0 40px rgba(0, 212, 255, 0.08), 0 20px 60px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(10px);
            position: relative;
            z-index: 1;
        }
        .form-box::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #00d4ff, transparent);
        }
        .form-box .icon { text-align: center; font-size: 2.5em; margin-bottom: 6px; }
        .form-box h2 { text-align: center; color: #fff; margin-bottom: 4px; font-size: 1.3em; text-shadow: 0 0 18px rgba(0, 212, 255, 0.4); }
        .form-box .desc { text-align: center; color: #7f93b5; font-size: 0.82em; margin-bottom: 22px; }
        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-weight: 600; color: #a8bbd9; margin-bottom: 5px; font-size: 0.82em; }
        .form-group input {
            width: 100%;
            padding: 11px 14px;
            background: rgba(0, 212, 255, 0.05);
            border: 2px solid rgba(0, 212, 255, 0.18);
            border-radius: 10px;
            font-size: 0.93em;
            color: #e6f1ff;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .form-group input::placeholder { color: #4a5a7a; }
        .form-group input:focus {
            border-color: #00d4ff;
            box-shadow: 0 0 16px rgba(0, 212, 255, 0.25);
        }
        .code-row { display: flex; gap: 10px; }
        .code-row input { flex: 1; }
        .code-btn {
            white-space: nowrap;
            padding: 11px 14px;
            background: linear-gradient(135deg, #00d4ff, #7c5cff);
            color: #05080f;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 0.82em;
            font-weight: 600;
            transition: opacity 0.2s;
        }
        .code-btn:hover { opacity: 0.85; }
        .code-btn:disabled { opacity: 0.45; cursor: not-allowed; }
        .alert { padding: 12px; border-radius: 8px; margin-bottom: 14px; font-size: 0.82em; text-align: center; }
        .alert-error { background: rgba(255, 84, 112, 0.1); color: #ff5470; border: 1px solid rgba(255, 84, 112, 0.3); }
        .alert-success { background: rgba(0, 255, 163, 0.08); color: #00ffa3; border: 1px solid rgba(0, 255, 163, 0.3); }
        .submit-btn {
            width: 100%;
            padding: 13px;
            background: linear-gradient(135deg, #00d4ff, #7c5cff);
            color: #05080f;
            border: none;
            border-radius: 10px;
            font-size: 1em;
            font-weight: 700;
            cursor: pointer;
            margin-top: 6px;
            box-shadow: 0 4px 20px rgba(0, 212, 255, 0.25);
            transition: all 0.2s;
        }
        .submit-btn:hover { opacity: 0.9; transform: translateY(-2px); }
        .link-text { text-align: center; margin-top: 16px; font-size: 0.82em; color: #7f93b5; }
        .link-text a { color: #00d4ff; text-decoration: none; font-weight: 600; }
        .link-text a:hover { text-shadow: 0 0 12px rgba(0, 212, 255, 0.6); }

        @media (max-width: 480px) {
            body { padding: 14px; align-items: center; justify-content: center; }
            .form-box {
                padding: 28px 22px;
                margin: 0;
                border-radius: 16px;
                width: 100%;
                max-width: 100%;
            }
            .form-box h2 { font-size: 1.25em; }
            .form-group label { font-size: 0.9em; }
            .form-group input {
                padding: 13px 14px;
                font-size: 16px;
                -webkit-appearance: none;
                appearance: none;
            }
            .submit-btn { padding: 14px; font-size: 1em; }
            .code-btn { padding: 13px 14px; font-size: 0.85em; }
            .alert { font-size: 0.9em; }
            .link-text { font-size: 0.9em; }
        }
    </style>
</head>
<body>
    <div class="form-box">
        <div class="icon">📝</div>
        <h2>创建账号</h2>
        <p class="desc">注册即生成专属设备密钥</p>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" id="regForm" novalidate>
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" placeholder="3-20位字母数字" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label>邮箱</label>
                <div class="code-row">
                    <input type="email" name="email" id="emailInput" placeholder="用于验证和找回密码" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    <button type="button" class="code-btn" id="codeBtn" onclick="getCode()">获取验证码</button>
                </div>
            </div>
            
            <div class="form-group">
                <label>邮箱验证码</label>
                <input type="text" name="code" id="codeInput" placeholder="输入6位验证码" maxlength="6">
            </div>
            
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" placeholder="至少6位密码">
            </div>
            
            <div class="form-group">
                <label>确认密码</label>
                <input type="password" name="password2" placeholder="再次输入密码">
            </div>
            
            <button type="submit" name="register" class="submit-btn">✅ 立即注册</button>
        </form>
        
        <p class="link-text">已有账号？<a href="login.php">立即登录</a></p>
    </div>
    
    <script>
    var cooldown = <?php echo isset($_SESSION['code_time']) ? max(0, 60 - (time() - $_SESSION['code_time'])) : 0; ?>;
    var codeBtn = document.getElementById('codeBtn');
    
    function updateCooldown() {
        if (cooldown > 0) {
            codeBtn.disabled = true;
            codeBtn.textContent = cooldown + '秒后重试';
            cooldown--;
            setTimeout(updateCooldown, 1000);
        } else {
            codeBtn.disabled = false;
            codeBtn.textContent = '获取验证码';
        }
    }
    if (cooldown > 0) updateCooldown();
    
    function getCode() {
        var email = document.getElementById('emailInput').value.trim();
        if (email === '') {
            alert('请先填写邮箱地址');
            return;
        }
        var form = document.getElementById('regForm');
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'get_code';
        input.value = '1';
        form.appendChild(input);
        form.submit();
    }
    </script>
</body>
</html>