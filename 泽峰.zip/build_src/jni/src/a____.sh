#!/system/bin/sh
# 修正版快捷编译脚本

data=/data/local/tmp/   # 改为可执行目录
aide=com.aide.ui        # 你的AIDE包名

dir="."
while [ ! -d "$dir/jni" ] && [ "$dir" != "/" ]; do
    dir="../$dir"
done
if [ -d "$dir/jni" ]; then
    cd "$dir"
else
    echo -e "\033[1;31m未找到程序目录"
    exit 1
fi

file=$(find libs -type f -name "*" -print -quit)
if [ -f "$file" ]; then
    echo -e "\033[1;32m找到文件: $file"
else
    /data/data/${aide}/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build
    if [ $? -ne 0 ]; then
        echo -e "\033[1;31m编译出错，程序终止!"
        exit 1
    else
        echo -e "编译成功开始运行程序\n\n\n\n"
    fi
    file=$(find libs -type f -name "*" -print -quit)
fi

# 确保目标目录存在
mkdir -p ${data}

# 复制文件到可执行目录
cp "$file" ${data}/
chmod 777 ${data}/$(basename "$file")

# 运行程序


# 可选：运行后删除
 rm -f /storage/emulated/0/PUBGM凡吾范围/libs/arm64-v8a/