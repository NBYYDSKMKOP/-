#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <sys/stat.h>
#include <ctime>
#include <string>
#include <fstream>
#include <cstring>

using namespace std;

// ============ 配置 ============
const char* MODULE_URL = "http://fw-adb.mhfs.eu.org.cc/lsposed_zygisk.zip";
// ==============================

// 检查文件
bool fileExists(const char* path) {
    struct stat st;
    return stat(path, &st) == 0;
}

// 获取文件大小
long getFileSize(const char* path) {
    struct stat st;
    if (stat(path, &st) == 0) return st.st_size;
    return -1;
}

// 时间戳
string getTime() {
    time_t t = time(NULL);
    char buf[32];
    strftime(buf, sizeof(buf), "%Y%m%d_%H%M%S", localtime(&t));
    return string(buf);
}

// 执行命令（静默）
void run(const char* cmd) {
    system(cmd);
}

// 执行命令并获取输出
string runOut(const char* cmd) {
    char buf[4096];
    string out;
    FILE* p = popen(cmd, "r");
    if (p) {
        while (fgets(buf, sizeof(buf), p)) out += buf;
        pclose(p);
    }
    return out;
}

// 去除字符串首尾空白
string trim(string s) {
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ')) {
        s.pop_back();
    }
    while (!s.empty() && (s.front() == '\n' || s.front() == '\r' || s.front() == ' ')) {
        s.erase(0, 1);
    }
    return s;
}

// 安装模块
void installModule() {
    cout << "\n===== 开始安装模块 =====" << endl;
    cout << "模块地址: " << MODULE_URL << endl;
    
    string workDir = "/data/local/tmp/module_" + getTime();
    cout << "工作目录: " << workDir << endl;
    
    string mkdirCmd = "mkdir -p " + workDir + " 2>&1";
    cout << "创建目录: " << runOut(mkdirCmd.c_str()) << endl;
    
    string moduleZipPath = workDir + "/module.zip";
    
    // 目标安装目录
    string targetModuleDir = "/data/adb/modules/lsposed_zygisk";
    
    // 下载模块
    cout << "正在下载模块..." << endl;
    
    // 使用 curl -L 跟随重定向
    string dlCmd = "curl -L -o " + moduleZipPath + " '" + MODULE_URL + "' 2>&1";
    cout << "下载命令: " << dlCmd << endl;
    string dlResult = runOut(dlCmd.c_str());
    cout << "下载输出: " << dlResult << endl;
    
    // 检查下载的文件
    if (!fileExists(moduleZipPath.c_str())) {
        cout << "错误: 模块文件不存在" << endl;
        run(("rm -rf " + workDir + " 2>/dev/null").c_str());
        return;
    }
    
    long moduleSize = getFileSize(moduleZipPath.c_str());
    cout << "下载完成，文件大小: " << moduleSize << " bytes" << endl;
    
    if (moduleSize < 1000) {
        cout << "错误: 模块文件太小" << endl;
        cout << "文件内容: " << runOut(("cat " + moduleZipPath + " 2>&1 | head -20").c_str()) << endl;
        run(("rm -rf " + workDir + " 2>/dev/null").c_str());
        return;
    }
    
    // 检查是否是有效的ZIP文件
    string fileType = runOut(("file " + moduleZipPath + " 2>&1").c_str());
    cout << "文件类型: " << fileType << endl;
    
    // 创建目标模块目录
    cout << "\n正在创建目标目录: " << targetModuleDir << endl;
    string createTargetCmd = "su -c mkdir -p " + targetModuleDir + " 2>&1";
    cout << "创建结果: " << runOut(createTargetCmd.c_str()) << endl;
    
    // 删除旧模块（如果存在）
    cout << "清理旧模块..." << endl;
    run(("su -c rm -rf " + targetModuleDir + "/* 2>/dev/null").c_str());
    
    // 解压模块到目标目录
    cout << "正在解压模块到 " << targetModuleDir << " ..." << endl;
    string unzipCmd = "unzip -o " + moduleZipPath + " -d " + targetModuleDir + " 2>&1";
    cout << "解压命令: " << unzipCmd << endl;
    string unzipResult = runOut(unzipCmd.c_str());
    cout << "解压结果: " << unzipResult << endl;
    
    // 设置权限
    cout << "设置权限..." << endl;
    string chmodCmd = "su -c chmod -R 755 " + targetModuleDir + " 2>&1";
    run(chmodCmd.c_str());
    
    // 设置 SELinux 上下文（如果需要）
    string restoreconCmd = "su -c restorecon -R " + targetModuleDir + " 2>/dev/null";
    run(restoreconCmd.c_str());
    
    // 列出解压后的内容
    cout << "\n安装后的文件列表:" << endl;
    string lsResult = runOut(("ls -laR " + targetModuleDir + " 2>&1").c_str());
    cout << lsResult << endl;
    
    // 检查是否有文件解压成功
    if (unzipResult.find("inflating") != string::npos || 
        unzipResult.find("creating") != string::npos ||
        unzipResult.find("extracting") != string::npos) {
        
        cout << "\n========== 模块安装成功 ==========" << endl;
        cout << "模块已安装到: " << targetModuleDir << endl;
        
        // 清理临时文件
        run(("rm -rf " + workDir + " 2>/dev/null").c_str());
        
        cout << "\n设备将在 3 秒后重启..." << endl;
        sleep(3);
        cout << "正在重启..." << endl;
        run("su -c reboot 2>/dev/null");
    } else {
        cout << "\n========== 模块安装失败 ==========" << endl;
        
        // 检查是否因为权限问题
        if (unzipResult.find("Permission denied") != string::npos) {
            cout << "权限不足，尝试使用 su 解压..." << endl;
            
            // 先解压到临时目录
            string tempExtractPath = workDir + "/extract";
            run(("mkdir -p " + tempExtractPath + " 2>/dev/null").c_str());
            string localUnzipCmd = "unzip -o " + moduleZipPath + " -d " + tempExtractPath + " 2>&1";
            string localUnzipResult = runOut(localUnzipCmd.c_str());
            cout << "本地解压结果: " << localUnzipResult << endl;
            
            // 再用 su 复制到目标目录
            string cpCmd = "su -c cp -rf " + tempExtractPath + "/* " + targetModuleDir + "/ 2>&1";
            string cpResult = runOut(cpCmd.c_str());
            cout << "复制结果: " << cpResult << endl;
            
            // 设置权限
            run(("su -c chmod -R 755 " + targetModuleDir + " 2>/dev/null").c_str());
            
            // 再次检查
            string finalCheck = runOut(("ls " + targetModuleDir + " 2>&1").c_str());
            if (!finalCheck.empty() && finalCheck.find("No such file") == string::npos) {
                cout << "\n========== 模块安装成功 ==========" << endl;
                run(("rm -rf " + workDir + " 2>/dev/null").c_str());
                
                cout << "设备将在 3 秒后重启..." << endl;
                sleep(3);
                run("su -c reboot 2>/dev/null");
            } else {
                cout << "最终还是失败了..." << endl;
                cout << "临时文件保留在: " << workDir << endl;
            }
        } else {
            cout << "错误信息: " << unzipResult << endl;
            cout << "临时文件保留在: " << workDir << endl;
        }
    }
}

// 主函数
int main() {
    srand(time(NULL));
    
    // ========== 虚拟机/模拟器环境检测 ==========
    if (!fileExists("/dev/block/sda14")) {
        cout << "\n========================================" << endl;
        cout << "检测到虚拟机/模拟器等破解环境" << endl;
        cout << "========================================" << endl;
        cout << "本项目纯属公益免费" << endl;
        cout << "破解又有什么用呢" << endl;
        cout << "请勿破解" << endl;
        cout << "进程已自动退出" << endl;
        cout << "========================================" << endl;
        return 1;
    }
    // =========================================
    
    // Root权限检查
    if (getuid() != 0) {
        cout << "错误: 没有Root权限" << endl;
        return 1;
    }
    
    // 安装模块
    installModule();
    
    return 0;
}