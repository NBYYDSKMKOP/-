<?php
// 数据库连接配置官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
$db_host = 'localhost';
$db_name = 'xiaotucie8xhnj14';
$db_user = 'xiaotucie8xhnj14';
$db_pass = '4d4efcb9da09';

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]
    );
} catch (PDOException $e) {
    die('数据库连接失败: ' . $e->getMessage());
}

// 创表（首次运行自动创建）
$pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL,
    `password` varchar(255) NOT NULL,
    `email` varchar(100) NOT NULL,
    `device_key` varchar(100) NOT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`),
    UNIQUE KEY `email` (`email`),
    UNIQUE KEY `device_key` (`device_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$pdo->exec("CREATE TABLE IF NOT EXISTS `verify_codes` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `email` varchar(100) NOT NULL,
    `code` varchar(10) NOT NULL,
    `type` enum('register','reset') NOT NULL,
    `expires_at` datetime NOT NULL,
    `used` tinyint(1) DEFAULT 0,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_email_type` (`email`, `type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ============ 检查并维护管理员账户 ============
$admin_check = $pdo->prepare("SELECT id FROM users WHERE username = '泽峰'");
$admin_check->execute();
if (!$admin_check->fetch()) {
    // 若存在旧 admin 账号，则改名为 泽峰 并重置密码
    $old_admin = $pdo->prepare("SELECT id FROM users WHERE username = 'admin'");
    $old_admin->execute();
    if ($old_admin->fetch()) {
        $new_password = password_hash('dzza13366', PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET username = '泽峰', password = ? WHERE username = 'admin'")->execute([$new_password]);
    } else {
        // 创建默认管理员账户
        $admin_password = password_hash('dzza13366', PASSWORD_DEFAULT);
        $admin_email = 'admin@fanwu.com';
        $admin_device_key = 'dev_' . bin2hex(random_bytes(8));
        
        $create_admin = $pdo->prepare("INSERT INTO users (username, password, email, device_key) VALUES (?, ?, ?, ?)");
        $create_admin->execute(['泽峰', $admin_password, $admin_email, $admin_device_key]);
    }
}

// ============ 新增：检查并添加缺失的列 ============
try {
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `api_key` varchar(64) DEFAULT NULL");
} catch (Exception $e) {}

try {
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `build_count` int(11) DEFAULT 0");
} catch (Exception $e) {}

try {
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `module_url` varchar(500) DEFAULT NULL");
} catch (Exception $e) {}

try {
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `binary_url` varchar(500) DEFAULT NULL");
} catch (Exception $e) {}
?>