<?php
session_start();
require_once 'db.php';
require_once 'Mailer.php';

$error = '';
$success = '';
$step = 1; // 1=验证身份, 2=重置密码官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl

// 获取验证码
if (isset($_POST['get_code'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    
    if (empty($username) || empty($email)) {
        $error = '请填写用户名和邮箱';
    } else {
        // 验证用户名和邮箱匹配
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND email = ?");
        $stmt->execute([$username, $email]);
        $user = $stmt->fetch();
        
        if (!$user) {
            $error = '用户名和邮箱不匹配';
        } elseif (isset($_SESSION['reset_code_time']) && time() - $_SESSION['reset_code_time'] < 60) {
            $remaining = 60 - (time() - $_SESSION['reset_code_time']);
            $error = "请等待 {$remaining} 秒后再获取验证码";
        } else {
            $code = Mailer::generateCode();
            
            $pdo->prepare("DELETE FROM verify_codes WHERE email = ? AND type = 'reset'")->execute([$email]);
            $stmt = $pdo->prepare("INSERT INTO verify_codes (email, code, type, expires_at) VALUES (?, ?, 'reset', DATE_ADD(NOW(), INTERVAL 10 MINUTE))");
            $stmt->execute([$email, $code]);
            
            $mailer = new Mailer();
            if ($mailer->sendResetCode($email, $code)) {
                $_SESSION['reset_code_time'] = time();
                $_SESSION['reset_username'] = $username;
                $_SESSION['reset_email'] = $email;
                $success = '验证码已发送，请查收邮件';
            } else {
                $error = '邮件发送失败';
            }
        }
    }
}

// 验证并进入重置步骤
if (isset($_POST['verify'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $code = trim($_POST['code']);
    
    $stmt = $pdo->prepare("SELECT * FROM verify_codes WHERE email = ? AND code = ? AND type = 'reset' AND used = 0 AND expires_at > NOW() ORDER BY id DESC LIMIT 1");
    $stmt->execute([$email, $code]);
    $verify = $stmt->fetch();
    
    if (!$verify) {
        $error = '验证码错误或已过期';
    } else {
        $pdo->prepare("UPDATE verify_codes SET used = 1 WHERE id = ?")->execute([$verify['id']]);
        $_SESSION['reset_username'] = $username;
        $_SESSION['reset_email'] = $email;
        $_SESSION['reset_verified'] = true;
        $step = 2;
    }
}

// 重置密码
if (isset($_POST['reset'])) {
    if (!isset($_SESSION['reset_verified']) || !$_SESSION['reset_verified']) {
        $error = '请先完成验证';
        $step = 1;
    } else {
        $password = $_POST['password'];
        $password2 = $_POST['password2'];
        
        if (strlen($password) < 6) {
            $error = '密码长度至少6位';
            $step = 2;
        } elseif ($password !== $password2) {
            $error = '两次密码不一致';
            $step = 2;
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = ? AND email = ?");
            $stmt->execute([$hashed, $_SESSION['reset_username'], $_SESSION['reset_email']]);
            
            unset($_SESSION['reset_verified'], $_SESSION['reset_username'], $_SESSION['reset_email']);
            $success = '密码重置成功！<a href="login.php">点击登录</a>';
            $step = 1;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>泽峰远控 - 找回密码</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .form-box {
            max-width: 420px;
            margin: 60px auto;
            background: #fff;
            border-radius: 16px;
            padding: 35px 30px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        .form-box h2 { text-align: center; color: #2d3436; margin-bottom: 6px; }
        .form-box .desc { text-align: center; color: #888; font-size: 0.85em; margin-bottom: 25px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-weight: 600; color: #555; margin-bottom: 6px; font-size: 0.85em; }
        .form-group input {
            width: 100%;
            padding: 12px 14px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 0.95em;
            outline: none;
            transition: border-color 0.2s;
            box-sizing: border-box;
        }
        .form-group input:focus { border-color: #6c5ce7; }
        .code-row { display: flex; gap: 10px; }
        .code-row input { flex: 1; }
        .code-btn {
            white-space: nowrap;
            padding: 12px 16px;
            background: #6c5ce7;
            color: #fff;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 0.85em;
            font-weight: 600;
        }
        .code-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .alert { padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 0.85em; text-align: center; }
        .alert-error { background: #ffeaea; color: #c0392b; }
        .alert-success { background: #d4fceb; color: #007a5e; }
        .submit-btn {
            width: 100%;
            padding: 14px;
            background: #6c5ce7;
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
        }
        .submit-btn:hover { opacity: 0.9; }
        .link-text { text-align: center; margin-top: 16px; font-size: 0.85em; color: #888; }
        .link-text a { color: #6c5ce7; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="form-box">
        <h2>🔑 找回密码</h2>
        <p class="desc">验证你的绑定邮箱以重置密码</p>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($step == 1): ?>
            <form method="POST">
                <div class="form-group">
                    <label>用户名</label>
                    <input type="text" name="username" placeholder="请输入用户名" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>绑定邮箱</label>
                    <div class="code-row">
                        <input type="email" name="email" placeholder="请输入绑定时使用的邮箱" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        <button type="submit" name="get_code" class="code-btn" id="codeBtn">获取验证码</button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>验证码</label>
                    <input type="text" name="code" placeholder="输入6位验证码" maxlength="6" required>
                </div>
                
                <button type="submit" name="verify" class="submit-btn">验证身份</button>
            </form>
        <?php else: ?>
            <form method="POST">
                <div class="form-group">
                    <label>新密码</label>
                    <input type="password" name="password" placeholder="至少6位" required>
                </div>
                
                <div class="form-group">
                    <label>确认新密码</label>
                    <input type="password" name="password2" placeholder="再次输入" required>
                </div>
                
                <button type="submit" name="reset" class="submit-btn">重置密码</button>
            </form>
        <?php endif; ?>
        
        <p class="link-text"><a href="login.php">← 返回登录</a></p>
    </div>
    
    <script>
    var cooldown = <?php echo isset($_SESSION['reset_code_time']) ? max(0, 60 - (time() - $_SESSION['reset_code_time'])) : 0; ?>;
    var btn = document.getElementById('codeBtn');
    
    function updateCooldown() {
        if (cooldown > 0) {
            btn.disabled = true;
            btn.textContent = cooldown + '秒后重试';
            cooldown--;
            setTimeout(updateCooldown, 1000);
        } else {
            btn.disabled = false;
            btn.textContent = '获取验证码';
        }
    }
    if (cooldown > 0) updateCooldown();
    </script>
</body>
</html>