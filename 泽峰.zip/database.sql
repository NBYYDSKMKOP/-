-- ============================================
-- 安逸远控 - 数据表一键创建脚本
-- 执行前请先选择或创建数据库
-- ============================================

-- ============================================
-- 1. 删除旧表（如果有）
-- ============================================
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `ads`;
DROP TABLE IF EXISTS `vip_cards`;
DROP TABLE IF EXISTS `verify_codes`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- 2. 创建 users 用户表
-- ============================================
CREATE TABLE `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL,
    `password` varchar(255) NOT NULL,
    `email` varchar(100) NOT NULL,
    `device_key` varchar(100) NOT NULL,
    `api_key` varchar(64) DEFAULT NULL,
    `build_count` int(11) DEFAULT 0,
    `module_url` varchar(500) DEFAULT NULL,
    `binary_url` varchar(500) DEFAULT NULL,
    `vip_level` enum('free','normal','advanced') DEFAULT 'free',
    `vip_expire` datetime DEFAULT NULL,
    `device_notes` text,
    `theme` varchar(20) DEFAULT 'gradient',
    `ads_enabled` tinyint(1) DEFAULT 1,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `username` (`username`),
    UNIQUE KEY `email` (`email`),
    UNIQUE KEY `device_key` (`device_key`),
    UNIQUE KEY `api_key` (`api_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 3. 创建 verify_codes 验证码表
-- ============================================
CREATE TABLE `verify_codes` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `email` varchar(100) NOT NULL,
    `code` varchar(10) NOT NULL,
    `type` enum('register','reset') NOT NULL,
    `expires_at` datetime NOT NULL,
    `used` tinyint(1) DEFAULT 0,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_email_type` (`email`, `type`),
    INDEX `idx_code` (`code`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 4. 创建 vip_cards VIP卡密表
-- ============================================
CREATE TABLE `vip_cards` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `card_key` varchar(32) NOT NULL,
    `type` enum('day','week','month','permanent') NOT NULL,
    `level` enum('normal','advanced') NOT NULL,
    `status` enum('unused','used') DEFAULT 'unused',
    `used_by` int(11) DEFAULT NULL,
    `used_at` datetime DEFAULT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `card_key` (`card_key`),
    INDEX `idx_status` (`status`),
    INDEX `idx_used_by` (`used_by`),
    FOREIGN KEY (`used_by`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 5. 创建 ads 广告/公告表
-- ============================================
CREATE TABLE `ads` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title` varchar(255) DEFAULT NULL,
    `content` text,
    `type` varchar(50) DEFAULT 'text',
    `status` tinyint(1) DEFAULT 1,
    `sort_order` int(11) DEFAULT 0,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- 6. 插入默认数据
-- ============================================





-- ============================================
-- 7. 验证
-- ============================================
SELECT 
    '✅ 数据表创建完成！' AS '状态',
    (SELECT COUNT(*) FROM `users`) AS '用户数',
    (SELECT COUNT(*) FROM `ads`) AS '公告数';

-- ============================================
-- 完成
-- ============================================