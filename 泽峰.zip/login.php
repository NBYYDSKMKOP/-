//官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
<?php
session_start();
require_once 'db.php';

$error = '';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = '请填写用户名和密码';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['device_key'] = $user['device_key'];
            header('Location: console.php');
            exit;
        } else {
            $error = '用户名或密码错误';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>泽峰远控 - 登录</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { -webkit-text-size-adjust: 100%; text-size-adjust: 100%; }
        html { height: 100%; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            min-height: 100vh;
            min-height: 100dvh;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
            background:
                radial-gradient(720px 420px at 88% -6%, rgba(124, 92, 255, 0.42), transparent 65%),
                radial-gradient(640px 380px at 6% 112%, rgba(0, 212, 255, 0.38), transparent 65%),
                radial-gradient(500px 340px at 46% 46%, rgba(255, 88, 196, 0.20), transparent 62%),
                radial-gradient(400px 300px at 18% 8%, rgba(0, 255, 163, 0.14), transparent 60%),
                linear-gradient(175deg, #070b16 0%, #0a1224 55%, #06090f 100%);
            background-attachment: fixed;
        }
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
            background-size: 36px 36px;
            pointer-events: none;
        }
        .form-box {
            max-width: 400px;
            width: 100%;
            margin: 0 auto;
            position: relative;
            z-index: 1;
            border-radius: 28px;
            padding: 36px 30px 32px;
            background: linear-gradient(155deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.06) 38%, rgba(255,255,255,0.02) 100%);
            border: 1px solid rgba(255,255,255,0.22);
            backdrop-filter: blur(26px) saturate(170%);
            -webkit-backdrop-filter: blur(26px) saturate(170%);
            box-shadow:
                0 24px 60px rgba(0, 0, 0, 0.45),
                0 2px 8px rgba(255, 255, 255, 0.06),
                inset 0 1px 0 rgba(255, 255, 255, 0.35),
                inset 0 -1px 0 rgba(255, 255, 255, 0.08);
        }
        .form-box::before {
            content: '';
            position: absolute;
            inset: 1px;
            border-radius: 27px;
            background: linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.03) 34%, rgba(255,255,255,0) 55%);
            pointer-events: none;
        }
        .form-box::after {
            content: '';
            position: absolute;
            top: -1px;
            left: 50%;
            transform: translateX(-50%);
            width: 55%;
            height: 2px;
            border-radius: 2px;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.9), transparent);
            filter: blur(0.5px);
        }
        .form-box h2 { text-align: center; color: #fff; margin-bottom: 8px; font-size: 1.45em; font-weight: 700; letter-spacing: 1px; text-shadow: 0 2px 16px rgba(0, 212, 255, 0.35); }
        .form-box .desc { text-align: center; color: rgba(255,255,255,0.6); font-size: 0.85em; margin-bottom: 26px; }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-weight: 600; color: rgba(255,255,255,0.78); margin-bottom: 7px; font-size: 0.85em; letter-spacing: 0.3px; }
        .form-group input {
            width: 100%;
            padding: 13px 16px;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.16);
            border-radius: 15px;
            font-size: 0.95em;
            color: #f2f7ff;
            outline: none;
            transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
            box-sizing: border-box;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        .form-group input::placeholder { color: rgba(255,255,255,0.35); }
        .form-group input:focus {
            border-color: rgba(0, 212, 255, 0.65);
            background: rgba(255,255,255,0.1);
            box-shadow: 0 0 0 4px rgba(0, 212, 255, 0.14), inset 0 1px 0 rgba(255,255,255,0.15);
        }
        .alert-error { background: rgba(255,84,112,0.12); color: #ff8fa3; border: 1px solid rgba(255,84,112,0.3); padding: 12px; border-radius: 14px; margin-bottom: 16px; font-size: 0.85em; text-align: center; backdrop-filter: blur(8px); }
        .submit-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.95), rgba(124, 92, 255, 0.95));
            color: #fff;
            border: none;
            border-radius: 15px;
            font-size: 1em;
            font-weight: 700;
            letter-spacing: 2px;
            cursor: pointer;
            box-shadow: 0 8px 28px rgba(0, 212, 255, 0.35), inset 0 1px 0 rgba(255,255,255,0.35);
            transition: all 0.2s;
        }
        .submit-btn:hover { opacity: 0.92; transform: translateY(-2px); box-shadow: 0 12px 34px rgba(0, 212, 255, 0.45), inset 0 1px 0 rgba(255,255,255,0.35); }
        .submit-btn:active { transform: translateY(0) scale(0.98); }
        .forgot { text-align: right; margin-top: 6px; }
        .forgot a { font-size: 0.8em; color: rgba(255,255,255,0.55); text-decoration: none; }
        .forgot a:hover { color: #00d4ff; }
        .link-text { text-align: center; margin-top: 18px; font-size: 0.85em; color: rgba(255,255,255,0.6); }
        .link-text a { color: #00d4ff; text-decoration: none; font-weight: 600; }
        .link-text a:hover { text-shadow: 0 0 12px rgba(0, 212, 255, 0.6); }

        @media (max-width: 480px) {
            body { padding: 14px; }
            .form-box {
                padding: 30px 22px 28px;
                margin: 0;
                border-radius: 24px;
                width: 100%;
                max-width: 100%;
            }
            .form-box::before { border-radius: 23px; }
            .form-box h2 { font-size: 1.3em; }
            .form-group label { font-size: 0.9em; }
            .form-group input {
                padding: 14px 16px;
                font-size: 16px;
                -webkit-appearance: none;
                appearance: none;
            }
            .submit-btn { padding: 15px; font-size: 1em; }
            .alert-error { font-size: 0.9em; }
            .forgot a { font-size: 0.85em; }
            .link-text { font-size: 0.9em; }
        }
    </style>
</head>
<body>
    <div class="form-box">
        <h2>🔐 登录</h2>
        <p class="desc">泽峰远控 · 值得信赖的远控</p>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" placeholder="请输入用户名" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" placeholder="请输入密码" required>
                <div class="forgot">
                    <a href="forgot_password.php">忘记密码了？点我找回</a>
                </div>
            </div>
            
            <button type="submit" name="login" class="submit-btn">登 录</button>
        </form>
        
        <p class="link-text">还没有账号？<a href="register.php">立即注册</a></p>
    </div>
</body>
</html>
