<?php
class Mailer {
    private $smtpHost = 'smtp.qq.com';
    private $smtpPort = 465;
    private $smtpUser = '3418057278@qq.com';
    private $smtpPass = 'mypgnfglfzbfchji';
    private $fromName = '官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl';

    public function sendRegisterCode($toEmail, $code) {
        $subject = '官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl - 注册验证码';
        $content = "官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl\n\n您的注册验证码为：{$code}\n\n请在10分钟内完成注册。";
        return $this->send($toEmail, $subject, $content);
    }

    public function sendResetCode($toEmail, $code) {
        $subject = '安逸远控 - 找回密码验证码';
        $content = "安逸远控\n\n您的找回密码验证码为：{$code}，请勿透露给他人。\n\n请在10分钟内完成验证。";
        return $this->send($toEmail, $subject, $content);
    }

    private function send($toEmail, $subject, $content) {
        $socket = fsockopen('ssl://' . $this->smtpHost, $this->smtpPort, $errno, $errstr, 30);
        if (!$socket) {
            error_log("SMTP连接失败: $errstr ($errno)");
            return false;
        }
        stream_set_timeout($socket, 30);

        $this->readResponse($socket);
        fputs($socket, "EHLO localhost\r\n");
        $this->readMultiResponse($socket);
        fputs($socket, "AUTH LOGIN\r\n");
        $this->readResponse($socket);
        fputs($socket, base64_encode($this->smtpUser) . "\r\n");
        $this->readResponse($socket);
        fputs($socket, base64_encode($this->smtpPass) . "\r\n");
        $response = $this->readResponse($socket);

        if (substr($response, 0, 3) !== '235') {
            error_log("SMTP认证失败: $response");
            fclose($socket);
            return false;
        }

        fputs($socket, "MAIL FROM: <{$this->smtpUser}>\r\n");
        $this->readResponse($socket);
        fputs($socket, "RCPT TO: <{$toEmail}>\r\n");
        $this->readResponse($socket);
        fputs($socket, "DATA\r\n");
        $this->readResponse($socket);

        $headers = [
            "From: {$this->fromName} <{$this->smtpUser}>",
            "To: {$toEmail}",
            "Subject: " . $this->encodeSubject($subject),
            "MIME-Version: 1.0",
            "Content-Type: text/plain; charset=UTF-8",
            "Date: " . date('r')
        ];
        $message = implode("\r\n", $headers) . "\r\n\r\n" . $content . "\r\n.";
        fputs($socket, $message . "\r\n");
        $response = $this->readResponse($socket);

        fputs($socket, "QUIT\r\n");
        fclose($socket);
        return substr($response, 0, 3) === '250';
    }

    private function readResponse($socket) {
        return fgets($socket, 515);
    }

    private function readMultiResponse($socket) {
        while ($line = fgets($socket, 515)) {
            if (substr($line, 3, 1) === ' ') break;
        }
    }

    private function encodeSubject($subject) {
        return '=?UTF-8?B?' . base64_encode($subject) . '?=';
    }

    public static function generateCode($length = 6) {
        return str_pad(random_int(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
    }
}
?>