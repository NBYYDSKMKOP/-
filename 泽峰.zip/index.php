<?php
session_start();
$is_logged = isset($_SESSION['user_id']);
$username = $is_logged ? htmlspecialchars($_SESSION['username']) : '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> - 值得信赖的稳定远控</title>
    <style>
        :root {
            --bg: #05080f;
            --surface: #0c1322;
            --surface-2: #101a2e;
            --border: rgba(0, 212, 255, 0.12);
            --border-glow: rgba(0, 212, 255, 0.35);
            --text: #e6f1ff;
            --text-secondary: #7f93b5;
            --accent: #00d4ff;
            --accent-2: #7c5cff;
            --accent-glow: rgba(0, 212, 255, 0.25);
            --green: #00ffa3;
            --green-glow: rgba(0, 255, 163, 0.25);
            --red: #ff5470;
            --card-radius: 16px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            -webkit-text-size-adjust: 100%;
            text-size-adjust: 100%;
        }

        body {
            background-color: var(--bg);
            background-image:
                linear-gradient(rgba(0, 212, 255, 0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 212, 255, 0.04) 1px, transparent 1px);
            background-size: 32px 32px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
            color: var(--text);
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
            overflow-x: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background:
                radial-gradient(600px 400px at 80% -10%, rgba(124, 92, 255, 0.14), transparent 70%),
                radial-gradient(500px 350px at 10% 110%, rgba(0, 212, 255, 0.12), transparent 70%);
            pointer-events: none;
            z-index: 0;
        }

        body::after {
            content: '';
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: repeating-linear-gradient(0deg, transparent 0px, transparent 3px, rgba(0, 0, 0, 0.08) 4px);
            pointer-events: none;
            z-index: 0;
        }

        .site-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
            position: relative;
            z-index: 1;
        }

        /* ========== 导航栏 ========== */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 0;
            border-bottom: 1px solid var(--border);
        }
        .logo-area {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .logo-icon {
            width: 42px;
            height: 42px;
            background: linear-gradient(135deg, var(--accent), var(--accent-2));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #05080f;
            box-shadow: 0 0 18px var(--accent-glow);
        }
        .logo-text {
            font-size: 22px;
            font-weight: 600;
            letter-spacing: 2px;
            color: #fff;
            text-shadow: 0 0 14px rgba(0, 212, 255, 0.45);
        }

        /* ========== 设备类型变量 ========== */
        body.is-phone {
            --feature-cols: 1;
            --feature-gap: 12px;
            --hero-padding: 40px 16px;
        }
        body.is-tablet {
            --feature-cols: 2;
            --feature-gap: 16px;
            --hero-padding: 50px 30px;
        }
        body.is-desktop {
            --feature-cols: 3;
            --feature-gap: 24px;
            --hero-padding: 60px 40px;
        }

        .site-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px;
            position: relative;
            z-index: 1;
        }

        .nav-links {
            display: flex;
            gap: 32px;
            align-items: center;
        }
        .nav-links a {
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 14px;
            letter-spacing: 0.5px;
            transition: color 0.25s;
            position: relative;
        }
        .nav-links a:hover,
        .nav-links a.active {
            color: #fff;
        }
        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--accent);
            box-shadow: 0 0 8px var(--accent);
            transition: width 0.3s;
        }
        .nav-links a:hover::after,
        .nav-links a.active::after {
            width: 100%;
        }
        .nav-status {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            color: var(--text-secondary);
        }
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--green);
            box-shadow: 0 0 8px var(--green-glow);
            animation: pulse-dot 2s infinite;
        }
        @keyframes pulse-dot {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.4; }
        }

        /* ========== Hero ========== */
        .hero {
            text-align: center;
            padding: var(--hero-padding, 60px 40px);
            position: relative;
        }
        .hero::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(0,212,255,0.10) 0%, rgba(124,92,255,0.06) 40%, transparent 70%);
            pointer-events: none;
        }
        .hero-badge {
            display: inline-block;
            background: rgba(0,255,163,0.08);
            border: 1px solid rgba(0,255,163,0.35);
            color: var(--green);
            padding: 6px 20px;
            border-radius: 20px;
            font-size: 13px;
            letter-spacing: 1px;
            margin-bottom: 24px;
            box-shadow: 0 0 20px rgba(0,255,163,0.12);
            animation: fadeUp 0.8s ease-out;
        }
        .hero-title {
            font-size: clamp(2rem, 6vw, 4rem);
            font-weight: 700;
            color: #fff;
            letter-spacing: 4px;
            margin-bottom: 12px;
            text-shadow: 0 0 30px rgba(0, 212, 255, 0.4);
            animation: fadeUp 0.8s ease-out 0.15s both;
        }
        .hero-subtitle {
            font-size: 1.1rem;
            color: var(--text-secondary);
            letter-spacing: 3px;
            margin-bottom: 32px;
            animation: fadeUp 0.8s ease-out 0.3s both;
        }
        .hero-btn-group {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
            animation: fadeUp 0.8s ease-out 0.45s both;
        }
        .btn {
            padding: 14px 36px;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 1px;
            cursor: pointer;
            border: none;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-2));
            color: #05080f;
            box-shadow: 0 4px 24px var(--accent-glow);
            border: 1px solid rgba(0, 212, 255, 0.5);
        }
        .btn-outline {
            background: transparent;
            color: var(--text);
            border: 2px solid rgba(0, 212, 255, 0.4);
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 34px var(--accent-glow);
        }
        .btn-outline:hover {
            border-color: var(--accent);
            box-shadow: 0 8px 30px rgba(0, 212, 255, 0.15);
        }
        .hero-welcome {
            margin-top: 16px;
            color: var(--text-secondary);
            font-size: 14px;
            animation: fadeUp 0.8s ease-out 0.6s both;
        }
        .hero-welcome strong {
            color: #fff;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ========== 流线动画 ========== */
        .stream-container {
            width: 100%;
            height: 120px;
            margin: 20px 0 40px;
            position: relative;
            overflow: hidden;
            border-top: 1px solid var(--border);
            border-bottom: 1px solid var(--border);
        }
        .stream-line {
            position: absolute;
            width: 200%;
            height: 100%;
            background: repeating-linear-gradient(90deg, transparent, transparent 30px, rgba(0,212,255,0.05) 30px, rgba(0,212,255,0.05) 60px);
            animation: streamMove 20s linear infinite;
        }
        .stream-line:nth-child(2) {
            top: 20px;
            animation-duration: 28s;
            animation-delay: -5s;
            opacity: 0.5;
        }
        .stream-line:nth-child(3) {
            top: 40px;
            animation-duration: 15s;
            animation-delay: -2s;
            opacity: 0.3;
        }
        @keyframes streamMove {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }

        /* ========== 核心标语 ========== */
        .core-slogan {
            text-align: center;
            margin: 50px 0 40px;
            animation: fadeUp 0.8s ease-out 0.6s both;
        }
        .core-slogan h2 {
            font-size: clamp(1.5rem, 4vw, 2.5rem);
            font-weight: 600;
            letter-spacing: 6px;
            color: #fff;
            text-shadow: 0 0 20px rgba(0, 212, 255, 0.3);
        }
        .core-slogan .sub {
            color: var(--text-secondary);
            margin-top: 12px;
            font-size: 0.95rem;
            letter-spacing: 2px;
        }

        /* ========== 特性卡片 ========== */
        .features {
            display: grid;
            grid-template-columns: repeat(var(--feature-cols, 3), 1fr);
            gap: var(--feature-gap, 24px);
            max-width: 860px;
            margin: 0 auto 60px;
            animation: fadeUp 0.8s ease-out 0.75s both;
        }
        .feature-card {
            background: linear-gradient(180deg, var(--surface), var(--surface-2));
            border: 1px solid var(--border);
            border-radius: var(--card-radius);
            padding: 32px 20px;
            text-align: center;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(8px);
        }
        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
            opacity: 0;
            transition: opacity 0.3s;
        }
        .feature-card:hover {
            border-color: var(--border-glow);
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 212, 255, 0.12);
        }
        .feature-card:hover::before {
            opacity: 1;
        }
        .feature-icon {
            font-size: 2.8rem;
            margin-bottom: 14px;
        }
        .feature-card h3 {
            color: #fff;
            font-size: 1.1rem;
            margin-bottom: 8px;
            font-weight: 600;
        }
        .feature-card p {
            color: var(--text-secondary);
            font-size: 0.85rem;
            line-height: 1.6;
        }

        /* ========== 页脚 ========== */
        .footer {
            text-align: center;
            padding: 40px 0;
            border-top: 1px solid var(--border);
            color: #5a6b8a;
            font-size: 0.85rem;
            letter-spacing: 2px;
        }

        /* ========== 设备标签 ========== */
        .device-tag {
            position: fixed;
            bottom: 16px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--surface);
            border: 1px solid var(--border);
            color: var(--text-secondary);
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 11px;
            letter-spacing: 1px;
            z-index: 99;
            pointer-events: none;
            opacity: 0.7;
        }

        /* ========== 响应式微调 ========== */
        @media (max-width: 768px) {
            .site-wrapper {
                padding: 0 16px;
            }
            .navbar {
                flex-wrap: wrap;
                gap: 10px;
                padding: 14px 0;
            }
            .nav-links {
                order: 3;
                width: 100%;
                justify-content: center;
                gap: 28px;
                padding-top: 6px;
                border-top: 1px solid var(--border);
            }
            .logo-text {
                font-size: 18px;
                letter-spacing: 1px;
            }
            .nav-status {
                font-size: 12px;
            }
            .feature-card {
                padding: 24px 16px;
            }
            .hero-title {
                letter-spacing: 2px;
            }
            .hero-subtitle {
                letter-spacing: 1px;
                font-size: 0.95rem;
            }
            .core-slogan h2 {
                letter-spacing: 3px;
            }
        }
        @media (max-width: 480px) {
            .nav-links {
                gap: 20px;
                font-size: 13px;
            }
            .logo-icon {
                width: 36px;
                height: 36px;
                font-size: 17px;
            }
            .logo-text {
                font-size: 17px;
            }
            .btn {
                padding: 12px 28px;
                font-size: 14px;
            }
            .hero-badge {
                font-size: 11px;
                padding: 4px 14px;
            }
            .hero-btn-group {
                gap: 12px;
            }
            .stream-container {
                height: 90px;
            }
            .device-tag {
                font-size: 10px;
                padding: 4px 12px;
            }
        }
    </style>
</head>
<body class="is-desktop">
    <div class="site-wrapper">
        <!-- 导航栏 -->
        <nav class="navbar">
            <div class="logo-area">
                <div class="logo-icon">🔗</div>
                <span class="logo-text">泽峰远控</span>
            </div>
            <div class="nav-links">
                <a href="index.php" class="active">首页</a>
                <a href="console.php">控制台</a>
            </div>
            <div class="nav-status">
                <span class="status-dot"></span>
                <span>服务运行中</span>
            </div>
        </nav>

        <!-- Hero 区域 -->
        <section class="hero">
            <div class="hero-badge">🔒 安全 · 稳定  </div>
            <h1 class="hero-title">泽峰远控</h1>
            <p class="hero-subtitle">值得信赖的稳定远控</p>

            <?php if ($is_logged): ?>
                <div class="hero-btn-group">
                    <a href="console.php" class="btn btn-primary">进入控制台</a>
                    <a href="logout.php" class="btn btn-outline">退出登录</a>
                </div>
                <p class="hero-welcome">
                    欢迎回来，<strong><?php echo $username; ?></strong>
                </p>
            <?php else: ?>
                <div class="hero-btn-group">
                    <a href="login.php" class="btn btn-primary">立即登录</a>
                    <a href="register.php" class="btn btn-outline">注册账号</a>
                </div>
            <?php endif; ?>
        </section>

        <!-- 流线动画 -->
        <div class="stream-container">
            <div class="stream-line"></div>
            <div class="stream-line"></div>
            <div class="stream-line"></div>
        </div>

        <!-- 核心标语 -->
        <section class="core-slogan">
            <h2>专属密钥 · 安全远控</h2>
            <p class="sub">极简 · 安全 · 实时响应</p>
        </section>

        <!-- 特性卡片 -->
        <div class="features">
            <div class="feature-card">
                <div class="feature-icon">🔑</div>
                <h3>专属密钥</h3>
                <p>每个账号独立密钥<br>设备数据安全隔离</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📱</div>
                <h3>多设备管理</h3>
                <p>一台设备一个密钥<br>轻松管理所有设备</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">⚡</div>
                <h3>实时响应</h3>
                <p>命令秒级送达<br>结果即时回传</p>
            </div>
        </div>

        <!-- 页脚 -->
        <footer class="footer">
            © 2025 泽峰工作室从凡吾接手运营
        </footer>
    </div>

    <!-- 设备标识（调试用，上线可删除） -->
    <div class="device-tag" id="deviceTag">桌面端</div>

    <script>
        /**
         * 设备自适应检测系统
         * 平板/手机仅切换布局类名，由 CSS 媒体查询完成响应式排版
         */
        (function() {
            var body = document.body;
            var deviceTag = document.getElementById('deviceTag');
            
            function detectAndApply() {
                var width = window.innerWidth;
                var ua = navigator.userAgent.toLowerCase();
                var isMobile = /iphone|ipod|android.*mobile|windows phone/.test(ua);
                var isTablet = /ipad|android(?!.*mobile)|tablet/.test(ua);
                
                // 移除所有设备类
                body.classList.remove('is-phone', 'is-tablet', 'is-desktop');
                
                if (isMobile || width < 600) {
                    // 手机：单列布局
                    body.classList.add('is-phone');
                    if (deviceTag) deviceTag.textContent = '📱 手机端';
                } else if (isTablet || (width >= 600 && width <= 1024)) {
                    // 平板：双列布局
                    body.classList.add('is-tablet');
                    if (deviceTag) deviceTag.textContent = '📋 平板端';
                } else {
                    // 桌面：三列布局
                    body.classList.add('is-desktop');
                    if (deviceTag) deviceTag.textContent = '🖥️ 桌面端';
                }
            }
            
            // 初始检测
            detectAndApply();
            
            // 监听窗口变化
            var resizeTimer;
            window.addEventListener('resize', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(detectAndApply, 250);
            });
            
            // 监听屏幕方向变化（移动端）
            window.addEventListener('orientationchange', function() {
                setTimeout(detectAndApply, 300);
            });
            
            // DOM 加载完成后确保应用
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', detectAndApply);
            }
        })();
    </script>
</body>
</html>