<?php
/**
 * 文件上传接口
 * 接收客户端上传的文件，存储到临时目录
 * 只有对应用户能访问官网:泽峰.top    更多公益开源资源分享 \n TG@ASDK886 QQ1063167389\n各大源码免费分享 网络搜集 打破信息差    官方频道:https://t.me/+FDfQgP9RFdljYjFl
 */

error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

// 检查请求方法
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => '仅支持POST请求'], JSON_UNESCAPED_UNICODE);
    exit;
}

$token = $_POST['token'] ?? '';

if (empty($token)) {
    echo json_encode(['success' => false, 'error' => '缺少上传令牌'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 验证令牌
$upload_tasks_file = __DIR__ . '/uploads/upload_tasks.json';

if (!file_exists($upload_tasks_file)) {
    echo json_encode(['success' => false, 'error' => '上传任务不存在'], JSON_UNESCAPED_UNICODE);
    exit;
}

$tasks = json_decode(file_get_contents($upload_tasks_file), true) ?? [];

if (!isset($tasks[$token])) {
    echo json_encode(['success' => false, 'error' => '无效的上传令牌'], JSON_UNESCAPED_UNICODE);
    exit;
}

$task = $tasks[$token];

// 检查任务是否过期
if (time() > $task['expires_at']) {
    $tasks[$token]['status'] = 'failed';
    $tasks[$token]['error'] = '上传超时';
    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
    echo json_encode(['success' => false, 'error' => '上传已过期'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 检查任务状态
if ($task['status'] !== 'pending') {
    echo json_encode(['success' => false, 'error' => '任务状态异常: ' . $task['status']], JSON_UNESCAPED_UNICODE);
    exit;
}

// 检查文件是否上传
if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    $error_msg = '文件上传失败';
    if (isset($_FILES['file'])) {
        switch ($_FILES['file']['error']) {
            case UPLOAD_ERR_INI_SIZE: $error_msg = '文件超过php.ini限制'; break;
            case UPLOAD_ERR_FORM_SIZE: $error_msg = '文件超过表单限制'; break;
            case UPLOAD_ERR_PARTIAL: $error_msg = '文件部分上传'; break;
            case UPLOAD_ERR_NO_FILE: $error_msg = '没有文件被上传'; break;
            case UPLOAD_ERR_NO_TMP_DIR: $error_msg = '缺少临时目录'; break;
            case UPLOAD_ERR_CANT_WRITE: $error_msg = '无法写入磁盘'; break;
        }
    }
    
    $tasks[$token]['status'] = 'failed';
    $tasks[$token]['error'] = $error_msg;
    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
    
    echo json_encode(['success' => false, 'error' => $error_msg], JSON_UNESCAPED_UNICODE);
    exit;
}

// 文件大小限制（100MB）
$max_size = 100 * 1024 * 1024;
if ($_FILES['file']['size'] > $max_size) {
    $tasks[$token]['status'] = 'failed';
    $tasks[$token]['error'] = '文件超过100MB限制';
    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
    
    echo json_encode(['success' => false, 'error' => '文件超过100MB限制'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 创建上传目录
$upload_dir = __DIR__ . '/uploads/temp/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// 生成唯一文件名（防止冲突和泄露）
$download_token = md5($task['user_id'] . '_' . $task['device'] . '_' . time() . '_' . bin2hex(random_bytes(8)));
$original_name = basename($_FILES['file']['name']);
$ext = pathinfo($original_name, PATHINFO_EXTENSION);

// 保留原始扩展名以便下载
$stored_filename = $download_token;
if (!empty($ext)) {
    // 不修改存储文件名，保持纯token，避免扩展名泄露
}

$file_path = $upload_dir . $stored_filename;

// 移动上传文件
if (!move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
    $tasks[$token]['status'] = 'failed';
    $tasks[$token]['error'] = '文件保存失败';
    file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));
    
    echo json_encode(['success' => false, 'error' => '文件保存失败'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 保存元数据（原始文件名、用户ID等）
$meta = [
    'original_name' => $original_name,
    'user_id' => $task['user_id'],
    'device' => $task['device'],
    'file_path_on_device' => $task['file_path'],
    'uploaded_at' => time(),
    'expires_at' => time() + 60 // 1分钟后过期
];
file_put_contents($file_path . '.meta', json_encode($meta, JSON_UNESCAPED_UNICODE));

// 更新任务状态
$tasks[$token]['status'] = 'completed';
$tasks[$token]['download_token'] = $download_token;
$tasks[$token]['filename'] = $original_name;
$tasks[$token]['completed_at'] = time();

file_put_contents($upload_tasks_file, json_encode($tasks, JSON_UNESCAPED_UNICODE));

echo json_encode([
    'success' => true,
    'message' => '文件上传成功',
    'filename' => $original_name
], JSON_UNESCAPED_UNICODE);