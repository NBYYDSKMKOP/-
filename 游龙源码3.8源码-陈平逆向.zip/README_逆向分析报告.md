# 游龙工具 8.6.0 逆向分析报告

## 一、应用概述

- **包名**: com.youlong.tool
- **版本**: 8.6.0
- **架构**: 原生 Android Shell (Kotlin/Java) + WebView 加载 HTML/JS 页面
- **核心功能**: 系统工具集合（ADB、Shizuku、性能监控、广告跳过、游戏等）

## 二、加密方案完整还原

### 2.1 加密算法
- **算法**: AES/GCM/NoPadding (AES-256)
- **IV/Nonce**: 12 字节，置于密文最前面
- **认证标签**: 128 bit (GCM)
- **密文结构**: `[12字节IV][AES-GCM密文+tag]`

### 2.2 密钥派生链
```
APK签名证书 SHA-256 指纹 (32字节)
         ↓
AssetsEncryptor.e (种子 byte[])
         ↓
NativeCrypto.deriveSeedForFallback() → 16字节 seed
NativeCrypto.deriveSaltForFallback() → 16字节 salt
         ↓
key = SHA-256(seed || salt || cert_fingerprint)
```

### 2.3 证书指纹 (密钥种子)
```
SHA-256: d3d868c90dfcdfe45ffa6891ea8f2e2eb6ceb49bc63eea5fd1aad54c5d46ae2c
```

### 2.4 原生库 seed/salt 派生算法
`.rodata` 常量:
- `b` (offset 0x00): `5a3cf1278e4bd60f39a87ec415926db3`
- `a_seed` (offset 0x10): `cb47760f33bbe851e2030c21871bed43`
- `a_salt` (offset 0x40): `34a3804b065ef3590bd1884b2ff473c4`

派生公式:
```python
def derive(a, b):
    for i in range(16):
        result[i] = a[i] ^ b[i] ^ 0x3d ^ b[(i+7) % 16]
```

计算结果:
- **seed**: `a37f126b44d8910e55cc7329883af61b`
- **salt**: `5c9be42f713d8a06bc1ef74320d5689c`

### 2.5 最终 AES 密钥
```
8bac6c9a8249c0297a57b9155ede58192f8f5c6ffdb179d30c82dea8b17529c4
```

## 三、解密成果

### 3.1 加密资源文件 (38个)
所有 `assets/*.java` 文件均为 AES-GCM 加密的 HTML 网页，解密后还原为 `.html`：

| 原文件 | 解密后 | 大小 | 功能推测 |
|--------|--------|------|----------|
| index.java | index.html | 253KB | 主页/导航 |
| termux.java | termux.html | 248KB | Termux 终端 |
| VIVO.java | VIVO.html | 257KB | VIVO 适配教程 |
| shizuku.java | shizuku.html | 202KB | Shizuku 工具 |
| OPPO.java | OPPO.html | 206KB | OPPO 适配教程 |
| xiaomi.java | xiaomi.html | 199KB | 小米适配教程 |
| rongyao.java | rongyao.html | 167KB | 荣耀适配教程 |
| aiagent.java | aiagent.html | 144KB | AI 助手 |
| piaoliuping.java | piaoliuping.html | 109KB | 漂流瓶 |
| wuziqi.java | wuziqi.html | 87KB | 五子棋游戏 |
| build.java | build.html | 75KB | 构建信息 |
| pictuee.java | pictuee.html | 72KB | 图片工具 |
| mali.java | mali.html | 65KB | 性能监控 |
| paofen.java | paofen.html | 61KB | 跑分 |
| heikepro.java | heikepro.html | 43KB | 黑客工具Pro |
| ... | ... | ... | ... |

另有 `assets/_test_ai_module.js` (30KB) 为五子棋 AI 模块，明文 JS。

### 3.2 JavaScript 反混淆
所有 HTML 中的 JS 均经过 javascript-obfuscator 混淆：
- 字符串数组 + Base64 编码 + 惰性解码缓存
- 变量名 `_0x` 十六进制混淆
- 数组旋转 IIFE 保护

已完成**字符串字面量还原**（共约 9000+ 处调用替换），代码可读性大幅提升。

### 3.3 Java 源码
通过 jadx 1.5.0 反编译 classes.dex + classes2.dex：
- 关键类: `AssetsEncryptor`, `NativeCrypto`, `MainActivity`, `YouLongApp`, `SignatureVerifier`
- 服务: `AdSkipService`, `FpsMonitorService`, `PerformanceService`, `ProtectService`, `ScreenFilterService`
- 原生库: `libnativecrypto.so` (arm64-v8a / armeabi-v7a)

## 四、应用架构

```
┌─────────────────────────────────────────┐
│  YouLongApp (Application)               │
│  - 校验 APK 签名证书                     │
│  - 设置证书指纹为加密种子                 │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│  MainActivity                           │
│  - WebView 加载 index.html              │
│  - shouldInterceptRequest 解密拦截       │
│  - JavaScriptInterface 原生桥接          │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│  AssetsEncryptor                        │
│  - AES/GCM 解密 (Java fallback)         │
│  - 或调用 NativeCrypto.decrypt (原生)    │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│  libnativecrypto.so                     │
│  - 密钥派生 (seed/salt XOR变换)          │
│  - AES-GCM 加解密                        │
│  - 反调试/反Frida检测                    │
└─────────────────────────────────────────┘
```

## 五、安全机制

1. **签名绑定**: 密钥种子 = APK 签名证书指纹，重打包后密钥失效
2. **原生加密**: 核心加解密在 .so 中实现，增加逆向难度
3. **反调试**: 检测 Frida、调试器、Substrate
4. **JS 混淆**: javascript-obfuscator 多层混淆
5. **文件伪装**: 加密 HTML 以 .java 扩展名存储

## 六、文件清单

```
reverse_youlong/
├── decrypted_assets/          # 解密+反混淆后的 HTML/JS (核心交付物)
│   ├── index.html
│   ├── termux.html
│   ├── ... (共37个HTML)
│   └── _test_ai_module.js
├── jadx_output2/sources/com/youlong/  # Java 源码
├── extracted_lib/lib/         # 原生库
├── signer_cert.der            # 签名证书
├── cert_sha256_seed.bin       # 证书指纹 (密钥种子)
└── README_逆向分析报告.md      # 本文件
```

## 七、解密脚本 (Python)

```python
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# 常量
b_const = bytes.fromhex('5a3cf1278e4bd60f39a87ec415926db3')
a_seed  = bytes.fromhex('cb47760f33bbe851e2030c21871bed43')
a_salt  = bytes.fromhex('34a3804b065ef3590bd1884b2ff473c4')
cert_fp = bytes.fromhex('d3d868c90dfcdfe45ffa6891ea8f2e2eb6ceb49bc63eea5fd1aad54c5d46ae2c')

def derive(a, b):
    return bytes(a[i] ^ b[i] ^ 0x3d ^ b[(i+7)%16] for i in range(16))

seed = derive(a_seed, b_const)
salt = derive(a_salt, b_const)
key  = hashlib.sha256(seed + salt + cert_fp).digest()

def decrypt(encrypted):
    iv, ct = encrypted[:12], encrypted[12:]
    return AESGCM(key).decrypt(iv, ct, None)
```

## 八、应用功能模块详解

### 8.1 系统工具类
| 页面 | 功能 | 关键技术 |
|------|------|----------|
| shizuku.html | Shizuku 命令执行终端 | Shizuku API + AI 辅助命令生成 |
| OPPO/VIVO/xiaomi/rongyao.html | 各品牌 Shizuku 适配教程 | 同上，品牌定制引导 |
| adb.html | ADB 调试工具 | 远程页面加载 |
| unzip.html | ZIP 解压工具 | JSZip |
| pictuee.html | 图片工具箱 | Canvas 旋转/翻转/裁剪 |
| tiaoguo.html | 广告跳过管理 | 无障碍服务配置 |
| shield_protect.html | 安全护盾/应用风险扫描 | 权限管控 + 应用黑名单 |
| 2weima.html | 二维码生成器 | qrcode.js |
| zizhi.html | 激活码验证 | 远程密钥校验 |

### 8.2 AI 功能类
| 页面 | 功能 | API |
|------|------|-----|
| aiagent.html | AI 全自动助手 | Agnes AI / NVIDIA |
| termux.html | 金龙AI 对话 | Agnes AI + TTS |
| wuziqi.html | 五子棋 AI 对弈 | DeepSeek API |

### 8.3 娱乐游戏类
| 页面 | 功能 |
|------|------|
| arcade.html | 怀旧打砖块 |
| mali.html | 超级玛丽 |
| wuziqi.html | 智弈五子棋（含排行榜） |
| piaoliuping.html | 漂流瓶社交 |
| naiwa.html | 奶蛙动画 |
| video_player.html | 奶蛙小剧场 |
| alipay.html | 支付宝到账音效 |
| danmu.html | 手持弹幕 |

### 8.4 生活实用类
| 页面 | 功能 |
|------|------|
| huangl.html | 万年历黄历择吉 |
| history.html | 历史上的今天 |
| fenbei.html | 分贝测试+记录 |
| suimian.html | 睡眠监测 |
| dailyyou.html | 心情日记 |
| time.html | 生命年龄计算器 |
| qq.html | QQ空间信息查询 |

### 8.5 装逼/黑客类
| 页面 | 功能 |
|------|------|
| heike.html | 渗透测试终端模拟器 |
| heikepro.html | Hacker Simulator（需激活码） |
| paofen.html | WebBench 跑分（全球排行榜） |

### 8.6 其他
| 页面 | 功能 |
|------|------|
| build.html | ANeko 桌面宠物皮肤制作工具 |
| xieyi.html / yinsi.html | 用户协议 / 隐私政策 |
| jiben.html | 协议同意引导页 |

## 九、外部 API 与数据存储

### 9.1 AI 接口
- `https://apihub.agnes-ai.com/v1/chat/completions` — 主力 AI
- `https://integrate.api.nvidia.com/v1/chat/completions` — NVIDIA AI
- `https://api.deepseek.com/chat/completions` — DeepSeek（五子棋）
- `https://tts666.pages.dev/api/tts` — 语音合成

### 9.2 数据存储（Cloudflare Pages）
- `https://yl-tool-data.pages.dev` — 工具配置数据
- `https://youlong-user-data.pages.dev` — 用户数据/广告/密钥
- `https://youlongtool-data.pages.dev` — 漂流瓶数据
- `https://api.github.com/repos/` — GitHub Gist 存储排行榜/用户数据

### 9.3 第三方服务
- `https://api.suol.cc/v1/lssdjt.php` — 历史上的今天
- `https://api.suol.cc/v1/qzone_info.php` — QQ空间查询
- `https://cn.apihz.cn/api/time/getzddayhs.php` — 黄历数据

## 十、JavaScript 反混淆详情

### 10.1 混淆技术
- javascript-obfuscator 多层混淆
- 字符串数组 + Base64 编码 + 惰性解码缓存
- 变量名 `_0x` 十六进制混淆
- 数组旋转 IIFE 保护（while + parseInt 计算）
- 部分页面使用跨脚本块共享访问器

### 10.2 反混淆成果
- 37 个 HTML 页面全部解密
- 约 9000+ 处混淆字符串调用还原为明文
- 所有 JS 代码已格式化（js-beautify）
- index.html 双脚本块均已处理（1154 处替换）
- 剩余：变量名仍为 `_0x` 形式，控制流平坦化较轻（仅 2 处 switch）

### 10.3 反混淆脚本
通用反混淆器位于工作目录 `deob_generic.js`，支持：
- 自动识别字符串数组函数和访问器函数
- 传递别名集合（const/let/var）
- vm sandbox 安全评估解码函数
- 多脚本块独立处理
