package com.youlong.gj;

import android.content.Context;
import android.os.Build;
import android.os.Debug;
import android.os.Process;
import com.youlong.gj.YouLongShield;
import com.youlong.tool.NativeCrypto;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import yl.d6;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class YouLongShield {
    private static boolean a = true;
    private static boolean b = false;
    private static boolean c = false;
    private static volatile boolean d = false;
    private static final AtomicBoolean e = new AtomicBoolean(false);
    private static final Random f = new Random();
    private static volatile Context g = null;

    /* JADX WARN: Code restructure failed: missing block: B:87:0x00c0, code lost:
    
        r11 = r3 + " 损坏";
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static java.lang.String c(android.content.Context r11) {
        /*
            Method dump skipped, instructions count: 299
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.gj.YouLongShield.c(android.content.Context):java.lang.String");
    }

    private static boolean d() {
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            return true;
        }
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/self/status")));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                if (readLine.startsWith("TracerPid:")) {
                    if (!"0".equals(readLine.substring(10).trim())) {
                        bufferedReader.close();
                        return true;
                    }
                }
            }
            bufferedReader.close();
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    private static boolean e() {
        String str = Build.FINGERPRINT;
        if (str != null) {
            String lowerCase = str.toLowerCase();
            if (lowerCase.contains("generic") || lowerCase.contains("emulator") || lowerCase.contains("sdk_gphone") || lowerCase.contains("vbox") || lowerCase.contains("qemu") || lowerCase.contains("genymotion") || lowerCase.contains("bluestacks") || lowerCase.contains("nox") || lowerCase.contains("mumu") || lowerCase.contains("ldplayer") || lowerCase.contains("memu")) {
                return true;
            }
        }
        String str2 = Build.MODEL;
        if (str2 != null) {
            String lowerCase2 = str2.toLowerCase();
            if (lowerCase2.contains("google_sdk") || lowerCase2.contains("emulator") || lowerCase2.contains("sdk_gphone") || lowerCase2.contains("genymotion") || lowerCase2.contains("bluestacks") || lowerCase2.contains("nox") || lowerCase2.contains("mumu") || lowerCase2.contains("ldplayer") || lowerCase2.contains("memu") || lowerCase2.contains("droid4x") || lowerCase2.contains("ttvm")) {
                return true;
            }
        }
        String str3 = Build.HARDWARE;
        if (str3 != null) {
            String lowerCase3 = str3.toLowerCase();
            if (lowerCase3.contains("goldfish") || lowerCase3.contains("ranchu") || lowerCase3.contains("qemu") || lowerCase3.contains("nox") || lowerCase3.contains("vbox") || lowerCase3.contains("emulator")) {
                return true;
            }
        }
        String str4 = Build.PRODUCT;
        if (str4 != null) {
            String lowerCase4 = str4.toLowerCase();
            if (lowerCase4.contains("sdk") || lowerCase4.contains("emulator") || lowerCase4.contains("simulator") || lowerCase4.contains("vbox") || lowerCase4.contains("nox") || lowerCase4.contains("goldfish")) {
                return true;
            }
        }
        String[] strArr = {"/system/lib/libc_malloc_debug_qemu.so", "/sys/qemu_trace", "/system/bin/qemu-props", "/system/lib/libdroid4x.so", "/system/lib/libnoxspeed.so", "/system/bin/noxd", "/system/lib/libbluestacks.so", "/dev/socket/qemud", "/dev/qemu_pipe", "/system/lib/libgoldfish.so"};
        for (int i = 0; i < 10; i++) {
            if (new File(strArr[i]).exists()) {
                return true;
            }
        }
        return false;
    }

    private static boolean f() {
        try {
            if (NativeCrypto.detectFrida()) {
                return true;
            }
        } catch (Throwable unused) {
        }
        int[] iArr = {27042, 27043};
        for (int i = 0; i < 2; i++) {
            int i2 = iArr[i];
            try {
                Socket socket = new Socket();
                try {
                    continue;
                    socket.connect(new InetSocketAddress("127.0.0.1", i2), 300);
                    socket.close();
                    return true;
                } finally {
                    try {
                        continue;
                    } catch (Throwable th) {
                    }
                }
            } catch (Exception unused2) {
            }
        }
        String[] strArr = {StrX.a(StrX.a), StrX.a(StrX.b), StrX.a(StrX.c), StrX.a(StrX.d), StrX.a(StrX.e), StrX.a(StrX.f), StrX.a(StrX.g)};
        for (int i3 = 0; i3 < 7; i3++) {
            if (new File(strArr[i3]).exists()) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:48:0x00c1, code lost:
    
        if (r2 != null) goto L94;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static boolean g() {
        /*
            java.lang.String r1 = "/system/app/Superuser.apk"
            java.lang.String r2 = "/sbin/su"
            java.lang.String r3 = "/system/bin/su"
            java.lang.String r4 = "/system/xbin/su"
            java.lang.String r5 = "/data/local/xbin/su"
            java.lang.String r6 = "/data/local/bin/su"
            java.lang.String r7 = "/system/sd/xbin/su"
            java.lang.String r8 = "/system/bin/failsafe/su"
            java.lang.String r9 = "/data/local/su"
            java.lang.String r10 = "/su/bin/su"
            java.lang.String r11 = "/sbin/magisk"
            java.lang.String r12 = "/system/bin/magisk"
            java.lang.String r13 = "/system/xbin/magisk"
            java.lang.String r14 = "/data/adb/magisk"
            java.lang.String r15 = "/data/adb/ksu"
            java.lang.String r16 = "/data/adb/apd"
            java.lang.String r17 = "/system/bin/ksud"
            java.lang.String r18 = "/system/xbin/busybox"
            java.lang.String r19 = "/system/bin/busybox"
            java.lang.String r20 = "/data/adb/busybox"
            java.lang.String[] r0 = new java.lang.String[]{r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20}
            r1 = 0
            r2 = r1
        L2e:
            r3 = 1
            r4 = 20
            if (r2 >= r4) goto L44
            r4 = r0[r2]
            java.io.File r5 = new java.io.File
            r5.<init>(r4)
            boolean r4 = r5.exists()
            if (r4 == 0) goto L41
            return r3
        L41:
            int r2 = r2 + 1
            goto L2e
        L44:
            java.lang.String r0 = "com.topjohnwu.magisk"
            boolean r0 = l(r0)
            if (r0 == 0) goto L4d
            return r3
        L4d:
            java.lang.String r0 = "io.github.huskydg.magisk"
            boolean r0 = l(r0)
            if (r0 == 0) goto L56
            return r3
        L56:
            java.lang.String r0 = "com.kingroot.kinguser"
            boolean r0 = l(r0)
            if (r0 == 0) goto L5f
            return r3
        L5f:
            java.lang.String r0 = "com.kingo.root"
            boolean r0 = l(r0)
            if (r0 == 0) goto L68
            return r3
        L68:
            java.lang.String r0 = "eu.chainfire.supersu"
            boolean r0 = l(r0)
            if (r0 == 0) goto L71
            return r3
        L71:
            java.lang.String r0 = "com.koushikdutta.superuser"
            boolean r0 = l(r0)
            if (r0 == 0) goto L7a
            return r3
        L7a:
            java.lang.String r0 = "com.dianxinos.superuser"
            boolean r0 = l(r0)
            if (r0 == 0) goto L83
            return r3
        L83:
            r2 = 0
            java.lang.Runtime r0 = java.lang.Runtime.getRuntime()     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            r4 = 2
            java.lang.String[] r4 = new java.lang.String[r4]     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            java.lang.String r5 = "which"
            r4[r1] = r5     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            java.lang.String r5 = "su"
            r4[r3] = r5     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            java.lang.Process r2 = r0.exec(r4)     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            java.io.BufferedReader r0 = new java.io.BufferedReader     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            java.io.InputStreamReader r4 = new java.io.InputStreamReader     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            java.io.InputStream r5 = r2.getInputStream()     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            r4.<init>(r5)     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            r0.<init>(r4)     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            java.lang.String r0 = r0.readLine()     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            if (r0 == 0) goto Lb7
            boolean r0 = r0.isEmpty()     // Catch: java.lang.Throwable -> Lb5 java.lang.Exception -> Lc1
            if (r0 != 0) goto Lb7
            r2.destroy()
            return r3
        Lb5:
            r0 = move-exception
            goto Lbb
        Lb7:
            r2.destroy()
            goto Lc4
        Lbb:
            if (r2 == 0) goto Lc0
            r2.destroy()
        Lc0:
            throw r0
        Lc1:
            if (r2 == 0) goto Lc4
            goto Lb7
        Lc4:
            java.lang.String r0 = android.os.Build.TAGS
            if (r0 == 0) goto Ld1
            java.lang.String r2 = "test-keys"
            boolean r0 = r0.contains(r2)
            if (r0 == 0) goto Ld1
            return r3
        Ld1:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.gj.YouLongShield.g():boolean");
    }

    private static boolean h() {
        String[] strArr = {"com.lbe.parallel", "com.parallel.space", "com.qihoo.magic", "com.by.chaos", "com.excelliance.dualaiv2", "com.excelliance.dualaiv3", "com.moxiaoxi.dualspace", "com.dualspace.app", "com.lody.virtual", "io.va.exposed", "com.vphone.launcher", "com.pirateking.hook", "com.zeroone.fake"};
        for (int i = 0; i < 13; i++) {
            if (l(strArr[i])) {
                return true;
            }
        }
        try {
            File file = new File("/proc/self/cmdline");
            if (file.exists()) {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                String readLine = bufferedReader.readLine();
                bufferedReader.close();
                if (readLine != null) {
                    if (readLine.toLowerCase().contains("virtual")) {
                        return true;
                    }
                }
            }
        } catch (Exception unused) {
        }
        return false;
    }

    private static boolean i() {
        String[] strArr = {StrX.a(StrX.h), StrX.a(StrX.i), StrX.a(StrX.j), StrX.a(StrX.k), StrX.a(StrX.l), StrX.a(StrX.m), StrX.a(StrX.n)};
        for (int i = 0; i < 7; i++) {
            if (l(strArr[i])) {
                return true;
            }
        }
        try {
            try {
                Class.forName(StrX.a(StrX.o));
                return true;
            } catch (ClassNotFoundException unused) {
                ClassLoader classLoader = YouLongShield.class.getClassLoader();
                if (classLoader != null) {
                    String valueOf = String.valueOf(classLoader);
                    if (!valueOf.contains("xposed") && !valueOf.contains("edxp")) {
                        if (valueOf.contains("lspd")) {
                        }
                    }
                    return true;
                }
                return false;
            }
        } catch (Throwable unused2) {
            return false;
        }
    }

    public static void j(Context context) {
        Context context2;
        if (context != null) {
            context2 = context.getApplicationContext();
        } else {
            context2 = null;
        }
        g = context2;
        if (c(context) != null) {
            a = false;
        }
        if (!a) {
            m();
            return;
        }
        boolean d2 = d();
        boolean k = k();
        boolean f2 = f();
        i();
        if (!d2 && !k && !f2) {
            b = g();
            c = e();
            h();
        } else {
            p(3, 15);
        }
        q();
    }

    private static boolean k() {
        try {
            return NativeCrypto.isTracerAttached();
        } catch (Throwable unused) {
            return false;
        }
    }

    private static boolean l(String str) {
        try {
            Context context = g;
            if (context == null) {
                context = (Context) Class.forName("android.app.ActivityThread").getMethod("currentApplication", new Class[0]).invoke(null, new Object[0]);
            }
            if (context == null) {
                return false;
            }
            context.getPackageManager().getPackageInfo(str, 0);
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    private static void m() {
        try {
            Process.killProcess(Process.myPid());
        } catch (Exception unused) {
        }
        System.exit(0);
    }

    public static /* synthetic */ void n(int i, int i2) {
        try {
            Thread.sleep(i * 1000);
        } catch (InterruptedException unused) {
        }
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 != 2) {
                    try {
                        Thread.sleep(f.nextInt(5000) + 1000);
                    } catch (InterruptedException unused2) {
                    }
                    m();
                    return;
                }
                return;
            }
            throw new RuntimeException("internal error: " + f.nextInt(9999));
        }
        m();
    }

    public static /* synthetic */ void o() {
        do {
            try {
                Thread.sleep((f.nextInt(51) + 10) * 1000);
                if (d() || k()) {
                    break;
                }
            } catch (InterruptedException unused) {
                return;
            }
        } while (!f());
        p(2, 10);
    }

    private static void p(int i, int i2) {
        if (d) {
            return;
        }
        d = true;
        Random random = f;
        final int nextInt = random.nextInt((i2 - i) + 1) + i;
        final int nextInt2 = random.nextInt(4);
        new Thread(new Runnable() { // from class: yl.c6
            @Override // java.lang.Runnable
            public final void run() {
                YouLongShield.n(nextInt, nextInt2);
            }
        }, "shield-retal").start();
    }

    private static void q() {
        if (!e.compareAndSet(false, true)) {
            return;
        }
        Thread thread = new Thread(new d6(0), "shield-watchdog");
        thread.setDaemon(true);
        thread.start();
    }
}
