package com.youlong.gj;

import android.content.Context;
import android.webkit.WebView;
import androidx.compose.animation.AnimatedVisibilityKt;
import androidx.compose.animation.AnimatedVisibilityScope;
import androidx.compose.animation.EnterExitTransitionKt;
import androidx.compose.animation.core.FiniteAnimationSpec;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.Composable;
import androidx.compose.runtime.ComposableTarget;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotMutationPolicy;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.graphics.drawscope.ContentDrawScope;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.ComposeView;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.viewinterop.AndroidView_androidKt;
import com.kyant.backdrop.backdrops.LayerBackdrop;
import com.kyant.backdrop.backdrops.LayerBackdropKt;
import com.kyant.backdrop.backdrops.LayerBackdropModifierKt;
import com.youlong.gj.MainScreenKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import yl.j;
import yl.j2;
import yl.l0;

@Metadata
@SourceDebugExtension
/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final class MainScreenKt {

    @NotNull
    private static final MutableState<Boolean> navBarVisible = SnapshotStateKt.mutableStateOf$default(Boolean.TRUE, (SnapshotMutationPolicy) null, 2, (Object) null);

    @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
    @Composable
    public static final void MainScreen(@NotNull final WebView webView, @Nullable Function1<? super Integer, Unit> function1, @Nullable Composer composer, final int i, final int i2) {
        final Function1<? super Integer, Unit> function12;
        Intrinsics.f(webView, "webView");
        Composer startRestartGroup = composer.startRestartGroup(1910984825);
        if ((i2 & 2) != 0) {
            function12 = new j2(4);
        } else {
            function12 = function1;
        }
        Modifier.Companion companion = Modifier.Companion;
        Modifier fillMaxSize$default = SizeKt.fillMaxSize$default(companion, 0.0f, 1, (Object) null);
        Alignment.Companion companion2 = Alignment.Companion;
        MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getTopStart(), false);
        int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
        CompositionLocalMap currentCompositionLocalMap = startRestartGroup.getCurrentCompositionLocalMap();
        Modifier materializeModifier = ComposedModifierKt.materializeModifier(startRestartGroup, fillMaxSize$default);
        ComposeUiNode.Companion companion3 = ComposeUiNode.Companion;
        Function0<ComposeUiNode> constructor = companion3.getConstructor();
        if (!(startRestartGroup.getApplier() instanceof Applier)) {
            ComposablesKt.invalidApplier();
        }
        startRestartGroup.startReusableNode();
        if (startRestartGroup.getInserting()) {
            startRestartGroup.createNode(constructor);
        } else {
            startRestartGroup.useNode();
        }
        Composer composer2 = Updater.constructor-impl(startRestartGroup);
        Function2 i3 = l0.i(companion3, composer2, maybeCachedBoxMeasurePolicy, composer2, currentCompositionLocalMap);
        if (composer2.getInserting() || !Intrinsics.b(composer2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
            j.i(currentCompositeKeyHash, composer2, currentCompositeKeyHash, i3);
        }
        Updater.set-impl(composer2, materializeModifier, companion3.getSetModifier());
        BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
        final LayerBackdrop a = LayerBackdropKt.a(new j2(5), startRestartGroup, 48, 1);
        AndroidView_androidKt.AndroidView(new Function1() { // from class: yl.s3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                WebView MainScreen$lambda$6$lambda$3;
                MainScreen$lambda$6$lambda$3 = MainScreenKt.MainScreen$lambda$6$lambda$3(webView, (Context) obj);
                return MainScreen$lambda$6$lambda$3;
            }
        }, LayerBackdropModifierKt.a(SizeKt.fillMaxSize$default(companion, 0.0f, 1, (Object) null), a), null, startRestartGroup, 0, 4);
        AnimatedVisibilityKt.AnimatedVisibility(((Boolean) navBarVisible.getValue()).booleanValue(), boxScopeInstance.align(companion, companion2.getBottomCenter()), EnterExitTransitionKt.slideInVertically$default((FiniteAnimationSpec) null, new j2(6), 1, (Object) null), EnterExitTransitionKt.slideOutVertically$default((FiniteAnimationSpec) null, new j2(7), 1, (Object) null), (String) null, ComposableLambdaKt.rememberComposableLambda(-1043731241, true, new Function3<AnimatedVisibilityScope, Composer, Integer, Unit>() { // from class: com.youlong.gj.MainScreenKt$MainScreen$2$4
            @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
            @Composable
            public final void a(AnimatedVisibilityScope AnimatedVisibility, Composer composer3, int i4) {
                Intrinsics.f(AnimatedVisibility, "$this$AnimatedVisibility");
                GlassBottomBarKt.i(LayerBackdrop.this, PaddingKt.padding-qDBjuR0$default(Modifier.Companion, 0.0f, 0.0f, 0.0f, Dp.m1238constructorimpl(12), 7, (Object) null), function12, composer3, 48, 0);
            }

            @Override // kotlin.jvm.functions.Function3
            public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
                a((AnimatedVisibilityScope) obj, (Composer) obj2, ((Number) obj3).intValue());
                return Unit.a;
            }
        }, startRestartGroup, 54), startRestartGroup, 200064, 16);
        startRestartGroup.endNode();
        ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new Function2() { // from class: yl.t3
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    Unit MainScreen$lambda$7;
                    MainScreen$lambda$7 = MainScreenKt.MainScreen$lambda$7(webView, function12, i, i2, (Composer) obj, ((Integer) obj2).intValue());
                    return MainScreen$lambda$7;
                }
            });
        }
    }

    public static final Unit MainScreen$lambda$1(int i) {
        return Unit.a;
    }

    public static final Unit MainScreen$lambda$6$lambda$2(ContentDrawScope rememberLayerBackdrop) {
        Intrinsics.f(rememberLayerBackdrop, "$this$rememberLayerBackdrop");
        DrawScope.drawRect-n-J9OG0$default(rememberLayerBackdrop, Color.Companion.getWhite-0d7_KjU(), 0L, 0L, 0.0f, (DrawStyle) null, (ColorFilter) null, 0, 126, (Object) null);
        rememberLayerBackdrop.drawContent();
        return Unit.a;
    }

    public static final WebView MainScreen$lambda$6$lambda$3(WebView webView, Context it) {
        Intrinsics.f(webView, "$webView");
        Intrinsics.f(it, "it");
        return webView;
    }

    public static final int MainScreen$lambda$6$lambda$4(int i) {
        return i;
    }

    public static final int MainScreen$lambda$6$lambda$5(int i) {
        return i;
    }

    public static final Unit MainScreen$lambda$7(WebView webView, Function1 function1, int i, int i2, Composer composer, int i3) {
        Intrinsics.f(webView, "$webView");
        MainScreen(webView, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.a;
    }

    @NotNull
    public static final MutableState<Boolean> getNavBarVisible() {
        return navBarVisible;
    }

    public static final void setMainContent(@NotNull ComposeView composeView, @NotNull final WebView webView, @NotNull final Function1<? super Integer, Unit> onTabSelected) {
        Intrinsics.f(composeView, "<this>");
        Intrinsics.f(webView, "webView");
        Intrinsics.f(onTabSelected, "onTabSelected");
        composeView.setContent(ComposableLambdaKt.composableLambdaInstance(1452519405, true, new Function2<Composer, Integer, Unit>() { // from class: com.youlong.gj.MainScreenKt$setMainContent$2
            @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
            @Composable
            public final void a(Composer composer, int i) {
                if ((i & 11) == 2 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                } else {
                    MainScreenKt.MainScreen(webView, onTabSelected, composer, 8, 0);
                }
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
                a((Composer) obj, ((Number) obj2).intValue());
                return Unit.a;
            }
        }));
    }

    public static /* synthetic */ void setMainContent$default(ComposeView composeView, WebView webView, Function1 function1, int i, Object obj) {
        if ((i & 2) != 0) {
            function1 = new j2(8);
        }
        setMainContent(composeView, webView, function1);
    }

    public static final Unit setMainContent$lambda$0(int i) {
        return Unit.a;
    }
}
