package com.youlong.gj;

import androidx.compose.runtime.MutableIntState;
import kotlin.jvm.functions.Function0;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final /* synthetic */ class a implements Function0 {
    public final /* synthetic */ int c;
    public final /* synthetic */ MutableIntState f;

    public /* synthetic */ a(MutableIntState mutableIntState, int i) {
        this.c = i;
        this.f = mutableIntState;
    }

    @Override // kotlin.jvm.functions.Function0
    public final Object invoke() {
        int i = this.c;
        MutableIntState mutableIntState = this.f;
        switch (i) {
            case 0:
                return GlassBottomBarKt$GlassBottomBar$2$3.a(mutableIntState);
            case 1:
                return GlassBottomBarKt$GlassBottomBar$2$3.b(mutableIntState);
            case 2:
                return GlassBottomBarKt$GlassBottomBar$2$3.c(mutableIntState);
            default:
                return Integer.valueOf(GlassBottomBarKt.e(mutableIntState));
        }
    }
}
