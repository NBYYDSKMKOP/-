package com.youlong.gj;

import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composable;
import androidx.compose.runtime.ComposableTarget;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnitKt;
import com.kyant.backdrop.Backdrop;
import com.kyant.backdrop.backdrops.CanvasBackdropKt;
import com.kyant.backdrop.catalog.components.LiquidBottomTabKt;
import com.youlong.gj.GlassBottomBarKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import yl.j2;

@Metadata
@SourceDebugExtension
/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final class GlassBottomBarKt {
    /* JADX WARN: Removed duplicated region for block: B:10:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0198  */
    /* JADX WARN: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x007e  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00e6  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00f2  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0107  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0131  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x014a  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0153  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x014c  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00f6  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x004e  */
    @androidx.compose.runtime.ComposableTarget(applier = "androidx.compose.ui.UiComposable")
    @androidx.compose.runtime.Composable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final void i(@org.jetbrains.annotations.NotNull final com.kyant.backdrop.Backdrop r16, @org.jetbrains.annotations.Nullable androidx.compose.ui.Modifier r17, @org.jetbrains.annotations.Nullable kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> r18, @org.jetbrains.annotations.Nullable androidx.compose.runtime.Composer r19, final int r20, final int r21) {
        /*
            Method dump skipped, instructions count: 424
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.gj.GlassBottomBarKt.i(com.kyant.backdrop.Backdrop, androidx.compose.ui.Modifier, kotlin.jvm.functions.Function1, androidx.compose.runtime.Composer, int, int):void");
    }

    @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
    @Composable
    public static final void j(final Function1<? super Integer, Unit> function1, Composer composer, final int i, final int i2) {
        int i3;
        int i4;
        Composer startRestartGroup = composer.startRestartGroup(1915069080);
        int i5 = i2 & 1;
        if (i5 != 0) {
            i3 = i | 6;
        } else if ((i & 14) == 0) {
            if (startRestartGroup.changedInstance(function1)) {
                i4 = 4;
            } else {
                i4 = 2;
            }
            i3 = i4 | i;
        } else {
            i3 = i;
        }
        if ((i3 & 11) == 2 && startRestartGroup.getSkipping()) {
            startRestartGroup.skipToGroupEnd();
        } else {
            if (i5 != 0) {
                function1 = new j2(1);
            }
            i(CanvasBackdropKt.a(new j2(2), startRestartGroup), null, function1, startRestartGroup, (i3 << 6) & 896, 2);
        }
        ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new Function2() { // from class: yl.t1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    Unit o;
                    int intValue = ((Integer) obj2).intValue();
                    o = GlassBottomBarKt.o(function1, i, i2, (Composer) obj, intValue);
                    return o;
                }
            });
        }
    }

    public static final Unit k(int i) {
        return Unit.a;
    }

    public static final Unit l(Backdrop backdrop, Modifier modifier, Function1 function1, int i, int i2, Composer composer, int i3) {
        Intrinsics.f(backdrop, "$backdrop");
        i(backdrop, modifier, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.a;
    }

    public static final Unit m(int i) {
        return Unit.a;
    }

    public static final Unit n(DrawScope rememberCanvasBackdrop) {
        Intrinsics.f(rememberCanvasBackdrop, "$this$rememberCanvasBackdrop");
        DrawScope.drawRect-n-J9OG0$default(rememberCanvasBackdrop, Color.Companion.getWhite-0d7_KjU(), 0L, 0L, 0.0f, (DrawStyle) null, (ColorFilter) null, 0, 126, (Object) null);
        return Unit.a;
    }

    public static final Unit o(Function1 function1, int i, int i2, Composer composer, int i3) {
        j(function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.a;
    }

    public static final int p(MutableIntState mutableIntState) {
        return mutableIntState.getIntValue();
    }

    public static final void q(MutableIntState mutableIntState, int i) {
        mutableIntState.setIntValue(i);
    }

    public static final int r(MutableIntState selectedIndex$delegate) {
        Intrinsics.f(selectedIndex$delegate, "$selectedIndex$delegate");
        return p(selectedIndex$delegate);
    }

    public static final Unit s(Function1 function1, MutableIntState selectedIndex$delegate, int i) {
        Intrinsics.f(selectedIndex$delegate, "$selectedIndex$delegate");
        q(selectedIndex$delegate, i);
        function1.invoke(Integer.valueOf(i));
        return Unit.a;
    }

    @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
    @Composable
    public static final void t(@NotNull final RowScope rowScope, @NotNull final ImageVector icon, @NotNull final String label, final boolean z, @NotNull final Function0<Unit> onClick, @Nullable Composer composer, final int i) {
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        Intrinsics.f(rowScope, "<this>");
        Intrinsics.f(icon, "icon");
        Intrinsics.f(label, "label");
        Intrinsics.f(onClick, "onClick");
        Composer startRestartGroup = composer.startRestartGroup(-2096740589);
        if ((i & 14) == 0) {
            if (startRestartGroup.changed(rowScope)) {
                i7 = 4;
            } else {
                i7 = 2;
            }
            i2 = i7 | i;
        } else {
            i2 = i;
        }
        if ((i & 112) == 0) {
            if (startRestartGroup.changed(icon)) {
                i6 = 32;
            } else {
                i6 = 16;
            }
            i2 |= i6;
        }
        if ((i & 896) == 0) {
            if (startRestartGroup.changed(label)) {
                i5 = 256;
            } else {
                i5 = 128;
            }
            i2 |= i5;
        }
        if ((i & 7168) == 0) {
            if (startRestartGroup.changed(z)) {
                i4 = 2048;
            } else {
                i4 = 1024;
            }
            i2 |= i4;
        }
        if ((57344 & i) == 0) {
            if (startRestartGroup.changedInstance(onClick)) {
                i3 = 16384;
            } else {
                i3 = 8192;
            }
            i2 |= i3;
        }
        if ((46811 & i2) == 9362 && startRestartGroup.getSkipping()) {
            startRestartGroup.skipToGroupEnd();
        } else {
            LiquidBottomTabKt.a(rowScope, onClick, null, ComposableLambdaKt.rememberComposableLambda(-1768696348, true, new Function3<ColumnScope, Composer, Integer, Unit>() { // from class: com.youlong.gj.GlassBottomBarKt$GlassTab$1
                @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
                @Composable
                public final void a(ColumnScope LiquidBottomTab, Composer composer2, int i8) {
                    long Color;
                    FontWeight normal;
                    long Color2;
                    Intrinsics.f(LiquidBottomTab, "$this$LiquidBottomTab");
                    if ((i8 & 81) == 16 && composer2.getSkipping()) {
                        composer2.skipToGroupEnd();
                        return;
                    }
                    Modifier.Companion companion = Modifier.Companion;
                    SpacerKt.Spacer(SizeKt.height-3ABfNKs(companion, Dp.m1238constructorimpl(6)), composer2, 6);
                    ImageVector imageVector = icon;
                    String str = label;
                    Modifier modifier = SizeKt.size-3ABfNKs(companion, Dp.m1238constructorimpl(22));
                    if (z) {
                        Color = ColorKt.Color(4278225151L);
                    } else {
                        Color = ColorKt.Color(4284900966L);
                    }
                    IconKt.Icon-ww6aTOc(imageVector, str, modifier, Color, composer2, 384, 0);
                    long sp = TextUnitKt.getSp(10);
                    if (z) {
                        normal = FontWeight.Companion.getBold();
                    } else {
                        normal = FontWeight.Companion.getNormal();
                    }
                    FontWeight fontWeight = normal;
                    if (z) {
                        Color2 = ColorKt.Color(4278225151L);
                    } else {
                        Color2 = ColorKt.Color(4284900966L);
                    }
                    TextKt.Text--4IGK_g(label, (Modifier) null, Color2, sp, (FontStyle) null, fontWeight, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, (TextStyle) null, composer2, 3072, 0, 131026);
                    SpacerKt.Spacer(SizeKt.height-3ABfNKs(companion, Dp.m1238constructorimpl(2)), composer2, 6);
                }

                @Override // kotlin.jvm.functions.Function3
                public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
                    a((ColumnScope) obj, (Composer) obj2, ((Number) obj3).intValue());
                    return Unit.a;
                }
            }, startRestartGroup, 54), startRestartGroup, (i2 & 14) | 3072 | ((i2 >> 9) & 112), 2);
        }
        ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope(new Function2() { // from class: yl.v1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    Unit u;
                    u = GlassBottomBarKt.u(rowScope, icon, label, z, onClick, i, (Composer) obj, ((Integer) obj2).intValue());
                    return u;
                }
            });
        }
    }

    public static final Unit u(RowScope this_GlassTab, ImageVector icon, String label, boolean z, Function0 onClick, int i, Composer composer, int i2) {
        Intrinsics.f(this_GlassTab, "$this_GlassTab");
        Intrinsics.f(icon, "$icon");
        Intrinsics.f(label, "$label");
        Intrinsics.f(onClick, "$onClick");
        t(this_GlassTab, icon, label, z, onClick, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.a;
    }
}
