package com.youlong.gj;

import androidx.compose.runtime.Composable;
import androidx.compose.runtime.ComposableTarget;
import androidx.compose.runtime.Composer;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;

@Metadata
/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
final class GlassBottomBarKt$setGlassBottomBar$2 implements Function2<Composer, Integer, Unit> {
    final /* synthetic */ Function1<Integer, Unit> c;

    @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
    @Composable
    public final void a(Composer composer, int i) {
        if ((i & 11) != 2 || !composer.getSkipping()) {
            GlassBottomBarKt.j(this.c, composer, 0, 0);
        } else {
            composer.skipToGroupEnd();
        }
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
        a((Composer) obj, ((Number) obj2).intValue());
        return Unit.a;
    }
}
