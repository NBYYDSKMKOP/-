package com.youlong.gj;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.FavoriteKt;
import androidx.compose.material.icons.filled.HomeKt;
import androidx.compose.material.icons.filled.PersonKt;
import androidx.compose.runtime.Composable;
import androidx.compose.runtime.ComposableTarget;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.ui.graphics.vector.ImageVector;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;

@Metadata
@SourceDebugExtension
/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final class GlassBottomBarKt$GlassBottomBar$2$3 implements Function3<RowScope, Composer, Integer, Unit> {
    final /* synthetic */ MutableIntState c;

    public GlassBottomBarKt$GlassBottomBar$2$3(MutableIntState mutableIntState) {
        this.c = mutableIntState;
    }

    public static final Unit e(MutableIntState selectedIndex$delegate) {
        Intrinsics.f(selectedIndex$delegate, "$selectedIndex$delegate");
        GlassBottomBarKt.q(selectedIndex$delegate, 0);
        return Unit.a;
    }

    public static final Unit f(MutableIntState selectedIndex$delegate) {
        Intrinsics.f(selectedIndex$delegate, "$selectedIndex$delegate");
        GlassBottomBarKt.q(selectedIndex$delegate, 1);
        return Unit.a;
    }

    public static final Unit g(MutableIntState selectedIndex$delegate) {
        Intrinsics.f(selectedIndex$delegate, "$selectedIndex$delegate");
        GlassBottomBarKt.q(selectedIndex$delegate, 2);
        return Unit.a;
    }

    @ComposableTarget(applier = "androidx.compose.ui.UiComposable")
    @Composable
    public final void d(RowScope LiquidBottomTabs, Composer composer, int i) {
        int i2;
        int p;
        boolean z;
        int p2;
        boolean z2;
        int p3;
        boolean z3;
        int i3;
        Intrinsics.f(LiquidBottomTabs, "$this$LiquidBottomTabs");
        if ((i & 14) == 0) {
            if (composer.changed(LiquidBottomTabs)) {
                i3 = 4;
            } else {
                i3 = 2;
            }
            i2 = i | i3;
        } else {
            i2 = i;
        }
        if ((i2 & 91) == 18 && composer.getSkipping()) {
            composer.skipToGroupEnd();
            return;
        }
        Icons.Filled filled = Icons.Filled.INSTANCE;
        ImageVector home = HomeKt.getHome(filled);
        p = GlassBottomBarKt.p(this.c);
        if (p == 0) {
            z = true;
        } else {
            z = false;
        }
        composer.startReplaceGroup(1989088170);
        MutableIntState mutableIntState = this.c;
        Object rememberedValue = composer.rememberedValue();
        Composer.Companion companion = Composer.Companion;
        if (rememberedValue == companion.getEmpty()) {
            rememberedValue = new a(mutableIntState, 0);
            composer.updateRememberedValue(rememberedValue);
        }
        composer.endReplaceGroup();
        int i4 = (i2 & 14) | 24960;
        GlassBottomBarKt.t(LiquidBottomTabs, home, "首页", z, (Function0) rememberedValue, composer, i4);
        ImageVector favorite = FavoriteKt.getFavorite(filled);
        p2 = GlassBottomBarKt.p(this.c);
        if (p2 == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        composer.startReplaceGroup(1989095178);
        MutableIntState mutableIntState2 = this.c;
        Object rememberedValue2 = composer.rememberedValue();
        if (rememberedValue2 == companion.getEmpty()) {
            rememberedValue2 = new a(mutableIntState2, 1);
            composer.updateRememberedValue(rememberedValue2);
        }
        composer.endReplaceGroup();
        GlassBottomBarKt.t(LiquidBottomTabs, favorite, "收藏", z2, (Function0) rememberedValue2, composer, i4);
        ImageVector person = PersonKt.getPerson(filled);
        p3 = GlassBottomBarKt.p(this.c);
        if (p3 == 2) {
            z3 = true;
        } else {
            z3 = false;
        }
        composer.startReplaceGroup(1989102122);
        MutableIntState mutableIntState3 = this.c;
        Object rememberedValue3 = composer.rememberedValue();
        if (rememberedValue3 == companion.getEmpty()) {
            rememberedValue3 = new a(mutableIntState3, 2);
            composer.updateRememberedValue(rememberedValue3);
        }
        composer.endReplaceGroup();
        GlassBottomBarKt.t(LiquidBottomTabs, person, "我的", z3, (Function0) rememberedValue3, composer, i4);
    }

    @Override // kotlin.jvm.functions.Function3
    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
        d((RowScope) obj, (Composer) obj2, ((Number) obj3).intValue());
        return Unit.a;
    }
}
