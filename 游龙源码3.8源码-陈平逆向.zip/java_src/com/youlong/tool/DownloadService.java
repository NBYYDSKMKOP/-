package com.youlong.tool;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import androidx.core.view.PointerIconCompat;
import com.youlong.tool.DownloadService;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import yl.i2;
import yl.j0;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class DownloadService extends Service {
    public static final HashMap g = new HashMap();
    public NotificationManager c;
    public Handler f;

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class DownloadTask implements Runnable {
        public final String c;
        public final String f;
        public final Uri g;

        public DownloadTask(String str, String str2, Uri uri) {
            this.c = str;
            this.f = str2;
            this.g = uri;
        }

        @Override // java.lang.Runnable
        public final void run() {
            HttpURLConnection httpURLConnection;
            int contentLength;
            InputStream inputStream;
            OutputStream openOutputStream;
            final int i;
            String str = this.f;
            DownloadService downloadService = DownloadService.this;
            final int i2 = 0;
            try {
                try {
                    downloadService.f.post(new Runnable(this) { // from class: com.youlong.tool.a
                        public final /* synthetic */ DownloadService.DownloadTask f;

                        {
                            this.f = this;
                        }

                        @Override // java.lang.Runnable
                        public final void run() {
                            int i3 = i2;
                            DownloadService.DownloadTask downloadTask = this.f;
                            switch (i3) {
                                case 0:
                                    DownloadService.b(DownloadService.this, downloadTask.f, 0);
                                    return;
                                case 1:
                                    DownloadService.a(DownloadService.this, downloadTask.f, "无法创建文件");
                                    return;
                                default:
                                    downloadTask.getClass();
                                    HashMap hashMap = DownloadService.g;
                                    DownloadService downloadService2 = DownloadService.this;
                                    downloadService2.getClass();
                                    Intent intent = new Intent("android.intent.action.VIEW");
                                    intent.setData(null);
                                    intent.addFlags(1);
                                    downloadService2.c.notify(PointerIconCompat.TYPE_CONTEXT_MENU, new NotificationCompat.Builder(downloadService2, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("下载完成").setContentText(downloadTask.f + " 下载完成，点击打开").setPriority(0).setAutoCancel(true).setContentIntent(PendingIntent.getActivity(downloadService2, 0, intent, 201326592)).build());
                                    return;
                            }
                        }
                    });
                    httpURLConnection = (HttpURLConnection) new URL(this.c).openConnection();
                    httpURLConnection.connect();
                    contentLength = httpURLConnection.getContentLength();
                    inputStream = httpURLConnection.getInputStream();
                    openOutputStream = downloadService.getContentResolver().openOutputStream(this.g);
                } catch (Exception e) {
                    downloadService.f.post(new c(0, this, e));
                    HashMap hashMap = DownloadService.g;
                    hashMap.remove(str);
                    if (!hashMap.isEmpty()) {
                        return;
                    }
                }
                if (openOutputStream == null) {
                    final int i3 = 1;
                    downloadService.f.post(new Runnable(this) { // from class: com.youlong.tool.a
                        public final /* synthetic */ DownloadService.DownloadTask f;

                        {
                            this.f = this;
                        }

                        @Override // java.lang.Runnable
                        public final void run() {
                            int i32 = i3;
                            DownloadService.DownloadTask downloadTask = this.f;
                            switch (i32) {
                                case 0:
                                    DownloadService.b(DownloadService.this, downloadTask.f, 0);
                                    return;
                                case 1:
                                    DownloadService.a(DownloadService.this, downloadTask.f, "无法创建文件");
                                    return;
                                default:
                                    downloadTask.getClass();
                                    HashMap hashMap2 = DownloadService.g;
                                    DownloadService downloadService2 = DownloadService.this;
                                    downloadService2.getClass();
                                    Intent intent = new Intent("android.intent.action.VIEW");
                                    intent.setData(null);
                                    intent.addFlags(1);
                                    downloadService2.c.notify(PointerIconCompat.TYPE_CONTEXT_MENU, new NotificationCompat.Builder(downloadService2, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("下载完成").setContentText(downloadTask.f + " 下载完成，点击打开").setPriority(0).setAutoCancel(true).setContentIntent(PendingIntent.getActivity(downloadService2, 0, intent, 201326592)).build());
                                    return;
                            }
                        }
                    });
                    HashMap hashMap2 = DownloadService.g;
                    hashMap2.remove(str);
                    if (hashMap2.isEmpty()) {
                        downloadService.stopSelf();
                        return;
                    }
                    return;
                }
                byte[] bArr = new byte[4096];
                long j = 0;
                int i4 = 0;
                while (true) {
                    int read = inputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    j += read;
                    openOutputStream.write(bArr, 0, read);
                    if (contentLength > 0 && (i = (int) ((100 * j) / contentLength)) != i4) {
                        downloadService.f.post(new Runnable() { // from class: com.youlong.tool.b
                            @Override // java.lang.Runnable
                            public final void run() {
                                DownloadService.DownloadTask downloadTask = DownloadService.DownloadTask.this;
                                DownloadService.b(DownloadService.this, downloadTask.f, i);
                            }
                        });
                        i4 = i;
                    }
                }
                openOutputStream.flush();
                openOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();
                final int i5 = 2;
                downloadService.f.post(new Runnable(this) { // from class: com.youlong.tool.a
                    public final /* synthetic */ DownloadService.DownloadTask f;

                    {
                        this.f = this;
                    }

                    @Override // java.lang.Runnable
                    public final void run() {
                        int i32 = i5;
                        DownloadService.DownloadTask downloadTask = this.f;
                        switch (i32) {
                            case 0:
                                DownloadService.b(DownloadService.this, downloadTask.f, 0);
                                return;
                            case 1:
                                DownloadService.a(DownloadService.this, downloadTask.f, "无法创建文件");
                                return;
                            default:
                                downloadTask.getClass();
                                HashMap hashMap22 = DownloadService.g;
                                DownloadService downloadService2 = DownloadService.this;
                                downloadService2.getClass();
                                Intent intent = new Intent("android.intent.action.VIEW");
                                intent.setData(null);
                                intent.addFlags(1);
                                downloadService2.c.notify(PointerIconCompat.TYPE_CONTEXT_MENU, new NotificationCompat.Builder(downloadService2, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("下载完成").setContentText(downloadTask.f + " 下载完成，点击打开").setPriority(0).setAutoCancel(true).setContentIntent(PendingIntent.getActivity(downloadService2, 0, intent, 201326592)).build());
                                return;
                        }
                    }
                });
                HashMap hashMap3 = DownloadService.g;
                hashMap3.remove(str);
                if (!hashMap3.isEmpty()) {
                    return;
                }
                downloadService.stopSelf();
            } catch (Throwable th) {
                HashMap hashMap4 = DownloadService.g;
                hashMap4.remove(str);
                if (hashMap4.isEmpty()) {
                    downloadService.stopSelf();
                }
                throw th;
            }
        }
    }

    public static void a(DownloadService downloadService, String str, String str2) {
        downloadService.getClass();
        NotificationCompat.Builder contentTitle = new NotificationCompat.Builder(downloadService, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("下载失败");
        StringBuilder h = i2.h(str, " - ");
        if (str2 == null) {
            str2 = "未知错误";
        }
        h.append(str2);
        downloadService.c.notify(PointerIconCompat.TYPE_CONTEXT_MENU, contentTitle.setContentText(h.toString()).setPriority(0).setAutoCancel(true).build());
    }

    public static void b(DownloadService downloadService, String str, int i) {
        downloadService.getClass();
        downloadService.c.notify(PointerIconCompat.TYPE_CONTEXT_MENU, new NotificationCompat.Builder(downloadService, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("正在下载").setContentText(str + " - " + i + "%").setPriority(-1).setOngoing(true).setProgress(100, i, false).build());
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        this.c = (NotificationManager) getSystemService("notification");
        this.f = new Handler(Looper.getMainLooper());
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel s = j0.s();
            j0.p(s);
            j0.v(s);
            j0.q(this.c, s);
        }
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null) {
            String stringExtra = intent.getStringExtra("url");
            String stringExtra2 = intent.getStringExtra("fileName");
            Uri uri = (Uri) intent.getParcelableExtra("destinationUri");
            if (stringExtra != null && stringExtra2 != null && uri != null) {
                DownloadTask downloadTask = new DownloadTask(stringExtra, stringExtra2, uri);
                g.put(stringExtra2, downloadTask);
                new Thread(downloadTask).start();
                return 2;
            }
            return 2;
        }
        return 2;
    }
}
