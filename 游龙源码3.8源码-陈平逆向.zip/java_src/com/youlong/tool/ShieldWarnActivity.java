package com.youlong.tool;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.lifecycle.CoroutineLiveDataKt;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class ShieldWarnActivity extends Activity {
    public static final /* synthetic */ int q = 0;
    public String c = "";
    public String f = "";
    public boolean g = false;
    public String h = "basic";
    public boolean i = false;
    public TextView j;
    public CountDownTimer k;
    public LinearLayout l;
    public LinearLayout m;
    public Handler n;
    public TextView o;
    public TextView p;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.ShieldWarnActivity$14, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass14 implements Runnable {
        public final /* synthetic */ String c;

        public AnonymousClass14(String str) {
            this.c = str;
        }

        @Override // java.lang.Runnable
        public final void run() {
            final String[] strArr = new String[1];
            boolean b = ShizukuUtils.b();
            String str = this.c;
            if (b && ShizukuUtils.a()) {
                strArr[0] = ShizukuUtils.c("pm disable-user --user 0 " + str, 15000L);
            } else {
                try {
                    Runtime.getRuntime().exec(new String[]{"sh", "-c", "pm disable-user --user 0 " + str}).waitFor();
                    strArr[0] = "OK(fallback)";
                } catch (Exception e) {
                    strArr[0] = "ERROR:" + e.getMessage();
                }
            }
            ShieldWarnActivity.this.n.post(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.14.1
                @Override // java.lang.Runnable
                public final void run() {
                    String[] strArr2;
                    String str2;
                    AnonymousClass14 anonymousClass14 = AnonymousClass14.this;
                    ShieldWarnActivity shieldWarnActivity = ShieldWarnActivity.this;
                    String str3 = anonymousClass14.c;
                    int i = ShieldWarnActivity.q;
                    shieldWarnActivity.getClass();
                    if (!(!shieldWarnActivity.getPackageManager().getApplicationInfo(str3, 0).enabled) && ((str2 = (strArr2 = strArr)[0]) == null || (!str2.contains("disabled") && !strArr2[0].contains("Success")))) {
                        ShieldWarnActivity.this.j.setText("⚠ 冻结可能失败，请手动处理");
                        ShieldWarnActivity.this.j.setTextColor(-48060);
                        ShieldWarnActivity.this.l.removeAllViews();
                        Button button = new Button(ShieldWarnActivity.this);
                        button.setText("关闭");
                        button.setTextColor(-1);
                        button.setTextSize(18.0f);
                        button.setBackgroundColor(-13730510);
                        button.setPadding(40, 24, 40, 24);
                        button.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.14.1.1
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                ShieldWarnActivity.this.finish();
                            }
                        });
                        ShieldWarnActivity.this.l.addView(button);
                    }
                    ShieldWarnActivity.this.j.setText("✅ 已冻结 " + anonymousClass14.c);
                    ShieldWarnActivity.this.j.setTextColor(-11751600);
                    TextView textView = ShieldWarnActivity.this.o;
                    if (textView != null) {
                        textView.setText("该应用已被冻结，可在设置中解冻");
                        ShieldWarnActivity.this.o.setTextColor(-11751600);
                    }
                    ShieldWarnActivity.this.l.removeAllViews();
                    Button button2 = new Button(ShieldWarnActivity.this);
                    button2.setText("关闭");
                    button2.setTextColor(-1);
                    button2.setTextSize(18.0f);
                    button2.setBackgroundColor(-13730510);
                    button2.setPadding(40, 24, 40, 24);
                    button2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                    button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.14.1.1
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            ShieldWarnActivity.this.finish();
                        }
                    });
                    ShieldWarnActivity.this.l.addView(button2);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.ShieldWarnActivity$15, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass15 implements Runnable {
        public final /* synthetic */ String c;

        /* renamed from: com.youlong.tool.ShieldWarnActivity$15$1, reason: invalid class name */
        /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
        class AnonymousClass1 implements Runnable {
            public AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public final void run() {
                ShieldWarnActivity.this.n.postDelayed(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.15.1.1
                    @Override // java.lang.Runnable
                    public final void run() {
                        AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                        AnonymousClass15 anonymousClass15 = AnonymousClass15.this;
                        AnonymousClass15 anonymousClass152 = AnonymousClass15.this;
                        ShieldWarnActivity shieldWarnActivity = ShieldWarnActivity.this;
                        String str = anonymousClass15.c;
                        int i = ShieldWarnActivity.q;
                        shieldWarnActivity.getClass();
                        try {
                            shieldWarnActivity.getPackageManager().getPackageInfo(str, 0);
                            ShieldWarnActivity.f(ShieldWarnActivity.this, anonymousClass152.c);
                        } catch (PackageManager.NameNotFoundException unused) {
                            ShieldWarnActivity.this.j.setText("卸载成功！");
                            ShieldWarnActivity.this.j.setTextColor(-11751600);
                            TextView textView = ShieldWarnActivity.this.o;
                            if (textView != null) {
                                textView.setText(anonymousClass152.c + " 已成功卸载");
                                ShieldWarnActivity.this.o.setTextColor(-11751600);
                            }
                            ShieldWarnActivity.this.n.postDelayed(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.15.1.1.1
                                @Override // java.lang.Runnable
                                public final void run() {
                                    ShieldWarnActivity.this.finish();
                                }
                            }, 2000L);
                        }
                    }
                }, 1500L);
            }
        }

        public AnonymousClass15(String str) {
            this.c = str;
        }

        @Override // java.lang.Runnable
        public final void run() {
            boolean b = ShizukuUtils.b();
            String str = this.c;
            if (b && ShizukuUtils.a()) {
                ShizukuUtils.c("pm uninstall " + str, 15000L);
            } else {
                try {
                    Runtime.getRuntime().exec(new String[]{"sh", "-c", "pm uninstall " + str}).waitFor();
                } catch (Exception e) {
                    new StringBuilder("ERROR:").append(e.getMessage());
                }
            }
            ShieldWarnActivity.this.n.post(new AnonymousClass1());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.ShieldWarnActivity$6, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass6 implements Runnable {
        public AnonymousClass6() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            String b;
            String str;
            boolean b2 = ShizukuUtils.b();
            ShieldWarnActivity shieldWarnActivity = ShieldWarnActivity.this;
            if (b2 && ShizukuUtils.a()) {
                b = ShizukuUtils.c("pm list packages -3", 15000L);
            } else {
                b = ShieldWarnActivity.b(shieldWarnActivity, "pm list packages -3");
            }
            ArrayList arrayList = new ArrayList();
            final boolean z = false;
            if (b != null) {
                for (String str2 : b.split("\n")) {
                    String trim = str2.trim();
                    if (trim.startsWith("package:")) {
                        String trim2 = trim.substring(8).trim();
                        if (!trim2.isEmpty() && !trim2.equals("com.youlong.tool") && !trim2.equals(shieldWarnActivity.getPackageName())) {
                            arrayList.add(trim2);
                        }
                    }
                }
            }
            if (!arrayList.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < arrayList.size(); i++) {
                    if (i > 0) {
                        sb.append("; ");
                    }
                    sb.append("am force-stop ");
                    sb.append((String) arrayList.get(i));
                }
                str = sb.toString();
            } else {
                str = "";
            }
            if (!str.isEmpty()) {
                if (ShizukuUtils.b() && ShizukuUtils.a()) {
                    ShizukuUtils.c(str, 60000L);
                } else {
                    ShieldWarnActivity.b(shieldWarnActivity, str);
                }
            }
            arrayList.size();
            final int size = arrayList.size();
            if (!shieldWarnActivity.c.isEmpty() && !shieldWarnActivity.c.equals("未知应用")) {
                z = true;
            }
            shieldWarnActivity.n.post(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.6.1
                @Override // java.lang.Runnable
                public final void run() {
                    AnonymousClass6 anonymousClass6 = AnonymousClass6.this;
                    ShieldWarnActivity.this.l.removeAllViews();
                    ShieldWarnActivity shieldWarnActivity2 = ShieldWarnActivity.this;
                    int i2 = size;
                    if (i2 == 0) {
                        shieldWarnActivity2.j.setText("已全面停止（未发现第三方应用）");
                    } else {
                        shieldWarnActivity2.j.setText("已强制停止 " + i2 + " 个第三方应用");
                    }
                    shieldWarnActivity2.j.setTextColor(-11751600);
                    shieldWarnActivity2.j.setTextSize(16.0f);
                    if (z) {
                        final String str3 = shieldWarnActivity2.c;
                        TextView textView = shieldWarnActivity2.o;
                        if (textView != null) {
                            textView.setText("已全面停止，是否卸载前台应用 " + str3 + " ？");
                            shieldWarnActivity2.o.setTextColor(-13312);
                        }
                        Button button = new Button(shieldWarnActivity2);
                        button.setText("立即卸载");
                        button.setTextColor(-1);
                        button.setTextSize(18.0f);
                        button.setBackgroundColor(-2937041);
                        button.setPadding(40, 24, 40, 24);
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                        layoutParams.bottomMargin = 12;
                        button.setLayoutParams(layoutParams);
                        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.6.1.1
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                                CountDownTimer countDownTimer = ShieldWarnActivity.this.k;
                                if (countDownTimer != null) {
                                    countDownTimer.cancel();
                                    ShieldWarnActivity.this.k = null;
                                }
                                ShieldWarnActivity.d(ShieldWarnActivity.this, str3);
                            }
                        });
                        shieldWarnActivity2.l.addView(button);
                        Button button2 = new Button(shieldWarnActivity2);
                        button2.setText("不卸载，关闭");
                        button2.setTextColor(-1);
                        button2.setTextSize(15.0f);
                        button2.setBackgroundColor(-13730510);
                        button2.setPadding(30, 18, 30, 18);
                        button2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                        button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.6.1.2
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                                CountDownTimer countDownTimer = ShieldWarnActivity.this.k;
                                if (countDownTimer != null) {
                                    countDownTimer.cancel();
                                    ShieldWarnActivity.this.k = null;
                                }
                                ShieldWarnActivity.e(ShieldWarnActivity.this, str3);
                            }
                        });
                        shieldWarnActivity2.l.addView(button2);
                        shieldWarnActivity2.k = new CountDownTimer() { // from class: com.youlong.tool.ShieldWarnActivity.6.1.3
                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            {
                                super(CoroutineLiveDataKt.DEFAULT_TIMEOUT, 1000L);
                            }

                            @Override // android.os.CountDownTimer
                            public final void onFinish() {
                                ShieldWarnActivity.d(ShieldWarnActivity.this, str3);
                            }

                            @Override // android.os.CountDownTimer
                            public final void onTick(long j) {
                                AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                                ShieldWarnActivity.this.j.setText((j / 1000) + " 秒后将自动卸载");
                                if (j <= 2000) {
                                    ShieldWarnActivity.this.j.setTextColor(-48060);
                                }
                            }
                        }.start();
                        return;
                    }
                    Button button3 = new Button(shieldWarnActivity2);
                    button3.setText("关闭");
                    button3.setTextColor(-1);
                    button3.setTextSize(18.0f);
                    button3.setBackgroundColor(-13730510);
                    button3.setPadding(40, 24, 40, 24);
                    button3.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                    button3.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.6.1.4
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            ShieldWarnActivity.this.finish();
                        }
                    });
                    shieldWarnActivity2.l.addView(button3);
                }
            });
        }
    }

    public static void a(ShieldWarnActivity shieldWarnActivity) {
        if (!shieldWarnActivity.i) {
            shieldWarnActivity.i = true;
            CountDownTimer countDownTimer = shieldWarnActivity.k;
            if (countDownTimer != null) {
                countDownTimer.cancel();
                shieldWarnActivity.k = null;
            }
            final String str = shieldWarnActivity.c;
            if (!str.isEmpty() && !str.equals("未知应用")) {
                boolean equals = "super".equals(shieldWarnActivity.h);
                boolean equals2 = "extreme".equals(shieldWarnActivity.h);
                if (equals) {
                    shieldWarnActivity.j.setText("正在通过 Shizuku 强制停止...");
                    shieldWarnActivity.j.setTextColor(-13312);
                    shieldWarnActivity.l.removeAllViews();
                    new Thread(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.7
                        @Override // java.lang.Runnable
                        public final void run() {
                            boolean b = ShizukuUtils.b();
                            String str2 = str;
                            if (b && ShizukuUtils.a()) {
                                ShizukuUtils.c("am force-stop " + str2, 10000L);
                            } else {
                                try {
                                    Runtime.getRuntime().exec(new String[]{"sh", "-c", "am force-stop " + str2}).waitFor();
                                } catch (Exception e) {
                                    new StringBuilder("ERROR:").append(e.getMessage());
                                }
                            }
                            ShieldWarnActivity.this.n.post(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.7.1
                                @Override // java.lang.Runnable
                                public final void run() {
                                    AnonymousClass7 anonymousClass7 = AnonymousClass7.this;
                                    final ShieldWarnActivity shieldWarnActivity2 = ShieldWarnActivity.this;
                                    shieldWarnActivity2.j.setText("5 秒后将自动卸载");
                                    shieldWarnActivity2.j.setTextColor(-48060);
                                    shieldWarnActivity2.j.setTextSize(18.0f);
                                    int childCount = shieldWarnActivity2.m.getChildCount();
                                    final String str3 = str;
                                    if (childCount >= 4) {
                                        View childAt = shieldWarnActivity2.m.getChildAt(3);
                                        if (childAt instanceof TextView) {
                                            TextView textView = (TextView) childAt;
                                            textView.setText("已强制停止：" + str3);
                                            textView.setTextColor(-11751600);
                                        }
                                    }
                                    TextView textView2 = shieldWarnActivity2.p;
                                    if (textView2 != null) {
                                        textView2.setText("am force-stop 已执行，是否继续卸载此应用？");
                                        shieldWarnActivity2.p.setTextColor(-13312);
                                    }
                                    TextView textView3 = shieldWarnActivity2.o;
                                    if (textView3 != null) {
                                        textView3.setText("应用已被强制停止，建议立即卸载\n如不操作将在5秒后自动卸载");
                                        shieldWarnActivity2.o.setTextColor(-13108);
                                    }
                                    shieldWarnActivity2.l.removeAllViews();
                                    Button button = new Button(shieldWarnActivity2);
                                    button.setText("立即卸载");
                                    button.setTextColor(-1);
                                    button.setTextSize(18.0f);
                                    button.setBackgroundColor(-2937041);
                                    button.setPadding(40, 24, 40, 24);
                                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                                    layoutParams.bottomMargin = 12;
                                    button.setLayoutParams(layoutParams);
                                    button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.8
                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view) {
                                            ShieldWarnActivity.d(ShieldWarnActivity.this, str3);
                                        }
                                    });
                                    shieldWarnActivity2.l.addView(button);
                                    Button button2 = new Button(shieldWarnActivity2);
                                    button2.setText("不卸载，关闭");
                                    button2.setTextColor(-1);
                                    button2.setTextSize(15.0f);
                                    button2.setBackgroundColor(-13730510);
                                    button2.setPadding(30, 18, 30, 18);
                                    button2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                                    button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.9
                                        @Override // android.view.View.OnClickListener
                                        public final void onClick(View view) {
                                            ShieldWarnActivity shieldWarnActivity3 = ShieldWarnActivity.this;
                                            CountDownTimer countDownTimer2 = shieldWarnActivity3.k;
                                            if (countDownTimer2 != null) {
                                                countDownTimer2.cancel();
                                                shieldWarnActivity3.k = null;
                                            }
                                            ShieldWarnActivity.e(shieldWarnActivity3, str3);
                                        }
                                    });
                                    shieldWarnActivity2.l.addView(button2);
                                    shieldWarnActivity2.k = new CountDownTimer() { // from class: com.youlong.tool.ShieldWarnActivity.10
                                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                        {
                                            super(CoroutineLiveDataKt.DEFAULT_TIMEOUT, 1000L);
                                        }

                                        @Override // android.os.CountDownTimer
                                        public final void onFinish() {
                                            ShieldWarnActivity.d(ShieldWarnActivity.this, str3);
                                        }

                                        @Override // android.os.CountDownTimer
                                        public final void onTick(long j) {
                                            ShieldWarnActivity shieldWarnActivity3 = ShieldWarnActivity.this;
                                            shieldWarnActivity3.j.setText((j / 1000) + " 秒后将自动卸载");
                                            if (j <= 2000) {
                                                shieldWarnActivity3.j.setTextColor(-48060);
                                            }
                                        }
                                    }.start();
                                }
                            });
                        }
                    }).start();
                    return;
                }
                if (equals2) {
                    shieldWarnActivity.j.setText("正在获取全部第三方应用...");
                    shieldWarnActivity.j.setTextColor(-13312);
                    shieldWarnActivity.l.removeAllViews();
                    new Thread(new AnonymousClass6()).start();
                    return;
                }
                if (shieldWarnActivity.g) {
                    shieldWarnActivity.j.setText("正在启动系统卸载...");
                    shieldWarnActivity.j.setTextColor(-13312);
                    shieldWarnActivity.l.removeAllViews();
                    try {
                        Intent intent = new Intent("android.intent.action.UNINSTALL_PACKAGE");
                        intent.setData(Uri.parse("package:".concat(str)));
                        intent.putExtra("android.intent.extra.RETURN_RESULT", true);
                        intent.addFlags(268435456);
                        shieldWarnActivity.startActivity(intent);
                    } catch (Exception unused) {
                    }
                    shieldWarnActivity.n.postDelayed(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.4
                        @Override // java.lang.Runnable
                        public final void run() {
                            String str2 = str;
                            int i = ShieldWarnActivity.q;
                            ShieldWarnActivity shieldWarnActivity2 = ShieldWarnActivity.this;
                            shieldWarnActivity2.getClass();
                            try {
                                shieldWarnActivity2.getPackageManager().getPackageInfo(str2, 0);
                                ShieldWarnActivity.f(shieldWarnActivity2, str2);
                            } catch (PackageManager.NameNotFoundException unused2) {
                                shieldWarnActivity2.finish();
                            }
                        }
                    }, 3000L);
                    return;
                }
                shieldWarnActivity.g(str);
                try {
                    Intent intent2 = new Intent(shieldWarnActivity, (Class<?>) MainActivity.class);
                    intent2.addFlags(335675392);
                    shieldWarnActivity.startActivity(intent2);
                } catch (Exception unused2) {
                }
                shieldWarnActivity.n.postDelayed(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.5
                    @Override // java.lang.Runnable
                    public final void run() {
                        final String str2 = str;
                        int i = ShieldWarnActivity.q;
                        final ShieldWarnActivity shieldWarnActivity2 = ShieldWarnActivity.this;
                        shieldWarnActivity2.getClass();
                        try {
                            Intent intent3 = new Intent(shieldWarnActivity2, (Class<?>) MainActivity.class);
                            intent3.addFlags(335675392);
                            shieldWarnActivity2.startActivity(intent3);
                        } catch (Exception unused3) {
                        }
                        try {
                            Intent intent4 = new Intent("android.intent.action.UNINSTALL_PACKAGE");
                            intent4.setData(Uri.parse("package:" + str2));
                            intent4.putExtra("android.intent.extra.RETURN_RESULT", true);
                            intent4.addFlags(268435456);
                            shieldWarnActivity2.startActivity(intent4);
                        } catch (Exception unused4) {
                        }
                        shieldWarnActivity2.finish();
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.18
                            @Override // java.lang.Runnable
                            public final void run() {
                                String str3 = str2;
                                ShieldWarnActivity shieldWarnActivity3 = ShieldWarnActivity.this;
                                try {
                                    shieldWarnActivity3.getPackageManager().getPackageInfo(str3, 0);
                                    int i2 = ShieldWarnActivity.q;
                                    shieldWarnActivity3.g(str3);
                                    Intent intent5 = new Intent("android.intent.action.DELETE");
                                    intent5.setData(Uri.parse("package:" + str3));
                                    intent5.addFlags(276856832);
                                    shieldWarnActivity3.startActivity(intent5);
                                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.youlong.tool.ShieldWarnActivity.18.1
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            AnonymousClass18 anonymousClass18 = AnonymousClass18.this;
                                            try {
                                                ShieldWarnActivity.this.getPackageManager().getPackageInfo(str2, 0);
                                                Intent intent6 = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                                                intent6.setData(Uri.parse("package:" + str2));
                                                intent6.addFlags(268435456);
                                                ShieldWarnActivity.this.startActivity(intent6);
                                            } catch (PackageManager.NameNotFoundException | Exception unused5) {
                                            }
                                        }
                                    }, 8000L);
                                } catch (PackageManager.NameNotFoundException | Exception unused5) {
                                }
                            }
                        }, CoroutineLiveDataKt.DEFAULT_TIMEOUT);
                    }
                }, 400L);
                return;
            }
            shieldWarnActivity.finish();
        }
    }

    public static String b(ShieldWarnActivity shieldWarnActivity, String str) {
        shieldWarnActivity.getClass();
        try {
            Process exec = Runtime.getRuntime().exec(new String[]{"sh", "-c", str});
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    sb.append(readLine);
                    sb.append("\n");
                } else {
                    exec.waitFor();
                    return sb.toString().trim();
                }
            }
        } catch (Exception e) {
            return "ERROR:" + e.getMessage();
        }
    }

    public static void c(ShieldWarnActivity shieldWarnActivity, String str) {
        CountDownTimer countDownTimer = shieldWarnActivity.k;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            shieldWarnActivity.k = null;
        }
        shieldWarnActivity.j.setText("正在冻结...");
        shieldWarnActivity.j.setTextColor(-13312);
        shieldWarnActivity.l.removeAllViews();
        new Thread(new AnonymousClass14(str)).start();
    }

    public static void d(ShieldWarnActivity shieldWarnActivity, String str) {
        CountDownTimer countDownTimer = shieldWarnActivity.k;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            shieldWarnActivity.k = null;
        }
        shieldWarnActivity.j.setText("正在卸载...");
        shieldWarnActivity.j.setTextColor(-13312);
        shieldWarnActivity.l.removeAllViews();
        new Thread(new AnonymousClass15(str)).start();
    }

    public static void e(ShieldWarnActivity shieldWarnActivity, final String str) {
        TextView textView = shieldWarnActivity.o;
        if (textView != null) {
            textView.setText("是否冻结此应用 " + str + " ？");
            shieldWarnActivity.o.setTextColor(-13312);
        }
        shieldWarnActivity.j.setText("20 秒后将自动冻结");
        shieldWarnActivity.j.setTextColor(-13312);
        shieldWarnActivity.j.setTextSize(16.0f);
        shieldWarnActivity.l.removeAllViews();
        Button button = new Button(shieldWarnActivity);
        button.setText("立即冻结");
        button.setTextColor(-1);
        button.setTextSize(18.0f);
        button.setBackgroundColor(-2937041);
        button.setPadding(40, 24, 40, 24);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = 12;
        button.setLayoutParams(layoutParams);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ShieldWarnActivity shieldWarnActivity2 = ShieldWarnActivity.this;
                CountDownTimer countDownTimer = shieldWarnActivity2.k;
                if (countDownTimer != null) {
                    countDownTimer.cancel();
                    shieldWarnActivity2.k = null;
                }
                ShieldWarnActivity.c(shieldWarnActivity2, str);
            }
        });
        shieldWarnActivity.l.addView(button);
        Button button2 = new Button(shieldWarnActivity);
        button2.setText("不冻结，关闭");
        button2.setTextColor(-1);
        button2.setTextSize(15.0f);
        button2.setBackgroundColor(-13730510);
        button2.setPadding(30, 18, 30, 18);
        button2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ShieldWarnActivity.this.finish();
            }
        });
        shieldWarnActivity.l.addView(button2);
        shieldWarnActivity.k = new CountDownTimer() { // from class: com.youlong.tool.ShieldWarnActivity.13
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(20000L, 1000L);
            }

            @Override // android.os.CountDownTimer
            public final void onFinish() {
                ShieldWarnActivity.c(ShieldWarnActivity.this, str);
            }

            @Override // android.os.CountDownTimer
            public final void onTick(long j) {
                ShieldWarnActivity shieldWarnActivity2 = ShieldWarnActivity.this;
                shieldWarnActivity2.j.setText((j / 1000) + " 秒后将自动冻结");
                if (j <= 3000) {
                    shieldWarnActivity2.j.setTextColor(-48060);
                }
            }
        }.start();
    }

    public static void f(ShieldWarnActivity shieldWarnActivity, final String str) {
        shieldWarnActivity.l.removeAllViews();
        shieldWarnActivity.j.setText("紧急脱险");
        shieldWarnActivity.j.setTextColor(-48060);
        shieldWarnActivity.j.setTextSize(22.0f);
        if (shieldWarnActivity.m.getChildCount() >= 6) {
            View childAt = shieldWarnActivity.m.getChildAt(6);
            if (childAt instanceof TextView) {
                TextView textView = (TextView) childAt;
                textView.setText("系统卸载未成功，请手动卸载该应用：");
                textView.setTextColor(-13108);
            }
        }
        Button button = new Button(shieldWarnActivity);
        button.setText("卸载应用");
        button.setTextColor(-1);
        button.setTextSize(18.0f);
        button.setBackgroundColor(-2937041);
        button.setPadding(40, 24, 40, 24);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = 12;
        button.setLayoutParams(layoutParams);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                try {
                    Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.parse("package:" + str));
                    intent.addFlags(268435456);
                    ShieldWarnActivity.this.startActivity(intent);
                } catch (Exception unused) {
                }
            }
        });
        shieldWarnActivity.l.addView(button);
        Button button2 = new Button(shieldWarnActivity);
        button2.setText("我已脱险");
        button2.setTextColor(-1);
        button2.setTextSize(18.0f);
        button2.setBackgroundColor(-11751600);
        button2.setPadding(40, 24, 40, 24);
        button2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ShieldWarnActivity.this.finish();
            }
        });
        shieldWarnActivity.l.addView(button2);
    }

    public final void g(String str) {
        try {
            Runtime.getRuntime().exec(new String[]{"sh", "-c", "am force-stop " + str}).waitFor();
        } catch (Exception unused) {
        }
        try {
            ActivityManager activityManager = (ActivityManager) getSystemService("activity");
            if (activityManager != null) {
                activityManager.killBackgroundProcesses(str);
            }
        } catch (Exception unused2) {
        }
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        boolean z;
        int i;
        String str;
        String str2;
        int i2;
        String str3;
        long j;
        super.onCreate(bundle);
        String stringExtra = getIntent().getStringExtra("suspect_package");
        this.c = stringExtra;
        if (stringExtra == null) {
            this.c = "未知应用";
        }
        String stringExtra2 = getIntent().getStringExtra("reason");
        this.f = stringExtra2;
        if (stringExtra2 == null) {
            this.f = "检测到高风险应用";
        }
        getIntent().getIntExtra("warn_count", 1);
        this.g = getIntent().getBooleanExtra("is_volume_rescue", false);
        String stringExtra3 = getIntent().getStringExtra("shield_mode");
        this.h = stringExtra3;
        if (stringExtra3 == null || (!stringExtra3.equals("basic") && !this.h.equals("super") && !this.h.equals("extreme"))) {
            this.h = "basic";
        }
        this.n = new Handler(Looper.getMainLooper());
        Window window = getWindow();
        window.addFlags(40372096);
        if (Build.VERSION.SDK_INT >= 28) {
            window.getAttributes().layoutInDisplayCutoutMode = 3;
        }
        window.getDecorView().setSystemUiVisibility(5894);
        final boolean equals = "super".equals(this.h);
        final boolean equals2 = "extreme".equals(this.h);
        if (!equals && !equals2) {
            z = false;
        } else {
            z = true;
        }
        LinearLayout linearLayout = new LinearLayout(this);
        this.m = linearLayout;
        linearLayout.setOrientation(1);
        this.m.setGravity(17);
        LinearLayout linearLayout2 = this.m;
        if (z) {
            i = -586343619;
        } else {
            i = -585433088;
        }
        linearLayout2.setBackgroundColor(i);
        this.m.setPadding(40, 60, 40, 60);
        TextView textView = new TextView(this);
        this.j = textView;
        if (equals) {
            textView.setText("10 秒后将自动强制停止");
        } else if (equals2) {
            textView.setText("5 秒后将自动全面拦截");
        } else {
            if (this.g) {
                str = "7 秒后将自动卸载前台应用";
            } else {
                str = "3 秒后将自动拦截卸载";
            }
            textView.setText(str);
        }
        this.j.setTextColor(-13312);
        this.j.setTextSize(16.0f);
        this.j.setGravity(17);
        this.j.setPadding(0, 0, 0, 10);
        this.m.addView(this.j);
        TextView textView2 = new TextView(this);
        if (z) {
            textView2.setText("🛡️");
        } else {
            textView2.setText("⚠️");
        }
        textView2.setTextSize(64.0f);
        textView2.setGravity(17);
        textView2.setPadding(0, 0, 0, 6);
        this.m.addView(textView2);
        TextView textView3 = new TextView(this);
        if (equals) {
            textView3.setText("超级拦截 · 强制停止");
        } else if (equals2) {
            textView3.setText("极强拦截 · 全面停止");
        } else {
            if (this.g) {
                str2 = "是否拦截前台应用？";
            } else {
                str2 = "检测到高风险应用！";
            }
            textView3.setText(str2);
        }
        textView3.setTextColor(-1);
        textView3.setTextSize(22.0f);
        textView3.setGravity(17);
        textView3.setPadding(0, 0, 0, 8);
        this.m.addView(textView3);
        TextView textView4 = new TextView(this);
        textView4.setText("应用：" + this.c);
        textView4.setTextColor(-13312);
        textView4.setTextSize(16.0f);
        textView4.setGravity(17);
        textView4.setPadding(0, 0, 0, 6);
        this.m.addView(textView4);
        TextView textView5 = new TextView(this);
        this.p = textView5;
        textView5.setText(this.f);
        this.p.setTextColor(-30584);
        this.p.setTextSize(14.0f);
        this.p.setGravity(17);
        this.p.setPadding(0, 0, 0, 20);
        this.m.addView(this.p);
        TextView textView6 = new TextView(this);
        this.o = textView6;
        if (equals) {
            textView6.setText("通过 Shizuku 执行 am force-stop 强制停止应用\n如不操作将在10秒后自动执行");
        } else if (equals2) {
            textView6.setText("通过 Shizuku 获取全部第三方应用并逐个强制停止\n如不操作将在5秒后自动执行（自动跳过游龙工具）");
        } else if (this.g) {
            textView6.setText("检测到三击音量键逃脱触发，是否立即卸载前台应用？\n如不操作将在7秒后自动卸载");
        } else {
            textView6.setText("此应用包含高风险权限，可能危害您的设备！\n请选择是否拦截卸载：");
        }
        this.o.setTextColor(-13108);
        this.o.setTextSize(15.0f);
        this.o.setGravity(17);
        this.o.setPadding(20, 16, 20, 22);
        TextView textView7 = this.o;
        if (z) {
            i2 = 1142253248;
        } else {
            i2 = 1157562368;
        }
        textView7.setBackgroundColor(i2);
        this.m.addView(this.o);
        LinearLayout linearLayout3 = new LinearLayout(this);
        this.l = linearLayout3;
        linearLayout3.setOrientation(1);
        this.l.setGravity(17);
        Button button = new Button(this);
        if (equals) {
            button.setText("立即强制停止");
        } else if (equals2) {
            button.setText("立即全面拦截");
        } else {
            if (this.g) {
                str3 = "立即拦截";
            } else {
                str3 = "是，拦截卸载";
            }
            button.setText(str3);
        }
        button.setTextColor(-1);
        button.setTextSize(18.0f);
        button.setBackgroundColor(-2937041);
        button.setPadding(40, 24, 40, 24);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = 12;
        button.setLayoutParams(layoutParams);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ShieldWarnActivity.a(ShieldWarnActivity.this);
            }
        });
        this.l.addView(button);
        Button button2 = new Button(this);
        String str4 = "取消";
        if (equals) {
            button2.setText("取消");
        } else {
            if (!this.g) {
                str4 = "否，信任此应用";
            }
            button2.setText(str4);
        }
        button2.setTextColor(-1);
        button2.setTextSize(15.0f);
        button2.setBackgroundColor(-13730510);
        button2.setPadding(30, 18, 30, 18);
        button2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ShieldWarnActivity.2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ShieldWarnActivity shieldWarnActivity = ShieldWarnActivity.this;
                if (!shieldWarnActivity.i) {
                    shieldWarnActivity.i = true;
                    CountDownTimer countDownTimer = shieldWarnActivity.k;
                    if (countDownTimer != null) {
                        countDownTimer.cancel();
                        shieldWarnActivity.k = null;
                    }
                    if (!shieldWarnActivity.g) {
                        String str5 = shieldWarnActivity.c;
                        try {
                            SharedPreferences sharedPreferences = shieldWarnActivity.getSharedPreferences("shield_prefs", 0);
                            String string = sharedPreferences.getString("whitelist_pkgs", "");
                            if (!string.contains(str5)) {
                                if (!string.isEmpty()) {
                                    string = string.concat(",");
                                }
                                sharedPreferences.edit().putString("whitelist_pkgs", string + str5).apply();
                            }
                        } catch (Exception unused) {
                        }
                    }
                    shieldWarnActivity.finish();
                }
            }
        });
        this.l.addView(button2);
        this.m.addView(this.l);
        setContentView(this.m);
        boolean z2 = this.g;
        if (equals) {
            j = 10000;
        } else if (equals2) {
            j = CoroutineLiveDataKt.DEFAULT_TIMEOUT;
        } else if (z2) {
            j = 7000;
        } else {
            j = 3000;
        }
        this.k = new CountDownTimer(j) { // from class: com.youlong.tool.ShieldWarnActivity.3
            @Override // android.os.CountDownTimer
            public final void onFinish() {
                ShieldWarnActivity shieldWarnActivity = ShieldWarnActivity.this;
                if (!shieldWarnActivity.i) {
                    ShieldWarnActivity.a(shieldWarnActivity);
                }
            }

            @Override // android.os.CountDownTimer
            public final void onTick(long j2) {
                String str5;
                boolean z3 = equals;
                ShieldWarnActivity shieldWarnActivity = ShieldWarnActivity.this;
                if (z3) {
                    str5 = (j2 / 1000) + " 秒后将自动强制停止";
                } else if (equals2) {
                    str5 = (j2 / 1000) + " 秒后将自动全面拦截";
                } else if (shieldWarnActivity.g) {
                    str5 = (j2 / 1000) + " 秒后将自动卸载前台应用";
                } else {
                    str5 = (j2 / 1000) + " 秒后将自动拦截卸载";
                }
                shieldWarnActivity.j.setText(str5);
                if (j2 <= 2000) {
                    shieldWarnActivity.j.setTextColor(-48060);
                }
            }
        }.start();
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        CountDownTimer countDownTimer = this.k;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            this.k = null;
        }
        super.onDestroy();
    }
}
