package com.youlong.tool;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Process;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.storage.StorageManager;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.os.EnvironmentCompat;
import com.youlong.gj.StrX;
import com.youlong.tool.DownloadManager;
import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import rikka.shizuku.Shizuku;
import yl.g3;
import yl.i2;
import yl.o3;
import yl.p3;
import yl.q3;
import yl.r3;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class MainActivity extends AppCompatActivity implements SensorEventListener {
    public static final String x = StrX.a(StrX.p);
    public WebView c;
    public ImageButton f;
    public Runnable j;
    public ValueCallback k;
    public SensorManager l;
    public Vibrator m;
    public PermissionRequest o;
    public DownloadManager p;
    public ExecutorService q;
    public FrameLayout r;
    public FrameLayout t;
    public WebChromeClient.CustomViewCallback u;
    public boolean g = false;
    public int h = 0;
    public final Handler i = new Handler();
    public long n = 0;
    public volatile boolean s = false;
    public boolean v = false;
    public final ContentObserver w = new ContentObserver(new Handler()) { // from class: com.youlong.tool.MainActivity.1
        @Override // android.database.ContentObserver
        public final void onChange(boolean z) {
            String str = MainActivity.x;
            AppCompatActivity appCompatActivity = MainActivity.this;
            appCompatActivity.getClass();
            try {
                if (Settings.System.getInt(appCompatActivity.getContentResolver(), "accelerometer_rotation") == 1) {
                    appCompatActivity.setRequestedOrientation(10);
                    return;
                }
            } catch (Settings.SettingNotFoundException unused) {
            }
            appCompatActivity.setRequestedOrientation(1);
        }
    };

    /* renamed from: com.youlong.tool.MainActivity$7, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass7 implements Runnable {
        public AnonymousClass7() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            MainActivity.this.f.setAlpha(0.35f);
        }
    }

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class JavaScriptInterface {
        public JavaScriptInterface() {
        }

        public static void b(File file) {
            if (file != null && file.exists()) {
                File[] listFiles = file.listFiles();
                if (listFiles != null) {
                    for (File file2 : listFiles) {
                        if (file2.isDirectory()) {
                            b(file2);
                        } else {
                            file2.delete();
                        }
                    }
                }
                file.delete();
            }
        }

        public static long c(File file) {
            long c;
            long j = 0;
            if (file != null && file.exists()) {
                File[] listFiles = file.listFiles();
                if (listFiles == null) {
                    return 0L;
                }
                for (File file2 : listFiles) {
                    if (file2.isFile()) {
                        c = file2.length();
                    } else if (file2.isDirectory()) {
                        c = c(file2);
                    }
                    j = c + j;
                }
            }
            return j;
        }

        public static double e() {
            File[] listFiles;
            try {
                long c = c(new File(Environment.getExternalStorageDirectory(), "DCIM/.thumbnails"));
                File file = new File(Environment.getExternalStorageDirectory(), "Download");
                if (file.exists() && (listFiles = file.listFiles()) != null) {
                    for (File file2 : listFiles) {
                        String lowerCase = file2.getName().toLowerCase();
                        if (file2.isFile() && (lowerCase.endsWith(".apk") || lowerCase.endsWith(".zip") || lowerCase.endsWith(".dex"))) {
                            c += file2.length();
                        }
                    }
                }
                return c / 1048576.0d;
            } catch (Exception unused) {
                return 0.0d;
            }
        }

        public final boolean a() {
            AppCompatActivity appCompatActivity = MainActivity.this;
            try {
                AppOpsManager appOpsManager = (AppOpsManager) appCompatActivity.getSystemService("appops");
                if (appOpsManager == null) {
                    return false;
                }
                if (appOpsManager.checkOpNoThrow("android:get_usage_stats", Process.myUid(), appCompatActivity.getPackageName()) != 0) {
                    return false;
                }
                return true;
            } catch (Exception unused) {
                return false;
            }
        }

        @JavascriptInterface
        public void addSingleToBlacklist(String str) {
            if (str != null && !str.isEmpty()) {
                try {
                    SharedPreferences sharedPreferences = MainActivity.this.getSharedPreferences("shield_prefs", 0);
                    String string = sharedPreferences.getString("blacklist_pkgs", "");
                    HashSet hashSet = new HashSet();
                    if (!string.isEmpty()) {
                        for (String str2 : string.split(",")) {
                            String trim = str2.trim();
                            if (!trim.isEmpty()) {
                                hashSet.add(trim);
                            }
                        }
                    }
                    if (hashSet.contains(str)) {
                        return;
                    }
                    hashSet.add(str);
                    StringBuilder sb = new StringBuilder();
                    Iterator it = hashSet.iterator();
                    while (it.hasNext()) {
                        String str3 = (String) it.next();
                        if (sb.length() > 0) {
                            sb.append(",");
                        }
                        sb.append(str3);
                    }
                    sharedPreferences.edit().putString("blacklist_pkgs", sb.toString()).apply();
                } catch (Exception unused) {
                }
            }
        }

        @JavascriptInterface
        public void addToBlacklist(String str) {
            try {
                JSONArray jSONArray = new JSONArray(str);
                SharedPreferences sharedPreferences = MainActivity.this.getSharedPreferences("shield_prefs", 0);
                HashSet hashSet = new HashSet();
                String string = sharedPreferences.getString("blacklist_pkgs", "");
                if (!string.isEmpty()) {
                    for (String str2 : string.split(",")) {
                        String trim = str2.trim();
                        if (!trim.isEmpty()) {
                            hashSet.add(trim);
                        }
                    }
                }
                for (int i = 0; i < jSONArray.length(); i++) {
                    hashSet.add(jSONArray.getString(i));
                }
                StringBuilder sb = new StringBuilder();
                Iterator it = hashSet.iterator();
                while (it.hasNext()) {
                    String str3 = (String) it.next();
                    if (sb.length() > 0) {
                        sb.append(",");
                    }
                    sb.append(str3);
                }
                sharedPreferences.edit().putString("blacklist_pkgs", sb.toString()).apply();
            } catch (Exception unused) {
            }
        }

        @JavascriptInterface
        public void closeApp() {
            MainActivity.this.runOnUiThread(new p3(this, 0));
        }

        public final boolean d() {
            ActivityManager activityManager;
            try {
                activityManager = (ActivityManager) MainActivity.this.getSystemService("activity");
            } catch (Exception unused) {
            }
            if (activityManager == null) {
                return false;
            }
            Iterator<ActivityManager.RunningServiceInfo> it = activityManager.getRunningServices(Integer.MAX_VALUE).iterator();
            while (it.hasNext()) {
                if (ProtectService.class.getName().equals(it.next().service.getClassName())) {
                    return true;
                }
            }
            return false;
        }

        @JavascriptInterface
        public String getAdSkipStats() {
            int i;
            AdSkipService adSkipService = AdSkipService.q;
            if (adSkipService == null) {
                return "{\"today\":0,\"total\":0}";
            }
            SharedPreferences sharedPreferences = adSkipService.getSharedPreferences("adskip_stats", 0);
            if (new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()).equals(sharedPreferences.getString("date", ""))) {
                i = sharedPreferences.getInt("today", 0);
            } else {
                i = 0;
            }
            return "{\"today\":" + i + ",\"total\":" + sharedPreferences.getInt("total", 0) + "}";
        }

        @JavascriptInterface
        public String getBlacklistStatus() {
            try {
                String string = MainActivity.this.getSharedPreferences("shield_prefs", 0).getString("blacklist_pkgs", "");
                ArrayList arrayList = new ArrayList();
                if (!string.isEmpty()) {
                    for (String str : string.split(",")) {
                        String trim = str.trim();
                        if (!trim.isEmpty()) {
                            arrayList.add(trim);
                        }
                    }
                }
                StringBuilder sb = new StringBuilder();
                sb.append("{\"packages\":[");
                Iterator it = arrayList.iterator();
                boolean z = true;
                while (it.hasNext()) {
                    String str2 = (String) it.next();
                    if (!z) {
                        sb.append(",");
                    }
                    sb.append("\"");
                    sb.append(str2);
                    sb.append("\"");
                    z = false;
                }
                sb.append("]}");
                return sb.toString();
            } catch (Exception unused) {
                return "{\"packages\":[]}";
            }
        }

        @JavascriptInterface
        public String getBlockHistory() {
            return MainActivity.this.getSharedPreferences("shield_prefs", 0).getString("block_history", "[]");
        }

        @JavascriptInterface
        public String getDangerScanCache() {
            SharedPreferences sharedPreferences = MainActivity.this.getSharedPreferences("shield_prefs", 0);
            return "{\"apps\":" + sharedPreferences.getString("danger_scan_cache", "[]") + ",\"scanTime\":" + sharedPreferences.getLong("danger_scan_time", 0L) + "}";
        }

        @JavascriptInterface
        public String getInstalledApps() {
            String str;
            try {
                PackageManager packageManager = MainActivity.this.getPackageManager();
                Intent intent = new Intent("android.intent.action.MAIN");
                intent.addCategory("android.intent.category.LAUNCHER");
                List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 0);
                if (queryIntentActivities == null) {
                    return "[]";
                }
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                StringBuilder sb = new StringBuilder();
                sb.append("[");
                boolean z = true;
                for (ResolveInfo resolveInfo : queryIntentActivities) {
                    String str2 = resolveInfo.activityInfo.packageName;
                    if (str2 != null && !linkedHashSet.contains(str2)) {
                        linkedHashSet.add(str2);
                        CharSequence loadLabel = resolveInfo.loadLabel(packageManager);
                        if (loadLabel != null) {
                            str = loadLabel.toString();
                        } else {
                            str = str2;
                        }
                        String replace = str.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
                        if (!z) {
                            sb.append(",");
                        }
                        sb.append("{\"name\":\"");
                        sb.append(replace);
                        sb.append("\",\"pkg\":\"");
                        sb.append(str2);
                        sb.append("\"}");
                        z = false;
                    }
                }
                sb.append("]");
                return sb.toString();
            } catch (Exception unused) {
                return "[]";
            }
        }

        /* JADX WARN: Type inference failed for: r0v0, types: [android.content.Context, com.youlong.tool.MainActivity] */
        @JavascriptInterface
        public String getMissingPermissions() {
            ?? r0 = MainActivity.this;
            return "{\"accessibility\":" + MainActivity.h(r0) + ",\"overlay\":" + Settings.canDrawOverlays(r0) + ",\"usage\":" + a() + "}";
        }

        @JavascriptInterface
        public String getNonSystemApps() {
            String str;
            AppCompatActivity appCompatActivity = MainActivity.this;
            try {
                PackageManager packageManager = appCompatActivity.getPackageManager();
                List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(0);
                StringBuilder sb = new StringBuilder("[");
                boolean z = true;
                for (ApplicationInfo applicationInfo : installedApplications) {
                    String str2 = applicationInfo.packageName;
                    if (str2 != null && !str2.equals(appCompatActivity.getPackageName())) {
                        int i = applicationInfo.flags;
                        if ((i & 1) == 0 && (i & 128) == 0 && ((str = applicationInfo.sourceDir) == null || !str.startsWith("/system/"))) {
                            String replace = applicationInfo.loadLabel(packageManager).toString().replace("\\", "\\\\").replace("\"", "\\\"");
                            if (!z) {
                                sb.append(",");
                            }
                            sb.append("{\"name\":\"");
                            sb.append(replace);
                            sb.append("\",\"pkg\":\"");
                            sb.append(str2);
                            sb.append("\"}");
                            z = false;
                        }
                    }
                }
                sb.append("]");
                return sb.toString();
            } catch (Exception unused) {
                return "[]";
            }
        }

        @JavascriptInterface
        public String getProtectStatus() {
            String str;
            StringBuilder sb;
            AppCompatActivity appCompatActivity = MainActivity.this;
            boolean z = false;
            SharedPreferences sharedPreferences = appCompatActivity.getSharedPreferences("shield_prefs", 0);
            boolean z2 = sharedPreferences.getBoolean("protect_on", false);
            boolean d = d();
            if (z2 && !d) {
                ContextCompat.startForegroundService(appCompatActivity, new Intent((Context) appCompatActivity, (Class<?>) ProtectService.class));
                d = true;
            }
            if (z2 && d) {
                z = true;
            }
            long j = sharedPreferences.getLong("protect_start_time", 0L);
            if (z && j > 0) {
                long currentTimeMillis = System.currentTimeMillis() - j;
                long j2 = currentTimeMillis / 3600000;
                long j3 = (currentTimeMillis % 3600000) / 60000;
                if (j2 > 0) {
                    sb = new StringBuilder();
                    sb.append(j2);
                    sb.append("h");
                } else {
                    sb = new StringBuilder();
                }
                sb.append(j3);
                sb.append("m");
                str = sb.toString();
            } else {
                str = "0m";
            }
            return "{\"on\":" + z + ",\"duration\":\"" + str + "\",\"overlay\":" + Settings.canDrawOverlays(appCompatActivity) + ",\"serviceRunning\":" + d + "}";
        }

        @JavascriptInterface
        public String getSensorData() {
            return "sensorReady";
        }

        @JavascriptInterface
        public boolean getShakeTriggerEnabled() {
            return MainActivity.this.getSharedPreferences("shield_prefs", 0).getBoolean("shake_trigger_on", false);
        }

        @JavascriptInterface
        public String getShieldMode() {
            return MainActivity.this.getSharedPreferences("shield_prefs", 0).getString("shield_mode", "basic");
        }

        @JavascriptInterface
        public boolean getVolumeTriggerEnabled() {
            return MainActivity.this.getSharedPreferences("shield_prefs", 0).getBoolean("volume_trigger_on", false);
        }

        @JavascriptInterface
        public boolean isAdSkipServiceRunning() {
            return AdSkipService.p;
        }

        @JavascriptInterface
        public boolean isPetAppInstalled() {
            try {
                MainActivity.this.getPackageManager().getPackageInfo("com.youlong.zoo", 0);
                return true;
            } catch (PackageManager.NameNotFoundException unused) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean isTrustAllApps() {
            return MainActivity.this.getSharedPreferences("shield_prefs", 0).getBoolean("trust_all_apps", false);
        }

        @JavascriptInterface
        public void launchOrInstallPetApp() {
            MainActivity.this.runOnUiThread(new p3(this, 3));
        }

        @JavascriptInterface
        public void onBlobData(String str) {
            MainActivity.this.runOnUiThread(new q3(this, str, 1));
        }

        @JavascriptInterface
        public void onBlobError(String str) {
            MainActivity.this.runOnUiThread(new q3(this, str, 0));
        }

        @JavascriptInterface
        public void openAccessibilitySettings() {
            MainActivity.this.runOnUiThread(new p3(this, 1));
        }

        @JavascriptInterface
        public void openAppInfo(String str) {
            AppCompatActivity appCompatActivity = MainActivity.this;
            try {
                Intent intent = new Intent("android.intent.action.UNINSTALL_PACKAGE");
                intent.setData(Uri.parse("package:" + str));
                intent.putExtra("android.intent.extra.RETURN_RESULT", true);
                intent.addFlags(268435456);
                appCompatActivity.startActivity(intent);
            } catch (Exception unused) {
                Toast.makeText((Context) appCompatActivity, (CharSequence) "无法打开卸载页面", 0).show();
            }
        }

        @JavascriptInterface
        public void openBlacklistManager() {
            AppCompatActivity appCompatActivity = MainActivity.this;
            Intent intent = new Intent((Context) appCompatActivity, (Class<?>) BlacklistActivity.class);
            intent.addFlags(268435456);
            appCompatActivity.startActivity(intent);
        }

        @JavascriptInterface
        public void openPermSettings(String str) {
            Intent intent;
            boolean equals = "accessibility".equals(str);
            AppCompatActivity appCompatActivity = MainActivity.this;
            if (equals) {
                intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
            } else if ("overlay".equals(str)) {
                intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + appCompatActivity.getPackageName()));
            } else if ("usage".equals(str)) {
                intent = new Intent("android.settings.USAGE_ACCESS_SETTINGS");
            } else {
                intent = null;
            }
            if (intent != null) {
                intent.addFlags(268435456);
                try {
                    appCompatActivity.startActivity(intent);
                } catch (Exception unused) {
                    Toast.makeText((Context) appCompatActivity, (CharSequence) "无法打开设置", 0).show();
                }
            }
        }

        @JavascriptInterface
        public void openShizukuPage() {
            MainActivity.this.runOnUiThread(new p3(this, 2));
        }

        @JavascriptInterface
        public void openStorageSettings() {
            AppCompatActivity appCompatActivity = MainActivity.this;
            try {
                try {
                    Intent intent = new Intent("android.settings.INTERNAL_STORAGE_SETTINGS");
                    intent.addFlags(268435456);
                    appCompatActivity.startActivity(intent);
                } catch (Exception unused) {
                }
            } catch (Exception unused2) {
                Intent intent2 = new Intent("android.settings.MEMORY_CARD_SETTINGS");
                intent2.addFlags(268435456);
                appCompatActivity.startActivity(intent2);
            }
        }

        @JavascriptInterface
        @SuppressLint({"WrongConstant"})
        public String performDeepClean() {
            double d;
            StorageManager storageManager;
            UUID uuid;
            File[] listFiles;
            File[] listFiles2;
            AppCompatActivity appCompatActivity = MainActivity.this;
            try {
                long freeSpace = Environment.getExternalStorageDirectory().getFreeSpace();
                b(new File(Environment.getExternalStorageDirectory(), "DCIM/.thumbnails"));
                b(new File(Environment.getExternalStorageDirectory(), "Pictures/.thumbnails"));
                b(new File(Environment.getExternalStorageDirectory(), "DCIM/.thumb"));
                b(appCompatActivity.getCacheDir());
                b(appCompatActivity.getExternalCacheDir());
                b(new File(appCompatActivity.getCacheDir().getParentFile(), "app_webview"));
                b(new File(appCompatActivity.getCacheDir().getParentFile(), "webview"));
                b(new File(appCompatActivity.getCacheDir().getParentFile(), "databases"));
                b(new File(appCompatActivity.getCacheDir().getParentFile(), "app_database"));
                b(new File(appCompatActivity.getCacheDir().getParentFile(), "app_geolocation"));
                try {
                    appCompatActivity.getCacheDir().getParentFile().delete();
                } catch (Exception unused) {
                }
                File file = new File(Environment.getExternalStorageDirectory(), "Android/data");
                int i = 0;
                if (file.exists() && (listFiles2 = file.listFiles()) != null) {
                    for (File file2 : listFiles2) {
                        b(new File(file2, "cache"));
                        b(new File(file2, "temp"));
                        b(new File(file2, "code_cache"));
                    }
                }
                File file3 = new File(Environment.getExternalStorageDirectory(), "Download");
                if (file3.exists() && (listFiles = file3.listFiles()) != null) {
                    for (File file4 : listFiles) {
                        String lowerCase = file4.getName().toLowerCase();
                        if (file4.isFile() && (lowerCase.endsWith(".apk") || lowerCase.endsWith(".dex") || lowerCase.endsWith(".zip") || lowerCase.endsWith(".rar") || lowerCase.endsWith(".7z") || lowerCase.endsWith(".iso") || lowerCase.endsWith(".tar") || lowerCase.endsWith(".gz") || lowerCase.endsWith(".tmp") || lowerCase.endsWith(".log") || lowerCase.startsWith("bugreport"))) {
                            file4.delete();
                        }
                    }
                }
                File file5 = new File(Environment.getExternalStorageDirectory(), "Android/obb");
                if (file5.exists()) {
                    PackageManager packageManager = appCompatActivity.getPackageManager();
                    File[] listFiles3 = file5.listFiles();
                    if (listFiles3 != null) {
                        for (File file6 : listFiles3) {
                            try {
                                packageManager.getPackageInfo(file6.getName(), 0);
                            } catch (PackageManager.NameNotFoundException unused2) {
                                b(file6);
                            }
                        }
                    }
                }
                b(new File("/data/local/tmp"));
                b(new File("/data/tombstones"));
                b(new File("/data/anr"));
                b(new File("/data/system/dropbox"));
                File[] listFiles4 = Environment.getExternalStorageDirectory().listFiles(new o3(i));
                if (listFiles4 != null) {
                    for (File file7 : listFiles4) {
                        b(file7);
                    }
                }
                String[] strArr = {"/sdcard/tencent/MicroMsg/avatar", "/sdcard/tencent/MicroMsg/sns", "/sdcard/tencent/MicroMsg/video", "/sdcard/tencent/MicroMsg/voice2", "/sdcard/Android/data/com.tencent.mm/cache", "/sdcard/Android/data/com.tencent.mobileqq/cache"};
                for (int i2 = 0; i2 < 6; i2++) {
                    b(new File(strArr[i2]));
                }
                try {
                    if (Build.VERSION.SDK_INT >= 26 && (storageManager = (StorageManager) appCompatActivity.getSystemService("storage")) != null) {
                        Method method = StorageManager.class.getMethod("freeStorageAndNotify", UUID.class, Long.TYPE);
                        uuid = StorageManager.UUID_DEFAULT;
                        method.invoke(storageManager, uuid, 0L);
                    }
                } catch (Exception unused3) {
                }
                double d2 = 0.0d;
                double max = Math.max(0.0d, (Environment.getExternalStorageDirectory().getFreeSpace() - freeSpace) / 1048576.0d);
                Object[] objArr = new Object[1];
                if (max > 0.0d) {
                    d = max;
                } else if (e() > 0.0d) {
                    d = e();
                } else {
                    d = 0.0d;
                }
                objArr[0] = Double.valueOf(d);
                String format = String.format("成功释放 %.1f MB 存储空间", objArr);
                Object[] objArr2 = new Object[2];
                if (max > 0.0d) {
                    d2 = max;
                }
                objArr2[0] = Double.valueOf(d2);
                if (max <= 0.0d) {
                    format = "清理完成！建议重启手机彻底释放系统缓存";
                }
                objArr2[1] = format;
                return String.format("{\"freed\":%.1f,\"message\":\"%s\"}", objArr2);
            } catch (Exception e) {
                return "{\"freed\":0,\"message\":\"清理出错: " + e.getMessage() + "\"}";
            }
        }

        @JavascriptInterface
        public void removeSingleFromBlacklist(String str) {
            if (str != null && !str.isEmpty()) {
                try {
                    SharedPreferences sharedPreferences = MainActivity.this.getSharedPreferences("shield_prefs", 0);
                    String string = sharedPreferences.getString("blacklist_pkgs", "");
                    HashSet hashSet = new HashSet();
                    if (!string.isEmpty()) {
                        for (String str2 : string.split(",")) {
                            String trim = str2.trim();
                            if (!trim.isEmpty()) {
                                hashSet.add(trim);
                            }
                        }
                    }
                    if (!hashSet.contains(str)) {
                        return;
                    }
                    hashSet.remove(str);
                    StringBuilder sb = new StringBuilder();
                    Iterator it = hashSet.iterator();
                    while (it.hasNext()) {
                        String str3 = (String) it.next();
                        if (sb.length() > 0) {
                            sb.append(",");
                        }
                        sb.append(str3);
                    }
                    sharedPreferences.edit().putString("blacklist_pkgs", sb.toString()).apply();
                } catch (Exception unused) {
                }
            }
        }

        @JavascriptInterface
        public void requestAdSkipPermission() {
            openAccessibilitySettings();
        }

        @JavascriptInterface
        public void requestPermission(String str) {
            boolean equals = "overlay".equals(str);
            AppCompatActivity appCompatActivity = MainActivity.this;
            if (equals) {
                if (!Settings.canDrawOverlays(appCompatActivity)) {
                    Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
                    intent.setData(Uri.parse("package:" + appCompatActivity.getPackageName()));
                    intent.addFlags(268435456);
                    appCompatActivity.startActivity(intent);
                    return;
                }
                return;
            }
            if ("usage".equals(str)) {
                Intent intent2 = new Intent("android.settings.USAGE_ACCESS_SETTINGS");
                intent2.addFlags(268435456);
                appCompatActivity.startActivity(intent2);
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:8:0x002e A[Catch: Exception -> 0x0050, TRY_LEAVE, TryCatch #0 {Exception -> 0x0050, blocks: (B:3:0x0004, B:5:0x000e, B:6:0x0028, B:8:0x002e, B:24:0x0055, B:26:0x0066, B:27:0x006c, B:29:0x007d, B:30:0x0082, B:32:0x0093, B:33:0x0098, B:35:0x00a9, B:37:0x00af, B:39:0x00b4, B:41:0x00c3, B:42:0x00c8, B:44:0x00d5, B:46:0x00da, B:49:0x00e1, B:51:0x00f2, B:53:0x00f8, B:55:0x00fe, B:57:0x010e, B:59:0x0116, B:61:0x011e, B:63:0x0126, B:65:0x012e, B:67:0x0136, B:69:0x013e, B:71:0x0146, B:73:0x014e, B:75:0x0156, B:77:0x015e, B:81:0x0166, B:80:0x016c, B:86:0x0174, B:88:0x0185, B:90:0x018b, B:92:0x0191, B:95:0x01a1, B:97:0x01ae, B:98:0x01b5, B:100:0x01c2, B:101:0x01c8, B:103:0x01e3, B:105:0x01f0, B:107:0x01f6, B:110:0x01fb, B:112:0x020a, B:114:0x020e, B:116:0x0219, B:118:0x023a, B:120:0x0247, B:122:0x024d, B:125:0x0252), top: B:2:0x0004 }] */
        @android.webkit.JavascriptInterface
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.String scanAllJunk() {
            /*
                Method dump skipped, instructions count: 725
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.MainActivity.JavaScriptInterface.scanAllJunk():java.lang.String");
        }

        @JavascriptInterface
        public String scanDangerApps() {
            AppCompatActivity appCompatActivity;
            String[] strArr;
            String str;
            AppCompatActivity appCompatActivity2 = MainActivity.this;
            try {
                PackageManager packageManager = appCompatActivity2.getPackageManager();
                List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(128);
                StringBuilder sb = new StringBuilder("[");
                int i = 1;
                boolean z = true;
                for (ApplicationInfo applicationInfo : installedApplications) {
                    if (!applicationInfo.packageName.equals(appCompatActivity2.getPackageName()) && (applicationInfo.flags & i) == 0 && !applicationInfo.packageName.startsWith("com.android.") && !applicationInfo.packageName.startsWith("com.google.") && (strArr = packageManager.getPackageInfo(applicationInfo.packageName, 4096).requestedPermissions) != null) {
                        StringBuilder sb2 = new StringBuilder();
                        int length = strArr.length;
                        int i2 = 0;
                        boolean z2 = false;
                        while (i2 < length) {
                            String str2 = strArr[i2];
                            if (str2 == null) {
                                appCompatActivity = appCompatActivity2;
                            } else {
                                appCompatActivity = appCompatActivity2;
                                if (str2.contains("BIND_DEVICE_ADMIN")) {
                                    if (sb2.length() > 0) {
                                        sb2.append(", ");
                                    }
                                    sb2.append("设备管理器");
                                } else if (str2.contains("SYSTEM_ALERT_WINDOW")) {
                                    if (sb2.length() > 0) {
                                        sb2.append(", ");
                                    }
                                    sb2.append("悬浮窗");
                                } else if (str2.contains("BIND_ACCESSIBILITY_SERVICE")) {
                                    if (sb2.length() > 0) {
                                        sb2.append(", ");
                                    }
                                    sb2.append("无障碍服务");
                                } else if (str2.contains("BIND_NOTIFICATION_LISTENER_SERVICE")) {
                                    if (sb2.length() > 0) {
                                        sb2.append(", ");
                                    }
                                    sb2.append("通知监听");
                                }
                                z2 = true;
                            }
                            try {
                                i2++;
                                appCompatActivity2 = appCompatActivity;
                            } catch (Exception unused) {
                            }
                        }
                        appCompatActivity = appCompatActivity2;
                        if (z2 || BlacklistConstants.a.contains(applicationInfo.packageName)) {
                            String replace = applicationInfo.loadLabel(packageManager).toString().replace("\\", "\\\\").replace("\"", "\\\"");
                            String replace2 = applicationInfo.packageName.replace("\\", "\\\\").replace("\"", "\\\"");
                            String replace3 = sb2.toString().replace("\\", "\\\\").replace("\"", "\\\"");
                            boolean contains = BlacklistConstants.a.contains(applicationInfo.packageName);
                            if (!z) {
                                sb.append(",");
                            }
                            sb.append("{\"name\":\"");
                            sb.append(replace);
                            sb.append("\",\"packageName\":\"");
                            sb.append(replace2);
                            sb.append("\",\"riskPermissions\":\"");
                            sb.append(replace3);
                            sb.append("\",\"isHardcoded\":");
                            sb.append(contains);
                            sb.append(",\"riskLevel\":\"");
                            if (contains) {
                                str = "95%";
                            } else {
                                str = "";
                            }
                            sb.append(str);
                            sb.append("\"");
                            sb.append("}");
                            z = false;
                        }
                        appCompatActivity2 = appCompatActivity;
                        i = 1;
                    }
                    appCompatActivity = appCompatActivity2;
                    appCompatActivity2 = appCompatActivity;
                    i = 1;
                }
                sb.append("]");
                return sb.toString();
            } catch (Exception unused2) {
                return "[]";
            }
        }

        @JavascriptInterface
        public void setShakeTriggerEnabled(boolean z) {
            AppCompatActivity appCompatActivity = MainActivity.this;
            SharedPreferences sharedPreferences = appCompatActivity.getSharedPreferences("shield_prefs", 0);
            sharedPreferences.edit().putBoolean("shake_trigger_on", z).apply();
            if (sharedPreferences.getBoolean("protect_on", false) && z && !d()) {
                ContextCompat.startForegroundService(appCompatActivity, new Intent((Context) appCompatActivity, (Class<?>) ProtectService.class));
            }
        }

        @JavascriptInterface
        public void setShieldMode(String str) {
            MainActivity.this.getSharedPreferences("shield_prefs", 0).edit().putString("shield_mode", str).apply();
        }

        @JavascriptInterface
        public void setVolumeTriggerEnabled(boolean z) {
            AppCompatActivity appCompatActivity = MainActivity.this;
            SharedPreferences sharedPreferences = appCompatActivity.getSharedPreferences("shield_prefs", 0);
            sharedPreferences.edit().putBoolean("volume_trigger_on", z).apply();
            if (sharedPreferences.getBoolean("protect_on", false) && z && !d()) {
                ContextCompat.startForegroundService(appCompatActivity, new Intent((Context) appCompatActivity, (Class<?>) ProtectService.class));
            }
        }

        /* JADX WARN: Type inference failed for: r1v0, types: [android.content.Context, com.youlong.tool.MainActivity] */
        @JavascriptInterface
        public String startProtect() {
            ?? r1 = MainActivity.this;
            boolean h = MainActivity.h(r1);
            boolean canDrawOverlays = Settings.canDrawOverlays(r1);
            boolean a = a();
            StringBuilder sb = new StringBuilder();
            if (!h) {
                if (sb.length() > 0) {
                    sb.append("、");
                }
                sb.append("无障碍");
            }
            if (!canDrawOverlays) {
                if (sb.length() > 0) {
                    sb.append("、");
                }
                sb.append("悬浮窗");
            }
            if (!a) {
                if (sb.length() > 0) {
                    sb.append("、");
                }
                sb.append("使用情况");
            }
            if (sb.length() > 0) {
                if (!canDrawOverlays) {
                    try {
                        Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION");
                        intent.setData(Uri.parse("package:" + r1.getPackageName()));
                        intent.addFlags(268435456);
                        r1.startActivity(intent);
                    } catch (Exception unused) {
                    }
                }
                if (!a) {
                    try {
                        Intent intent2 = new Intent("android.settings.USAGE_ACCESS_SETTINGS");
                        intent2.addFlags(268435456);
                        r1.startActivity(intent2);
                    } catch (Exception unused2) {
                    }
                }
                if (!h) {
                    try {
                        Intent intent3 = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
                        intent3.addFlags(268435456);
                        r1.startActivity(intent3);
                    } catch (Exception unused3) {
                    }
                }
                Toast.makeText((Context) r1, "请先授权：" + sb.toString(), 1).show();
                return "{\"status\":\"need_permission\",\"missing\":\"" + sb.toString() + "\"}";
            }
            r1.getSharedPreferences("shield_prefs", 0).edit().putBoolean("protect_on", true).putLong("protect_start_time", System.currentTimeMillis()).putBoolean("shake_trigger_on", true).putBoolean("volume_trigger_on", false).apply();
            ContextCompat.startForegroundService(r1, new Intent((Context) r1, (Class<?>) ProtectService.class));
            Toast.makeText((Context) r1, "守护已开启", 0).show();
            return "{\"status\":\"started\"}";
        }

        @JavascriptInterface
        public void stopProtect() {
            AppCompatActivity appCompatActivity = MainActivity.this;
            appCompatActivity.getSharedPreferences("shield_prefs", 0).edit().putBoolean("protect_on", false).putBoolean("shake_trigger_on", false).putBoolean("volume_trigger_on", false).apply();
            appCompatActivity.stopService(new Intent((Context) appCompatActivity, (Class<?>) ProtectService.class));
            String str = MainActivity.x;
            appCompatActivity.getClass();
            PendingIntent broadcast = PendingIntent.getBroadcast(appCompatActivity, 0, new Intent((Context) appCompatActivity, (Class<?>) KeepAliveReceiver.class), 201326592);
            AlarmManager alarmManager = (AlarmManager) appCompatActivity.getSystemService(NotificationCompat.CATEGORY_ALARM);
            if (alarmManager != null) {
                alarmManager.cancel(broadcast);
            }
            int i = ProtectService.F;
            try {
                NotificationManager notificationManager = (NotificationManager) appCompatActivity.getSystemService("notification");
                if (notificationManager != null) {
                    for (int i2 = 2000; i2 < 3000; i2++) {
                        notificationManager.cancel(i2);
                    }
                }
            } catch (Exception unused) {
            }
        }

        @JavascriptInterface
        public void triggerShakeAlert() {
            AppCompatActivity appCompatActivity = MainActivity.this;
            Intent intent = new Intent((Context) appCompatActivity, (Class<?>) ProtectService.class);
            intent.setAction("com.youlong.tool.SHAKE_TRIGGER");
            ContextCompat.startForegroundService(appCompatActivity, intent);
        }

        @JavascriptInterface
        public void trustAllApps() {
            String str;
            AppCompatActivity appCompatActivity = MainActivity.this;
            try {
                SharedPreferences sharedPreferences = appCompatActivity.getSharedPreferences("shield_prefs", 0);
                List<ApplicationInfo> installedApplications = appCompatActivity.getPackageManager().getInstalledApplications(0);
                StringBuilder sb = new StringBuilder();
                for (ApplicationInfo applicationInfo : installedApplications) {
                    String str2 = applicationInfo.packageName;
                    if (str2 != null && !str2.equals(appCompatActivity.getPackageName())) {
                        int i = applicationInfo.flags;
                        if ((i & 1) == 0 && (i & 128) == 0 && ((str = applicationInfo.sourceDir) == null || !str.startsWith("/system/"))) {
                            if (sb.length() > 0) {
                                sb.append(",");
                            }
                            sb.append(str2);
                        }
                    }
                }
                sharedPreferences.edit().putString("whitelist_pkgs", sb.toString()).putBoolean("trust_all_apps", true).apply();
                sharedPreferences.edit().putString("blacklist_pkgs", "").apply();
            } catch (Exception unused) {
            }
        }

        @JavascriptInterface
        public void updateAdSkipConfig(String str) {
            String str2;
            String str3;
            boolean z = AdSkipService.p;
            try {
                JSONObject jSONObject = new JSONObject(str);
                boolean optBoolean = jSONObject.optBoolean("enabled", false);
                String str4 = "[]";
                if (jSONObject.optJSONArray("monitorApps") == null) {
                    str2 = "[]";
                } else {
                    str2 = jSONObject.getJSONArray("monitorApps").toString();
                }
                if (jSONObject.optJSONArray("blacklistApps") == null) {
                    str3 = "[]";
                } else {
                    str3 = jSONObject.getJSONArray("blacklistApps").toString();
                }
                if (jSONObject.optJSONArray("customKeywords") != null) {
                    str4 = jSONObject.getJSONArray("customKeywords").toString();
                }
                AdSkipService adSkipService = AdSkipService.q;
                if (adSkipService != null) {
                    adSkipService.getSharedPreferences("adskip_config", 0).edit().putBoolean("enabled", optBoolean).putString("monitor_apps", str2).putString("blacklist_apps", str3).putString("custom_keywords", str4).apply();
                    AdSkipService.q.g();
                } else {
                    AdSkipService.z = optBoolean;
                    AdSkipService.w = str2;
                    AdSkipService.x = str3;
                    AdSkipService.y = str4;
                }
            } catch (JSONException unused) {
            }
        }

        @JavascriptInterface
        public void vibrate(int i) {
            VibrationEffect createOneShot;
            Vibrator vibrator = MainActivity.this.m;
            if (vibrator != null) {
                if (Build.VERSION.SDK_INT >= 26) {
                    createOneShot = VibrationEffect.createOneShot(i, -1);
                    vibrator.vibrate(createOneShot);
                } else {
                    vibrator.vibrate(i);
                }
            }
        }
    }

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class ShizukuBridge {
        public ShizukuBridge() {
        }

        /* JADX WARN: Type inference failed for: r0v1, types: [com.youlong.tool.MainActivity, java.lang.Object, android.app.Activity] */
        @JavascriptInterface
        public String executeCommand(String str) {
            String str2 = MainActivity.x;
            ?? r0 = MainActivity.this;
            r0.getClass();
            if (!MainActivity.m()) {
                return "错误：Shizuku服务未启动，请先安装并启动Shizuku APP";
            }
            if (Shizuku.checkSelfPermission() == 0) {
                r0.q.execute(new r3(this, str, 0));
                return "命令执行中...";
            }
            r0.runOnUiThread(new d(this, 2));
            return "正在请求权限，请在弹窗中授权";
        }

        @JavascriptInterface
        public String getInstalledApps() {
            try {
                PackageManager packageManager = MainActivity.this.getPackageManager();
                List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(128);
                StringBuilder sb = new StringBuilder();
                for (ApplicationInfo applicationInfo : installedApplications) {
                    if ((applicationInfo.flags & 1) == 0) {
                        String charSequence = applicationInfo.loadLabel(packageManager).toString();
                        sb.append("package:");
                        sb.append(applicationInfo.packageName);
                        sb.append(" label:");
                        sb.append(charSequence);
                        sb.append("\n");
                    }
                }
                return sb.toString();
            } catch (Exception e) {
                return "error:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String getServiceStatus() {
            String str = MainActivity.x;
            MainActivity.this.getClass();
            if (!MainActivity.m()) {
                return "Shizuku未启动";
            }
            if (Shizuku.checkSelfPermission() == 0) {
                return "Shizuku已连接";
            }
            return "Shizuku待授权";
        }

        @JavascriptInterface
        public boolean isShizukuReady() {
            String str = MainActivity.x;
            MainActivity.this.getClass();
            if (MainActivity.m() && Shizuku.checkSelfPermission() == 0) {
                return true;
            }
            return false;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0057 A[Catch: all -> 0x0070, Exception -> 0x0072, TRY_ENTER, TryCatch #10 {Exception -> 0x0072, all -> 0x0070, blocks: (B:15:0x004a, B:18:0x0057, B:20:0x0061, B:22:0x0067, B:26:0x0075, B:31:0x008b), top: B:14:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x008b A[Catch: all -> 0x0070, Exception -> 0x0072, TRY_ENTER, TRY_LEAVE, TryCatch #10 {Exception -> 0x0072, all -> 0x0070, blocks: (B:15:0x004a, B:18:0x0057, B:20:0x0061, B:22:0x0067, B:26:0x0075, B:31:0x008b), top: B:14:0x004a }] */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00d0  */
    /* JADX WARN: Removed duplicated region for block: B:61:? A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00cb A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r3v5, types: [com.youlong.tool.MainActivity$WipeInputStream, java.io.InputStream] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static android.webkit.WebResourceResponse g(com.youlong.tool.MainActivity r8, java.lang.String r9) {
        /*
            Method dump skipped, instructions count: 223
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.MainActivity.g(com.youlong.tool.MainActivity, java.lang.String):android.webkit.WebResourceResponse");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static boolean h(MainActivity mainActivity) {
        String string;
        mainActivity.getClass();
        try {
            if (Settings.Secure.getInt(mainActivity.getContentResolver(), "accessibility_enabled") != 1 || (string = Settings.Secure.getString(mainActivity.getContentResolver(), "enabled_accessibility_services")) == null) {
                return false;
            }
            if (!string.contains(mainActivity.getPackageName() + "/")) {
                return false;
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static void i(File file) {
        File[] listFiles;
        if (file.isDirectory() && (listFiles = file.listFiles()) != null) {
            for (File file2 : listFiles) {
                i(file2);
            }
        }
        file.delete();
    }

    public static String k(String str) {
        String lowerCase = str.toLowerCase();
        if (!lowerCase.endsWith(".html") && !lowerCase.endsWith(".htm")) {
            if (lowerCase.endsWith(".css")) {
                return "text/css";
            }
            if (lowerCase.endsWith(".js")) {
                return "application/javascript";
            }
            if (lowerCase.endsWith(".json")) {
                return "application/json";
            }
            if (lowerCase.endsWith(".png")) {
                return "image/png";
            }
            if (!lowerCase.endsWith(".jpg") && !lowerCase.endsWith(".jpeg")) {
                if (lowerCase.endsWith(".webp")) {
                    return "image/webp";
                }
                if (lowerCase.endsWith(".gif")) {
                    return "image/gif";
                }
                if (lowerCase.endsWith(".svg")) {
                    return "image/svg+xml";
                }
                if (lowerCase.endsWith(".ico")) {
                    return "image/x-icon";
                }
                if (lowerCase.endsWith(".mp4")) {
                    return "video/mp4";
                }
                if (lowerCase.endsWith(".mp3")) {
                    return "audio/mpeg";
                }
                if (lowerCase.endsWith(".woff")) {
                    return "font/woff";
                }
                if (lowerCase.endsWith(".woff2")) {
                    return "font/woff2";
                }
                if (lowerCase.endsWith(".ttf")) {
                    return "font/ttf";
                }
                if (lowerCase.endsWith(".txt")) {
                    return "text/plain";
                }
                if (lowerCase.endsWith(".xml")) {
                    return "application/xml";
                }
                if (lowerCase.endsWith(".pdf")) {
                    return "application/pdf";
                }
                return "application/octet-stream";
            }
            return "image/jpeg";
        }
        return "text/html";
    }

    public static boolean m() {
        if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void j() {
        WebChromeClient.CustomViewCallback customViewCallback;
        if (this.v && (customViewCallback = this.u) != null) {
            customViewCallback.onCustomViewHidden();
            this.u = null;
            this.t.removeAllViews();
            this.t.setVisibility(8);
            this.c.setVisibility(0);
            this.v = false;
            getWindow().clearFlags(1024);
        }
    }

    public final void l() {
        int identifier = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (identifier > 0) {
            this.h = getResources().getDimensionPixelSize(identifier);
        }
        if (this.h == 0) {
            this.h = (int) (getResources().getDisplayMetrics().density * 24.0f);
        }
    }

    public final void n(int i) {
        Sensor defaultSensor = this.l.getDefaultSensor(i);
        if (defaultSensor != null) {
            this.l.registerListener(this, defaultSensor, 3);
        }
    }

    public final void o() {
        if (!this.c.canGoBack()) {
            return;
        }
        String originalUrl = this.c.getOriginalUrl();
        if (originalUrl == null) {
            originalUrl = "";
        }
        if (!originalUrl.contains("about:blank") && !originalUrl.isEmpty()) {
            this.c.goBack();
            return;
        }
        this.c.loadUrl(x + "index.html");
    }

    @Override // android.hardware.SensorEventListener
    public final void onAccuracyChanged(Sensor sensor, int i) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void onActivityResult(int i, int i2, Intent intent) {
        Uri[] uriArr;
        String str;
        super/*androidx.fragment.app.FragmentActivity*/.onActivityResult(i, i2, intent);
        DownloadManager downloadManager = this.p;
        if (downloadManager != null && i == 2002) {
            Activity activity = downloadManager.a;
            if (i2 == -1 && intent != null) {
                Uri data = intent.getData();
                if (data != null) {
                    activity.getContentResolver().takePersistableUriPermission(data, 3);
                    downloadManager.g = data;
                    String str2 = downloadManager.e;
                    String str3 = downloadManager.f;
                    HashMap hashMap = downloadManager.d;
                    ExecutorService executorService = downloadManager.c;
                    if (str2 != null && str2.startsWith("blob:") && (str = downloadManager.h) != null) {
                        DownloadManager.BlobDownloadTask blobDownloadTask = new DownloadManager.BlobDownloadTask(str, str3, data);
                        hashMap.put(str3, blobDownloadTask);
                        executorService.execute(blobDownloadTask);
                        downloadManager.e(str3);
                        downloadManager.h = null;
                    } else {
                        DownloadManager.DownloadTask downloadTask = new DownloadManager.DownloadTask(str2, str3, data);
                        hashMap.put(str3, downloadTask);
                        executorService.execute(downloadTask);
                        downloadManager.e(str3);
                    }
                }
            } else {
                downloadManager.h = null;
                Toast.makeText(activity, "用户取消了下载", 0).show();
            }
        }
        if (i == 1000 && this.k != null) {
            if (i2 == -1 && intent != null) {
                ClipData clipData = intent.getClipData();
                if (clipData != null && clipData.getItemCount() > 0) {
                    uriArr = new Uri[clipData.getItemCount()];
                    for (int i3 = 0; i3 < clipData.getItemCount(); i3++) {
                        Uri uri = clipData.getItemAt(i3).getUri();
                        uriArr[i3] = uri;
                        try {
                            getContentResolver().takePersistableUriPermission(uri, 3);
                        } catch (SecurityException | Exception unused) {
                        }
                    }
                } else {
                    Uri data2 = intent.getData();
                    if (data2 != null) {
                        uriArr = new Uri[]{data2};
                        try {
                            getContentResolver().takePersistableUriPermission(data2, 3);
                        } catch (SecurityException | Exception unused2) {
                        }
                    }
                }
                this.k.onReceiveValue(uriArr);
                this.k = null;
            }
            uriArr = null;
            this.k.onReceiveValue(uriArr);
            this.k = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void onBackPressed() {
        if (this.v) {
            j();
            return;
        }
        if (this.c.canGoBack()) {
            o();
        } else {
            if (this.g) {
                super/*androidx.activity.ComponentActivity*/.onBackPressed();
                return;
            }
            this.g = true;
            Toast.makeText((Context) this, (CharSequence) "再按一次退出", 0).show();
            new Handler().postDelayed(new Runnable() { // from class: com.youlong.tool.MainActivity.8
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.g = false;
                }
            }, 2000L);
        }
    }

    public final void onConfigurationChanged(Configuration configuration) {
        FrameLayout frameLayout;
        String str;
        super.onConfigurationChanged(configuration);
        l();
        p();
        WebView webView = this.c;
        if (webView != null) {
            webView.requestLayout();
            int i = getResources().getDisplayMetrics().widthPixels;
            int i2 = getResources().getDisplayMetrics().heightPixels;
            float f = getResources().getDisplayMetrics().density;
            if (configuration.orientation == 2) {
                str = "landscape";
            } else {
                str = "portrait";
            }
            StringBuilder g = i2.g("if(window.onScreenChanged) { window.onScreenChanged({ width:", i, ", height:", i2, ", density:");
            g.append(f);
            g.append(", orientation:'");
            g.append(str);
            g.append("' }); }");
            this.c.evaluateJavascript(g.toString(), null);
        }
        if (this.v && (frameLayout = this.t) != null) {
            frameLayout.requestLayout();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:51:0x025a  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0291  */
    /* JADX WARN: Type inference failed for: r5v4, types: [java.lang.Object, com.youlong.tool.DownloadManager] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onCreate(android.os.Bundle r10) {
        /*
            Method dump skipped, instructions count: 802
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.MainActivity.onCreate(android.os.Bundle):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void onDestroy() {
        WebView webView = this.c;
        if (webView != null) {
            webView.destroy();
        }
        SensorManager sensorManager = this.l;
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        getContentResolver().unregisterContentObserver(this.w);
        ExecutorService executorService = this.q;
        if (executorService != null) {
            executorService.shutdown();
        }
        this.q.execute(new g3(this, 0));
        super.onDestroy();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super/*androidx.fragment.app.FragmentActivity*/.onRequestPermissionsResult(i, strArr, iArr);
        DownloadManager downloadManager = this.p;
        if (downloadManager != null) {
            downloadManager.getClass();
            if (i == 2001) {
                if (iArr.length > 0 && iArr[0] == 0) {
                    downloadManager.f();
                } else {
                    Toast.makeText(downloadManager.a, "没有通知权限，无法显示下载进度", 1).show();
                }
            }
        }
        PermissionRequest permissionRequest = this.o;
        if (permissionRequest != null) {
            permissionRequest.grant(permissionRequest.getResources());
            this.o = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void onResume() {
        super/*androidx.fragment.app.FragmentActivity*/.onResume();
    }

    @Override // android.hardware.SensorEventListener
    public final void onSensorChanged(SensorEvent sensorEvent) {
        String str;
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.n < 200) {
            return;
        }
        this.n = currentTimeMillis;
        int type = sensorEvent.sensor.getType();
        if (type != 1) {
            if (type != 2) {
                if (type != 4) {
                    if (type != 5) {
                        if (type != 6) {
                            if (type != 8) {
                                if (type != 12) {
                                    if (type != 13) {
                                        str = EnvironmentCompat.MEDIA_UNKNOWN;
                                    } else {
                                        str = "temperature";
                                    }
                                } else {
                                    str = "humidity";
                                }
                            } else {
                                str = "proximity";
                            }
                        } else {
                            str = "pressure";
                        }
                    } else {
                        str = "light";
                    }
                } else {
                    str = "gyroscope";
                }
            } else {
                str = "magnetic";
            }
        } else {
            str = "accelerometer";
        }
        float[] fArr = sensorEvent.values;
        this.c.evaluateJavascript("if(window.onSensorData) window.onSensorData('" + str + "', " + Arrays.toString(fArr) + ");", null);
    }

    public final void p() {
        View findViewById = findViewById(R.id.statusBarSpacer);
        ViewGroup.LayoutParams layoutParams = findViewById.getLayoutParams();
        layoutParams.height = (int) (getResources().getDisplayMetrics().density * 1.0f);
        findViewById.setLayoutParams(layoutParams);
        ConstraintLayout.LayoutParams layoutParams2 = (ConstraintLayout.LayoutParams) this.f.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin = ((int) (getResources().getDisplayMetrics().density * 8.0f)) + 50;
        this.f.setLayoutParams(layoutParams2);
    }

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public static class WipeInputStream extends InputStream {
        public byte[] c;
        public int f;
        public int g;

        public final void a() {
            byte[] bArr = this.c;
            if (bArr != null) {
                Arrays.fill(bArr, (byte) 0);
                this.c = null;
            }
        }

        @Override // java.io.InputStream
        public final int available() {
            if (this.c == null) {
                return 0;
            }
            return this.g - this.f;
        }

        @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
            a();
        }

        @Override // java.io.InputStream
        public final int read() {
            byte[] bArr = this.c;
            if (bArr == null) {
                return -1;
            }
            int i = this.f;
            if (i >= this.g) {
                a();
                return -1;
            }
            this.f = i + 1;
            return bArr[i] & 255;
        }

        @Override // java.io.InputStream
        public final long skip(long j) {
            if (this.c == null || j <= 0) {
                return 0L;
            }
            int i = this.f;
            int i2 = this.g;
            int min = (int) Math.min(j, i2 - i);
            int i3 = this.f + min;
            this.f = i3;
            if (i3 >= i2) {
                a();
            }
            return min;
        }

        @Override // java.io.InputStream
        public final int read(byte[] bArr, int i, int i2) {
            if (this.c == null) {
                return -1;
            }
            if (i < 0 || i2 < 0 || i2 > bArr.length - i) {
                throw new IndexOutOfBoundsException();
            }
            int i3 = this.f;
            int i4 = this.g;
            if (i3 >= i4) {
                a();
                return -1;
            }
            int min = Math.min(i2, i4 - i3);
            System.arraycopy(this.c, this.f, bArr, i, min);
            int i5 = this.f + min;
            this.f = i5;
            if (i5 >= i4) {
                a();
            }
            return min;
        }
    }
}
