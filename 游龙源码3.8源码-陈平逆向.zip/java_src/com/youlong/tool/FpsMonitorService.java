package com.youlong.tool;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import yl.j0;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class FpsMonitorService extends Service {
    public static WindowManager c = null;
    public static FpsOverlayView f = null;
    public static volatile boolean g = false;

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public static class FpsOverlayView extends View implements Choreographer.FrameCallback {
        public static final /* synthetic */ int E = 0;
        public float A;
        public float B;
        public float C;
        public float D;
        public final Paint c;
        public final Paint f;
        public final Paint g;
        public final Paint h;
        public final Paint i;
        public final RectF j;
        public final RectF k;
        public final Handler l;
        public long m;
        public final long[] n;
        public int o;
        public int p;
        public int q;
        public float r;
        public float s;
        public float t;
        public float u;
        public boolean v;
        public float w;
        public float x;
        public float y;
        public float z;

        public FpsOverlayView(Context context) {
            super(context);
            this.j = new RectF();
            this.k = new RectF();
            this.l = new Handler(Looper.getMainLooper());
            this.m = 0L;
            this.n = new long[30];
            this.o = 0;
            this.p = 0;
            this.q = 0;
            this.v = false;
            setFocusable(false);
            setFocusableInTouchMode(false);
            Paint paint = new Paint(1);
            this.c = paint;
            paint.setColor(Color.argb(220, 20, 20, 20));
            Paint paint2 = new Paint(1);
            this.f = paint2;
            paint2.setStyle(Paint.Style.STROKE);
            paint2.setStrokeWidth(1.5f);
            paint2.setColor(Color.argb(64, 0, 255, 136));
            Paint paint3 = new Paint(1);
            this.g = paint3;
            paint3.setColor(Color.rgb(0, 255, 136));
            Paint.Align align = Paint.Align.CENTER;
            paint3.setTextAlign(align);
            paint3.setFakeBoldText(true);
            Paint paint4 = new Paint(1);
            this.h = paint4;
            paint4.setColor(Color.rgb(255, 71, 87));
            Paint paint5 = new Paint(1);
            this.i = paint5;
            paint5.setColor(-1);
            paint5.setTextAlign(align);
            paint5.setFakeBoldText(true);
        }

        @Override // android.view.Choreographer.FrameCallback
        public final void doFrame(long j) {
            long nanoTime = System.nanoTime();
            long j2 = nanoTime - this.m;
            this.m = nanoTime;
            long[] jArr = this.n;
            if (j2 > 0) {
                int i = this.o;
                jArr[i % jArr.length] = j2;
                this.o = i + 1;
                this.p++;
            }
            if (this.p >= 60) {
                this.p = 0;
                int min = Math.min(this.o, jArr.length);
                long j3 = 0;
                for (int i2 = 0; i2 < min; i2++) {
                    j3 += jArr[i2];
                }
                if (j3 > 0 && min > 0) {
                    this.q = (int) ((min * 1000000000) / j3);
                }
                postInvalidate();
            }
            Choreographer.getInstance().postFrameCallback(this);
        }

        @Override // android.view.View
        public final void onAttachedToWindow() {
            super.onAttachedToWindow();
            float f = getResources().getDisplayMetrics().density;
            this.w = f;
            float f2 = 14.0f * f;
            this.C = f2;
            this.D = 7.0f * f;
            this.A = f2;
            this.z = 22.0f * f;
            this.B = (f * 20.0f) / 2.0f;
            Paint paint = this.g;
            paint.setTextSize(f2);
            this.i.setTextSize(this.w * 10.0f);
            this.x = (this.C * 2.0f) + paint.measureText("88 FPS");
            this.y = (this.w * 4.0f) + (this.D * 2.0f) + this.A;
            this.m = System.nanoTime();
            Choreographer.getInstance().postFrameCallback(this);
        }

        @Override // android.view.View
        public final void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            Choreographer.getInstance().removeFrameCallback(this);
        }

        @Override // android.view.View
        public final void onDraw(Canvas canvas) {
            int rgb;
            super.onDraw(canvas);
            float width = getWidth();
            float height = getHeight();
            RectF rectF = this.j;
            rectF.set(0.0f, 0.0f, width, height);
            float f = this.z;
            canvas.drawRoundRect(rectF, f, f, this.c);
            float f2 = this.z;
            canvas.drawRoundRect(rectF, f2, f2, this.f);
            if (this.q >= 30) {
                rgb = Color.rgb(0, 255, 136);
            } else {
                rgb = Color.rgb(255, 107, 107);
            }
            Paint paint = this.g;
            paint.setColor(rgb);
            canvas.drawText(this.q + " FPS", width / 2.0f, ((this.A * 0.35f) + height) / 2.0f, paint);
            float f3 = this.B;
            float f4 = this.w;
            float f5 = (width - f3) - (f4 * 3.0f);
            float f6 = (f4 * 3.0f) + f3;
            RectF rectF2 = this.k;
            rectF2.set(f5 - f3, f6 - f3, f5 + f3, f3 + f6);
            canvas.drawOval(rectF2, this.h);
            Paint paint2 = this.i;
            canvas.drawText("x", f5, (paint2.getTextSize() * 0.35f) + f6, paint2);
        }

        @Override // android.view.View
        public final void onMeasure(int i, int i2) {
            setMeasuredDimension((int) this.x, (int) this.y);
        }

        @Override // android.view.View
        public final boolean onTouchEvent(MotionEvent motionEvent) {
            float rawX = motionEvent.getRawX();
            float rawY = motionEvent.getRawY();
            int action = motionEvent.getAction();
            if (action != 0) {
                if (action != 1) {
                    if (action != 2) {
                        return super.onTouchEvent(motionEvent);
                    }
                    float f = rawX - this.r;
                    float f2 = rawY - this.s;
                    if (!this.v && (Math.abs(f) > 10.0f || Math.abs(f2) > 10.0f)) {
                        this.v = true;
                    }
                    if (this.v) {
                        WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams) super.getLayoutParams();
                        layoutParams.x = (int) (this.t + f);
                        layoutParams.y = (int) (this.u + f2);
                        FpsMonitorService.c.updateViewLayout(this, layoutParams);
                    }
                    return true;
                }
                if (!this.v) {
                    float x = motionEvent.getX();
                    float y = motionEvent.getY();
                    float width = getWidth();
                    float f3 = this.B;
                    float f4 = this.w;
                    float f5 = x - ((width - f3) - (f4 * 3.0f));
                    float f6 = y - ((f4 * 3.0f) + f3);
                    if (((float) Math.sqrt((f6 * f6) + (f5 * f5))) <= (this.w * 4.0f) + this.B) {
                        this.l.post(new d(this, 0));
                    }
                }
                this.v = false;
                return true;
            }
            this.r = rawX;
            this.s = rawY;
            WindowManager.LayoutParams layoutParams2 = (WindowManager.LayoutParams) super.getLayoutParams();
            this.t = layoutParams2.x;
            this.u = layoutParams2.y;
            this.v = false;
            return true;
        }
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        int i;
        super.onCreate();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            NotificationChannel w = j0.w();
            j0.z(w);
            j0.v(w);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                j0.q(notificationManager, w);
            }
        }
        Intent intent = new Intent(this, (Class<?>) MainActivity.class);
        intent.setFlags(603979776);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, 201326592);
        Intent intent2 = new Intent(this, (Class<?>) FpsMonitorService.class);
        intent2.setAction("com.youlong.tool.action.STOP_FPS");
        startForeground(3001, new NotificationCompat.Builder(this, "fps_monitor_channel").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("帧率监测运行中").setContentText("显示当前屏幕帧率").setPriority(-1).setOngoing(true).setContentIntent(activity).addAction(android.R.drawable.ic_menu_close_clear_cancel, "停止", PendingIntent.getService(this, 1, intent2, 201326592)).build());
        if (f == null) {
            c = (WindowManager) getSystemService("window");
            f = new FpsOverlayView(this);
            if (i2 >= 26) {
                i = 2038;
            } else {
                i = 2006;
            }
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, i, 264, -3);
            layoutParams.gravity = 8388659;
            layoutParams.x = 100;
            layoutParams.y = 300;
            try {
                c.addView(f, layoutParams);
            } catch (Exception unused) {
            }
        }
        g = true;
    }

    @Override // android.app.Service
    public final void onDestroy() {
        FpsOverlayView fpsOverlayView;
        g = false;
        WindowManager windowManager = c;
        if (windowManager != null && (fpsOverlayView = f) != null) {
            try {
                windowManager.removeView(fpsOverlayView);
            } catch (Exception unused) {
            }
        }
        f = null;
        c = null;
        stopForeground(true);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null && "com.youlong.tool.action.STOP_FPS".equals(intent.getAction())) {
            stopSelf();
            return 2;
        }
        return 1;
    }
}
