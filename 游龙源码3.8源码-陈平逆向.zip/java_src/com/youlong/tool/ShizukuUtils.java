package com.youlong.tool;

import java.io.OutputStream;
import java.util.concurrent.TimeUnit;
import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuRemoteProcess;
import yl.m3;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class ShizukuUtils {
    public static boolean a() {
        try {
            if (Shizuku.checkSelfPermission() != 0) {
                return false;
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static boolean b() {
        try {
            if (!Shizuku.pingBinder()) {
                return false;
            }
            if (Shizuku.isPreV11()) {
                return false;
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static String c(String str, long j) {
        if (!b()) {
            return "ERROR:Shizuku服务未启动";
        }
        if (!a()) {
            return "ERROR:Shizuku未授权";
        }
        StringBuilder sb = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        try {
            String trim = str.trim();
            int i = 1;
            int i2 = 0;
            ShizukuRemoteProcess newProcess = Shizuku.newProcess(new String[]{"sh"}, null, null);
            OutputStream outputStream = newProcess.getOutputStream();
            outputStream.write((trim + "\nexit\n").getBytes("UTF-8"));
            outputStream.flush();
            outputStream.close();
            Thread thread = new Thread(new m3(newProcess, sb, 2));
            Thread thread2 = new Thread(new m3(newProcess, sb2, 3));
            thread.start();
            thread2.start();
            long currentTimeMillis = System.currentTimeMillis() + j;
            boolean z = false;
            while (!z) {
                long currentTimeMillis2 = currentTimeMillis - System.currentTimeMillis();
                if (currentTimeMillis2 <= 0) {
                    break;
                }
                try {
                    z = newProcess.waitFor(Math.min(currentTimeMillis2, 200L), TimeUnit.MILLISECONDS);
                } catch (Exception e) {
                    e.getMessage();
                    z = true;
                }
            }
            if (!z) {
                newProcess.destroyForcibly();
                thread.join(500L);
                thread2.join(500L);
                return "ERROR:执行超时（" + j + "ms）";
            }
            thread.join(2000L);
            thread2.join(2000L);
            for (int i3 = 0; i3 < 5; i3++) {
                try {
                    i2 = newProcess.exitValue();
                    break;
                } catch (Exception unused) {
                    if (i3 < 4) {
                        try {
                            Thread.sleep(100L);
                        } catch (InterruptedException unused2) {
                        }
                    }
                }
            }
            i = i2;
            String trim2 = sb.toString().trim();
            String trim3 = sb2.toString().trim();
            trim2.getClass();
            trim3.getClass();
            if (trim2.length() > 0) {
                return trim2;
            }
            if (i == 0) {
                if (trim3.length() <= 0) {
                    return "OK";
                }
                return trim3;
            }
            if (trim3.length() > 0) {
                if (i2 != 0 && i2 != -1) {
                    return "ERROR:执行失败(code:" + i2 + ") " + trim3;
                }
                return trim3;
            }
            if (i2 == 0 || i2 == -1) {
                return "OK";
            }
            return "ERROR:执行失败(code:" + i2 + ")，无输出";
        } catch (Exception e2) {
            return "ERROR:" + e2.getClass().getSimpleName() + ": " + e2.getMessage();
        }
    }
}
