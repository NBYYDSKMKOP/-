package com.youlong.tool;

import android.app.Application;
import android.os.Process;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class YouLongApp extends Application {
    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        if (!SignatureVerifier.verify(this)) {
            Process.killProcess(Process.myPid());
            System.exit(0);
        } else {
            byte[] certSha256Fingerprint = SignatureVerifier.getCertSha256Fingerprint(this);
            if (certSha256Fingerprint != null) {
                AssetsEncryptor.h(certSha256Fingerprint);
            }
        }
    }
}
