package com.youlong.tool;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class AdSkipService extends AccessibilityService {
    public static volatile boolean p = false;
    public static AdSkipService q;
    public static ForegroundChangeListener r;
    public static VolumeChangeListener s;
    public static final String[] t = {"跳过广告", "点击跳过", "跳过", "Skip Ad", "Skip ad", "Skip"};
    public static final String[] u = {"点击跳转", "摇一摇", "广告"};
    public static final String[] v = {"关闭", "close", "dismiss", "取消", "忽略", "x", "×", "不再提示", "忽略提醒"};
    public static String w;
    public static String x;
    public static String y;
    public static boolean z;
    public final Handler c = new Handler(Looper.getMainLooper());
    public long f = 0;
    public HashSet g = new HashSet();
    public HashSet h = new HashSet();
    public HashSet i = new HashSet();
    public boolean j = false;
    public String k = "";
    public long l = 0;
    public String m = "";
    public int n = 1080;
    public int o = 2400;

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public interface ForegroundChangeListener {
        void a(String str);
    }

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public interface VolumeChangeListener {
        void a();
    }

    public static AccessibilityNodeInfo a(AccessibilityNodeInfo accessibilityNodeInfo, ArrayList arrayList) {
        if (accessibilityNodeInfo.isClickable()) {
            return accessibilityNodeInfo;
        }
        AccessibilityNodeInfo parent = accessibilityNodeInfo.getParent();
        for (int i = 0; parent != null && i < 6; i++) {
            arrayList.add(parent);
            if (parent.isClickable()) {
                return parent;
            }
            parent = parent.getParent();
        }
        return null;
    }

    public static boolean e(AccessibilityNodeInfo accessibilityNodeInfo, ArrayList arrayList) {
        String h = h(accessibilityNodeInfo);
        String[] strArr = u;
        for (int i = 0; i < 3; i++) {
            if (h.contains(strArr[i])) {
                return true;
            }
        }
        CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
        if (contentDescription != null) {
            String charSequence = contentDescription.toString();
            for (int i2 = 0; i2 < 3; i2++) {
                if (charSequence.contains(strArr[i2])) {
                    return true;
                }
            }
        }
        for (int i3 = 0; i3 < accessibilityNodeInfo.getChildCount(); i3++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i3);
            if (child != null) {
                arrayList.add(child);
                if (e(child, arrayList)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static String h(AccessibilityNodeInfo accessibilityNodeInfo) {
        StringBuilder sb = new StringBuilder();
        CharSequence text = accessibilityNodeInfo.getText();
        CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
        if (text != null) {
            sb.append(text);
        }
        if (contentDescription != null) {
            sb.append(" ");
            sb.append(contentDescription);
        }
        return sb.toString().toLowerCase().trim();
    }

    public static HashSet i(String str) {
        HashSet hashSet = new HashSet();
        try {
            JSONArray jSONArray = new JSONArray(str);
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                if (jSONObject.has("pkg")) {
                    hashSet.add(jSONObject.getString("pkg"));
                }
            }
        } catch (JSONException unused) {
        }
        return hashSet;
    }

    public final AccessibilityNodeInfo b(ArrayList arrayList) {
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null && !windows.isEmpty()) {
            for (AccessibilityWindowInfo accessibilityWindowInfo : windows) {
                if (accessibilityWindowInfo != null) {
                    AccessibilityNodeInfo root = accessibilityWindowInfo.getRoot();
                    if (root == null) {
                        accessibilityWindowInfo.recycle();
                    } else {
                        arrayList.add(root);
                        if (root.getPackageName() != null) {
                            root.getPackageName().toString();
                        }
                        accessibilityWindowInfo.getType();
                        AccessibilityNodeInfo l = l(root, arrayList);
                        accessibilityWindowInfo.recycle();
                        if (l != null) {
                            return l;
                        }
                    }
                }
            }
            return null;
        }
        AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
        if (rootInActiveWindow != null) {
            arrayList.add(rootInActiveWindow);
            Objects.toString(rootInActiveWindow.getPackageName());
            return l(rootInActiveWindow, arrayList);
        }
        return null;
    }

    public final AccessibilityNodeInfo c(AccessibilityNodeInfo accessibilityNodeInfo, ArrayList arrayList) {
        AccessibilityNodeInfo a;
        if (accessibilityNodeInfo.isVisibleToUser() && f(accessibilityNodeInfo) && h(accessibilityNodeInfo).contains("跳过")) {
            if (accessibilityNodeInfo.isClickable()) {
                a = accessibilityNodeInfo;
            } else {
                a = a(accessibilityNodeInfo, arrayList);
            }
            if (a != null) {
                return a;
            }
            return accessibilityNodeInfo;
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
            if (child != null) {
                arrayList.add(child);
                AccessibilityNodeInfo c = c(child, arrayList);
                if (c != null) {
                    return c;
                }
            }
        }
        return null;
    }

    public final boolean d(int i, int i2) {
        Path path = new Path();
        path.moveTo(i, i2);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0L, 50L));
        final boolean[] zArr = {false};
        final Object obj = new Object();
        if (!dispatchGesture(builder.build(), new AccessibilityService.GestureResultCallback() { // from class: com.youlong.tool.AdSkipService.1
            @Override // android.accessibilityservice.AccessibilityService.GestureResultCallback
            public final void onCancelled(GestureDescription gestureDescription) {
                synchronized (obj) {
                    zArr[0] = false;
                    obj.notify();
                }
            }

            @Override // android.accessibilityservice.AccessibilityService.GestureResultCallback
            public final void onCompleted(GestureDescription gestureDescription) {
                synchronized (obj) {
                    zArr[0] = true;
                    obj.notify();
                }
            }
        }, null)) {
            return false;
        }
        synchronized (obj) {
            try {
                obj.wait(500L);
            } catch (InterruptedException unused) {
            }
        }
        return zArr[0];
    }

    public final boolean f(AccessibilityNodeInfo accessibilityNodeInfo) {
        Rect rect = new Rect();
        accessibilityNodeInfo.getBoundsInScreen(rect);
        int width = rect.width();
        int height = rect.height();
        if (width <= 2 || height <= 2) {
            return false;
        }
        if (width > this.n * 0.95d && height > this.o * 0.85d) {
            return false;
        }
        return true;
    }

    public final void g() {
        SharedPreferences sharedPreferences = getSharedPreferences("adskip_config", 0);
        boolean z2 = sharedPreferences.getBoolean("enabled", false);
        this.g = i(sharedPreferences.getString("monitor_apps", "[]"));
        this.h = i(sharedPreferences.getString("blacklist_apps", "[]"));
        String string = sharedPreferences.getString("custom_keywords", "[]");
        HashSet hashSet = new HashSet();
        try {
            JSONArray jSONArray = new JSONArray(string);
            for (int i = 0; i < jSONArray.length(); i++) {
                String lowerCase = jSONArray.getString(i).trim().toLowerCase();
                if (!lowerCase.isEmpty()) {
                    hashSet.add(lowerCase);
                }
            }
        } catch (JSONException unused) {
        }
        this.i = hashSet;
        this.j = z2;
        Objects.toString(this.g);
        Objects.toString(this.i);
    }

    public final void j() {
        int i;
        SharedPreferences sharedPreferences = getSharedPreferences("adskip_stats", 0);
        String format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        if (format.equals(sharedPreferences.getString("date", ""))) {
            i = sharedPreferences.getInt("today", 0) + 1;
        } else {
            i = 1;
        }
        sharedPreferences.edit().putInt("today", i).putInt("total", sharedPreferences.getInt("total", 0) + 1).putString("date", format).apply();
    }

    public final AccessibilityNodeInfo k(AccessibilityNodeInfo accessibilityNodeInfo, ArrayList arrayList) {
        boolean z2;
        boolean z3;
        if (accessibilityNodeInfo.isVisibleToUser() && accessibilityNodeInfo.isClickable()) {
            Rect rect = new Rect();
            accessibilityNodeInfo.getBoundsInScreen(rect);
            int width = rect.width();
            int height = rect.height();
            boolean z4 = true;
            if (width >= 10 && width <= 90 && height >= 10 && height <= 90) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (rect.top < this.o * 0.15d) {
                z3 = true;
            } else {
                z3 = false;
            }
            if (accessibilityNodeInfo.getText() != null && !accessibilityNodeInfo.getText().toString().trim().isEmpty()) {
                z4 = false;
            }
            if (z2 && z3 && z4) {
                rect.toShortString();
                return accessibilityNodeInfo;
            }
            if (z2 && z3 && rect.left > this.n * 0.5d) {
                rect.toShortString();
                return accessibilityNodeInfo;
            }
        }
        for (int i = 0; i < accessibilityNodeInfo.getChildCount(); i++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
            if (child != null) {
                arrayList.add(child);
                AccessibilityNodeInfo k = k(child, arrayList);
                if (k != null) {
                    if (!accessibilityNodeInfo.isClickable()) {
                        accessibilityNodeInfo = a(accessibilityNodeInfo, arrayList);
                    }
                    if (accessibilityNodeInfo != null) {
                        return accessibilityNodeInfo;
                    }
                    return k;
                }
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:51:0x0024, code lost:
    
        if (f(r2) != false) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x002b, code lost:
    
        if (r2 != null) goto L17;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.accessibility.AccessibilityNodeInfo l(android.view.accessibility.AccessibilityNodeInfo r18, java.util.ArrayList r19) {
        /*
            r17 = this;
            r0 = r17
            r1 = r19
            boolean r2 = e(r18, r19)
            r3 = 0
            if (r2 != 0) goto Ld
        Lb:
            r2 = r3
            goto L2d
        Ld:
            android.view.accessibility.AccessibilityNodeInfo r2 = r17.c(r18, r19)
            if (r2 == 0) goto L27
            boolean r4 = r2.isClickable()
            if (r4 == 0) goto L1a
            goto L1e
        L1a:
            android.view.accessibility.AccessibilityNodeInfo r2 = a(r2, r1)
        L1e:
            if (r2 == 0) goto L27
            boolean r4 = r0.f(r2)
            if (r4 == 0) goto L27
            goto L2d
        L27:
            android.view.accessibility.AccessibilityNodeInfo r2 = r17.k(r18, r19)
            if (r2 == 0) goto Lb
        L2d:
            if (r2 == 0) goto L30
            return r2
        L30:
            java.lang.String r4 = "跳过广告"
            java.lang.String r5 = "点击跳过"
            java.lang.String r6 = "跳过"
            java.lang.String r7 = "关闭广告"
            java.lang.String r8 = "关闭"
            java.lang.String r9 = "Skip Ad"
            java.lang.String r10 = "Skip ad"
            java.lang.String r11 = "Skip"
            java.lang.String r12 = "close"
            java.lang.String r13 = "dismiss"
            java.lang.String r14 = "忽略"
            java.lang.String r15 = "不再提示"
            java.lang.String r16 = "忽略提醒"
            java.lang.String[] r2 = new java.lang.String[]{r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16}
            r4 = 0
        L4f:
            r5 = 13
            if (r4 >= r5) goto L8a
            r5 = r2[r4]
            r6 = r18
            java.util.List r5 = r6.findAccessibilityNodeInfosByText(r5)
            if (r5 != 0) goto L5e
            goto L87
        L5e:
            r1.addAll(r5)
            java.util.Iterator r5 = r5.iterator()
        L65:
            boolean r7 = r5.hasNext()
            if (r7 == 0) goto L87
            java.lang.Object r7 = r5.next()
            android.view.accessibility.AccessibilityNodeInfo r7 = (android.view.accessibility.AccessibilityNodeInfo) r7
            if (r7 == 0) goto L65
            boolean r8 = r7.isVisibleToUser()
            if (r8 != 0) goto L7a
            goto L65
        L7a:
            android.view.accessibility.AccessibilityNodeInfo r7 = a(r7, r1)
            if (r7 == 0) goto L65
            boolean r8 = r0.f(r7)
            if (r8 == 0) goto L65
            return r7
        L87:
            int r4 = r4 + 1
            goto L4f
        L8a:
            r6 = r18
            android.view.accessibility.AccessibilityNodeInfo r2 = r17.m(r18, r19)
            if (r2 == 0) goto L93
            return r2
        L93:
            android.view.accessibility.AccessibilityNodeInfo r1 = r17.k(r18, r19)
            if (r1 == 0) goto L9a
            return r1
        L9a:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.AdSkipService.l(android.view.accessibility.AccessibilityNodeInfo, java.util.ArrayList):android.view.accessibility.AccessibilityNodeInfo");
    }

    public final AccessibilityNodeInfo m(AccessibilityNodeInfo accessibilityNodeInfo, ArrayList arrayList) {
        AccessibilityNodeInfo a;
        String lowerCase;
        AccessibilityNodeInfo a2;
        AccessibilityNodeInfo a3;
        AccessibilityNodeInfo a4;
        AccessibilityNodeInfo a5;
        if (accessibilityNodeInfo.isVisibleToUser() && f(accessibilityNodeInfo)) {
            String h = h(accessibilityNodeInfo);
            String[] strArr = t;
            for (int i = 0; i < 6; i++) {
                if (h.contains(strArr[i])) {
                    if (accessibilityNodeInfo.isClickable()) {
                        a5 = accessibilityNodeInfo;
                    } else {
                        a5 = a(accessibilityNodeInfo, arrayList);
                    }
                    if (a5 != null) {
                        return a5;
                    }
                    return accessibilityNodeInfo;
                }
            }
            String[] strArr2 = v;
            for (int i2 = 0; i2 < 9; i2++) {
                if (h.contains(strArr2[i2])) {
                    if (accessibilityNodeInfo.isClickable()) {
                        a4 = accessibilityNodeInfo;
                    } else {
                        a4 = a(accessibilityNodeInfo, arrayList);
                    }
                    if (a4 != null) {
                        return a4;
                    }
                    return accessibilityNodeInfo;
                }
            }
            if (!h.matches(".*跳过\\s*\\d+\\s*[s秒]?.*") && !h.matches(".*\\d+\\s*[s秒]\\s*(后|跳过|关闭).*")) {
                if (accessibilityNodeInfo.getViewIdResourceName() == null) {
                    lowerCase = null;
                } else {
                    lowerCase = accessibilityNodeInfo.getViewIdResourceName().toString().toLowerCase();
                }
                if (lowerCase != null && (lowerCase.contains("skip") || lowerCase.contains("close") || lowerCase.contains("dismiss"))) {
                    if (accessibilityNodeInfo.isClickable()) {
                        a3 = accessibilityNodeInfo;
                    } else {
                        a3 = a(accessibilityNodeInfo, arrayList);
                    }
                    if (a3 != null) {
                        return a3;
                    }
                    return accessibilityNodeInfo;
                }
                Iterator it = this.i.iterator();
                while (it.hasNext()) {
                    String str = (String) it.next();
                    if (!str.isEmpty() && h.contains(str.toLowerCase())) {
                        if (accessibilityNodeInfo.isClickable()) {
                            a2 = accessibilityNodeInfo;
                        } else {
                            a2 = a(accessibilityNodeInfo, arrayList);
                        }
                        if (a2 != null) {
                            return a2;
                        }
                        return accessibilityNodeInfo;
                    }
                }
            } else {
                if (accessibilityNodeInfo.isClickable()) {
                    a = accessibilityNodeInfo;
                } else {
                    a = a(accessibilityNodeInfo, arrayList);
                }
                if (a != null) {
                    return a;
                }
                return accessibilityNodeInfo;
            }
        }
        for (int i3 = 0; i3 < accessibilityNodeInfo.getChildCount(); i3++) {
            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i3);
            if (child != null) {
                arrayList.add(child);
                AccessibilityNodeInfo m = m(child, arrayList);
                if (m != null) {
                    return m;
                }
            }
        }
        return null;
    }

    @Override // android.accessibilityservice.AccessibilityService
    public final void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        CharSequence packageName;
        boolean z2 = this.j;
        Handler handler = this.c;
        if (!z2) {
            handler.removeCallbacksAndMessages(null);
            return;
        }
        if (this.g.isEmpty() || (packageName = accessibilityEvent.getPackageName()) == null) {
            return;
        }
        String charSequence = packageName.toString();
        if (accessibilityEvent.getEventType() == 32) {
            this.k = charSequence;
            ForegroundChangeListener foregroundChangeListener = r;
            if (foregroundChangeListener != null) {
                foregroundChangeListener.a(charSequence);
            }
            if (charSequence != null && this.g.contains(charSequence) && !this.h.contains(charSequence)) {
                int i = 1;
                handler.postDelayed(new d(this, i), 1500L);
                handler.postDelayed(new d(this, i), 4000L);
            }
        }
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        q = this;
        WindowManager windowManager = (WindowManager) getSystemService("window");
        if (windowManager != null) {
            Point point = new Point();
            Display defaultDisplay = windowManager.getDefaultDisplay();
            if (defaultDisplay != null) {
                defaultDisplay.getRealSize(point);
                this.n = point.x;
                this.o = point.y;
            }
        }
        if (w != null || x != null || y != null) {
            SharedPreferences.Editor putBoolean = getSharedPreferences("adskip_config", 0).edit().putBoolean("enabled", z);
            String str = w;
            String str2 = "[]";
            if (str == null) {
                str = "[]";
            }
            SharedPreferences.Editor putString = putBoolean.putString("monitor_apps", str);
            String str3 = x;
            if (str3 == null) {
                str3 = "[]";
            }
            SharedPreferences.Editor putString2 = putString.putString("blacklist_apps", str3);
            String str4 = y;
            if (str4 != null) {
                str2 = str4;
            }
            putString2.putString("custom_keywords", str2).apply();
            w = null;
            x = null;
            y = null;
            g();
        }
        g();
        Objects.toString(this.g);
    }

    @Override // android.app.Service
    public final void onDestroy() {
        p = false;
        q = null;
        super.onDestroy();
    }

    @Override // android.accessibilityservice.AccessibilityService
    public final void onInterrupt() {
    }

    @Override // android.accessibilityservice.AccessibilityService
    public final boolean onKeyEvent(KeyEvent keyEvent) {
        VolumeChangeListener volumeChangeListener;
        if (keyEvent.getAction() == 0 && keyEvent.getKeyCode() == 25 && (volumeChangeListener = s) != null) {
            volumeChangeListener.a();
        }
        return super.onKeyEvent(keyEvent);
    }

    @Override // android.accessibilityservice.AccessibilityService
    public final void onServiceConnected() {
        super.onServiceConnected();
        p = true;
        try {
            AccessibilityServiceInfo serviceInfo = getServiceInfo();
            if (serviceInfo != null) {
                serviceInfo.flags |= 32;
                setServiceInfo(serviceInfo);
            }
        } catch (Exception unused) {
        }
    }
}
