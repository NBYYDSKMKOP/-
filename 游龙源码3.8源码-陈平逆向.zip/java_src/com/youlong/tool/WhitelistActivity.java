package com.youlong.tool;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class WhitelistActivity extends Activity {
    public static final /* synthetic */ int c = 0;

    /* renamed from: com.youlong.tool.WhitelistActivity$1, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass1 implements View.OnClickListener {
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            throw null;
        }
    }

    /* renamed from: com.youlong.tool.WhitelistActivity$2, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass2 implements View.OnClickListener {
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            int i = WhitelistActivity.c;
            throw null;
        }
    }

    /* renamed from: com.youlong.tool.WhitelistActivity$3, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass3 implements Comparator<AppItem> {
        @Override // java.util.Comparator
        public final int compare(AppItem appItem, AppItem appItem2) {
            appItem.getClass();
            appItem2.getClass();
            throw null;
        }
    }

    /* renamed from: com.youlong.tool.WhitelistActivity$4, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass4 implements DialogInterface.OnClickListener {
        @Override // android.content.DialogInterface.OnClickListener
        public final void onClick(DialogInterface dialogInterface, int i) {
            throw null;
        }
    }

    /* renamed from: com.youlong.tool.WhitelistActivity$5, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass5 implements DialogInterface.OnMultiChoiceClickListener {
        @Override // android.content.DialogInterface.OnMultiChoiceClickListener
        public final void onClick(DialogInterface dialogInterface, int i, boolean z) {
            throw null;
        }
    }

    /* renamed from: com.youlong.tool.WhitelistActivity$6, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass6 implements Comparator<AppItem> {
        @Override // java.util.Comparator
        public final int compare(AppItem appItem, AppItem appItem2) {
            appItem.getClass();
            appItem2.getClass();
            throw null;
        }
    }

    /* renamed from: com.youlong.tool.WhitelistActivity$7, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass7 implements View.OnClickListener {
        @Override // android.view.View.OnClickListener
        public final void onClick(View view) {
            int i = WhitelistActivity.c;
            throw null;
        }
    }

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public static class AppItem {
    }

    static {
        new HashSet(Arrays.asList("com.eg.android.AlipayGphone", "com.tencent.mm", "com.xunmeng.pinduoduo", "com.youlong.zoo", "com.tencent.mobileqq"));
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getPackageManager();
        getSharedPreferences("shield_prefs", 0);
        throw null;
    }
}
