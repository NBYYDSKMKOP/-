package com.youlong.tool;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.SparseIntArray;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.compose.ui.platform.AndroidComposeViewAccessibilityDelegateCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.view.PointerIconCompat;
import androidx.lifecycle.CoroutineLiveDataKt;
import com.youlong.tool.AdSkipService;
import com.youlong.tool.ProtectService;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONArray;
import org.json.JSONObject;
import rikka.shizuku.Shizuku;
import yl.d4;
import yl.j0;
import yl.l3;
import yl.l4;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class ProtectService extends Service implements SensorEventListener {
    public static final /* synthetic */ int F = 0;
    public long c;
    public Handler f;
    public Runnable g;
    public l4 h;
    public PowerManager.WakeLock i;
    public BroadcastReceiver l;
    public BroadcastReceiver m;
    public AudioManager q;
    public Runnable r;
    public Runnable s;
    public SensorManager v;
    public Vibrator w;
    public float x;
    public float y;
    public float z;
    public final HashSet j = new HashSet();
    public final HashSet k = new HashSet();
    public final ArrayList n = new ArrayList();
    public String o = "";
    public long p = 0;
    public int t = -1;
    public final l3 u = new l3(this, 1);
    public long A = 0;
    public int B = 0;
    public long C = 0;
    public final int[] D = {3, 2, 5, 4, 1};
    public final SparseIntArray E = new SparseIntArray();

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.ProtectService$10, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass10 implements Runnable {
        public final /* synthetic */ Runnable[] c;
        public final /* synthetic */ boolean[] f;
        public final /* synthetic */ TextView g;
        public final /* synthetic */ Button h;
        public final /* synthetic */ Button i;
        public final /* synthetic */ String j;
        public final /* synthetic */ TextView k;
        public final /* synthetic */ TextView l;
        public final /* synthetic */ LinearLayout m;
        public final /* synthetic */ WindowManager n;

        /* renamed from: com.youlong.tool.ProtectService$10$1, reason: invalid class name */
        /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
        class AnonymousClass1 implements Runnable {
            public AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public final void run() {
                boolean b = ShizukuUtils.b();
                AnonymousClass10 anonymousClass10 = AnonymousClass10.this;
                if (b && ShizukuUtils.a()) {
                    ShizukuUtils.c("am force-stop " + anonymousClass10.j, 10000L);
                } else {
                    try {
                        Runtime.getRuntime().exec(new String[]{"sh", "-c", "am force-stop " + anonymousClass10.j}).waitFor();
                    } catch (Exception e) {
                        new StringBuilder("ERROR:").append(e.getMessage());
                    }
                }
                ProtectService.this.f.post(new Runnable() { // from class: com.youlong.tool.ProtectService.10.1.1
                    @Override // java.lang.Runnable
                    public final void run() {
                        AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                        AnonymousClass10.this.k.setText("已强制停止：" + AnonymousClass10.this.j);
                        AnonymousClass10.this.k.setTextColor(-11751600);
                        AnonymousClass10.this.l.setText("am force-stop 已执行，是否继续卸载此应用？");
                        AnonymousClass10.this.l.setTextColor(-13312);
                        AnonymousClass10.this.g.setText("5 秒后将自动卸载");
                        AnonymousClass10.this.g.setTextColor(-48060);
                        AnonymousClass10.this.g.setTextSize(18.0f);
                        AnonymousClass10.this.h.setText("立即卸载");
                        AnonymousClass10.this.h.setEnabled(true);
                        AnonymousClass10.this.i.setText("不卸载，关闭");
                        AnonymousClass10.this.i.setTextColor(-1);
                        AnonymousClass10.this.i.setBackgroundColor(-13730510);
                        AnonymousClass10.this.i.setEnabled(true);
                        final AtomicInteger atomicInteger = new AtomicInteger(5);
                        Runnable runnable = new Runnable() { // from class: com.youlong.tool.ProtectService.10.1.1.1
                            @Override // java.lang.Runnable
                            public final void run() {
                                int decrementAndGet = atomicInteger.decrementAndGet();
                                RunnableC00101 runnableC00101 = RunnableC00101.this;
                                if (decrementAndGet > 0) {
                                    AnonymousClass10.this.g.setText(decrementAndGet + " 秒后将自动卸载");
                                    if (decrementAndGet <= 2) {
                                        AnonymousClass10.this.g.setTextColor(-48060);
                                    }
                                    ProtectService.this.f.postDelayed(this, 1000L);
                                    return;
                                }
                                AnonymousClass10.this.g.setText("正在卸载...");
                                AnonymousClass10 anonymousClass102 = AnonymousClass10.this;
                                ProtectService protectService = ProtectService.this;
                                String str = anonymousClass102.j;
                                ProtectService.c(anonymousClass102.n, anonymousClass102.h, anonymousClass102.i, anonymousClass102.m, anonymousClass102.g, protectService, str);
                            }
                        };
                        final Runnable[] runnableArr = {runnable};
                        AnonymousClass10 anonymousClass102 = AnonymousClass10.this;
                        anonymousClass102.c[0] = runnable;
                        ProtectService.this.f.postDelayed(runnableArr[0], 1000L);
                        AnonymousClass10.this.h.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.10.1.1.2
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                Runnable runnable2 = runnableArr[0];
                                RunnableC00101 runnableC00101 = RunnableC00101.this;
                                if (runnable2 != null) {
                                    ProtectService.this.f.removeCallbacks(runnable2);
                                }
                                AnonymousClass10.this.g.setText("正在卸载...");
                                AnonymousClass10 anonymousClass103 = AnonymousClass10.this;
                                ProtectService protectService = ProtectService.this;
                                String str = anonymousClass103.j;
                                LinearLayout linearLayout = anonymousClass103.m;
                                ProtectService.c(anonymousClass103.n, anonymousClass103.h, anonymousClass103.i, linearLayout, anonymousClass103.g, protectService, str);
                            }
                        });
                        AnonymousClass10.this.i.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.10.1.1.3
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                Runnable runnable2 = runnableArr[0];
                                RunnableC00101 runnableC00101 = RunnableC00101.this;
                                if (runnable2 != null) {
                                    ProtectService.this.f.removeCallbacks(runnable2);
                                }
                                AnonymousClass10 anonymousClass103 = AnonymousClass10.this;
                                ProtectService.e(ProtectService.this, anonymousClass103.j, anonymousClass103.l, anonymousClass103.g, anonymousClass103.h, anonymousClass103.i, anonymousClass103.m, anonymousClass103.n);
                            }
                        });
                    }
                });
            }
        }

        public AnonymousClass10(Runnable[] runnableArr, boolean[] zArr, TextView textView, Button button, Button button2, String str, TextView textView2, TextView textView3, LinearLayout linearLayout, WindowManager windowManager) {
            this.c = runnableArr;
            this.f = zArr;
            this.g = textView;
            this.h = button;
            this.i = button2;
            this.j = str;
            this.k = textView2;
            this.l = textView3;
            this.m = linearLayout;
            this.n = windowManager;
        }

        @Override // java.lang.Runnable
        public final void run() {
            Runnable runnable = this.c[0];
            if (runnable != null) {
                ProtectService.this.f.removeCallbacks(runnable);
            }
            this.f[0] = true;
            TextView textView = this.g;
            textView.setText("正在通过 Shizuku 强制停止...");
            textView.setTextColor(-13312);
            this.h.setEnabled(false);
            this.i.setEnabled(false);
            new Thread(new AnonymousClass1()).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.ProtectService$17, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass17 implements Runnable {
        public final /* synthetic */ String c;
        public final /* synthetic */ TextView f;
        public final /* synthetic */ Button g;
        public final /* synthetic */ WindowManager h;
        public final /* synthetic */ LinearLayout i;
        public final /* synthetic */ Button j;
        public final /* synthetic */ ProtectService k;

        public AnonymousClass17(WindowManager windowManager, Button button, Button button2, LinearLayout linearLayout, TextView textView, ProtectService protectService, String str) {
            this.k = protectService;
            this.c = str;
            this.f = textView;
            this.g = button;
            this.h = windowManager;
            this.i = linearLayout;
            this.j = button2;
        }

        @Override // java.lang.Runnable
        public final void run() {
            final String[] strArr = new String[1];
            boolean b = ShizukuUtils.b();
            String str = this.c;
            if (b && ShizukuUtils.a()) {
                strArr[0] = ShizukuUtils.c("pm uninstall " + str, 15000L);
            } else {
                try {
                    Runtime.getRuntime().exec(new String[]{"sh", "-c", "pm uninstall " + str}).waitFor();
                    strArr[0] = "OK(fallback)";
                } catch (Exception e) {
                    strArr[0] = "ERROR:" + e.getMessage();
                }
            }
            this.k.f.post(new Runnable() { // from class: com.youlong.tool.ProtectService.17.1
                @Override // java.lang.Runnable
                public final void run() {
                    AnonymousClass17 anonymousClass17 = AnonymousClass17.this;
                    ProtectService protectService = anonymousClass17.k;
                    String str2 = anonymousClass17.c;
                    int i = ProtectService.F;
                    protectService.getClass();
                    try {
                        protectService.getPackageManager().getPackageInfo(str2, 0);
                    } catch (PackageManager.NameNotFoundException unused) {
                    }
                    if (!strArr[0].contains("Success")) {
                        anonymousClass17.f.setText("⚠ 卸载可能失败，请手动处理");
                        anonymousClass17.f.setTextColor(-48060);
                        anonymousClass17.g.setText("关闭");
                        anonymousClass17.g.setEnabled(true);
                        anonymousClass17.g.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.17.1.1
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                                AnonymousClass17.this.k.C = System.currentTimeMillis();
                                try {
                                    AnonymousClass17 anonymousClass172 = AnonymousClass17.this;
                                    anonymousClass172.h.removeView(anonymousClass172.i);
                                } catch (Exception unused2) {
                                }
                            }
                        });
                        anonymousClass17.j.setVisibility(8);
                    }
                    anonymousClass17.f.setText("✅ 已成功卸载");
                    anonymousClass17.f.setTextColor(-11751600);
                    anonymousClass17.g.setText("关闭");
                    anonymousClass17.g.setEnabled(true);
                    anonymousClass17.g.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.17.1.1
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                            AnonymousClass17.this.k.C = System.currentTimeMillis();
                            try {
                                AnonymousClass17 anonymousClass172 = AnonymousClass17.this;
                                anonymousClass172.h.removeView(anonymousClass172.i);
                            } catch (Exception unused2) {
                            }
                        }
                    });
                    anonymousClass17.j.setVisibility(8);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.ProtectService$21, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass21 implements Runnable {
        public final /* synthetic */ String c;
        public final /* synthetic */ TextView f;
        public final /* synthetic */ Button g;
        public final /* synthetic */ WindowManager h;
        public final /* synthetic */ LinearLayout i;
        public final /* synthetic */ Button j;
        public final /* synthetic */ ProtectService k;

        public AnonymousClass21(WindowManager windowManager, Button button, Button button2, LinearLayout linearLayout, TextView textView, ProtectService protectService, String str) {
            this.k = protectService;
            this.c = str;
            this.f = textView;
            this.g = button;
            this.h = windowManager;
            this.i = linearLayout;
            this.j = button2;
        }

        @Override // java.lang.Runnable
        public final void run() {
            final String[] strArr = new String[1];
            boolean b = ShizukuUtils.b();
            String str = this.c;
            if (b && ShizukuUtils.a()) {
                strArr[0] = ShizukuUtils.c("pm disable-user --user 0 " + str, 15000L);
            } else {
                try {
                    Runtime.getRuntime().exec(new String[]{"sh", "-c", "pm disable-user --user 0 " + str}).waitFor();
                    strArr[0] = "OK(fallback)";
                } catch (Exception e) {
                    strArr[0] = "ERROR:" + e.getMessage();
                }
            }
            this.k.f.post(new Runnable() { // from class: com.youlong.tool.ProtectService.21.1
                @Override // java.lang.Runnable
                public final void run() {
                    AnonymousClass21 anonymousClass21 = AnonymousClass21.this;
                    ProtectService protectService = anonymousClass21.k;
                    String str2 = anonymousClass21.c;
                    int i = ProtectService.F;
                    protectService.getClass();
                    if (!(!protectService.getPackageManager().getApplicationInfo(str2, 0).enabled)) {
                        String[] strArr2 = strArr;
                        if (!strArr2[0].contains("disabled") && !strArr2[0].contains("Success")) {
                            anonymousClass21.f.setText("⚠ 冻结可能失败，请手动处理");
                            anonymousClass21.f.setTextColor(-48060);
                            anonymousClass21.g.setText("关闭");
                            anonymousClass21.g.setEnabled(true);
                            anonymousClass21.g.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.21.1.1
                                @Override // android.view.View.OnClickListener
                                public final void onClick(View view) {
                                    AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                                    AnonymousClass21.this.k.C = System.currentTimeMillis();
                                    try {
                                        AnonymousClass21 anonymousClass212 = AnonymousClass21.this;
                                        anonymousClass212.h.removeView(anonymousClass212.i);
                                    } catch (Exception unused) {
                                    }
                                }
                            });
                            anonymousClass21.j.setVisibility(8);
                        }
                    }
                    anonymousClass21.f.setText("✅ 已冻结 " + anonymousClass21.c);
                    anonymousClass21.f.setTextColor(-11751600);
                    anonymousClass21.g.setText("关闭");
                    anonymousClass21.g.setEnabled(true);
                    anonymousClass21.g.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.21.1.1
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                            AnonymousClass21.this.k.C = System.currentTimeMillis();
                            try {
                                AnonymousClass21 anonymousClass212 = AnonymousClass21.this;
                                anonymousClass212.h.removeView(anonymousClass212.i);
                            } catch (Exception unused) {
                            }
                        }
                    });
                    anonymousClass21.j.setVisibility(8);
                }
            });
        }
    }

    /* renamed from: com.youlong.tool.ProtectService$4, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass4 extends BroadcastReceiver {
        public AnonymousClass4() {
        }

        @Override // android.content.BroadcastReceiver
        public final void onReceive(Context context, Intent intent) {
            String dataString = intent.getDataString();
            if (dataString != null && dataString.startsWith("package:")) {
                ProtectService.this.f.postDelayed(new c(1, this, dataString.substring(8)), 3000L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.ProtectService$6, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass6 implements Runnable {
        public final /* synthetic */ Runnable[] c;
        public final /* synthetic */ boolean[] f;
        public final /* synthetic */ TextView g;
        public final /* synthetic */ Button h;
        public final /* synthetic */ Button i;
        public final /* synthetic */ boolean j;
        public final /* synthetic */ TextView k;
        public final /* synthetic */ String l;
        public final /* synthetic */ TextView m;
        public final /* synthetic */ LinearLayout n;
        public final /* synthetic */ WindowManager o;

        /* renamed from: com.youlong.tool.ProtectService$6$1, reason: invalid class name */
        /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
        class AnonymousClass1 implements Runnable {
            public AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public final void run() {
                String a;
                String sb;
                boolean b = ShizukuUtils.b();
                AnonymousClass6 anonymousClass6 = AnonymousClass6.this;
                if (b && ShizukuUtils.a()) {
                    a = ShizukuUtils.c("pm list packages -3", 15000L);
                } else {
                    a = ProtectService.a(ProtectService.this, "pm list packages -3");
                }
                ArrayList arrayList = new ArrayList();
                if (a != null) {
                    for (String str : a.split("\n")) {
                        String trim = str.trim();
                        if (trim.startsWith("package:")) {
                            String trim2 = trim.substring(8).trim();
                            if (!trim2.isEmpty() && !trim2.equals("com.youlong.tool") && !trim2.equals(ProtectService.this.getPackageName())) {
                                arrayList.add(trim2);
                            }
                        }
                    }
                }
                if (arrayList.isEmpty()) {
                    sb = "";
                } else {
                    StringBuilder sb2 = new StringBuilder();
                    for (int i = 0; i < arrayList.size(); i++) {
                        if (i > 0) {
                            sb2.append("; ");
                        }
                        sb2.append("am force-stop ");
                        sb2.append((String) arrayList.get(i));
                    }
                    sb = sb2.toString();
                }
                if (!sb.isEmpty()) {
                    if (ShizukuUtils.b() && ShizukuUtils.a()) {
                        ShizukuUtils.c(sb, 60000L);
                    } else {
                        ProtectService.a(ProtectService.this, sb);
                    }
                }
                arrayList.size();
                final int size = arrayList.size();
                ProtectService.this.f.post(new Runnable() { // from class: com.youlong.tool.ProtectService.6.1.1
                    @Override // java.lang.Runnable
                    public final void run() {
                        AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                        int i2 = size;
                        if (i2 == 0) {
                            AnonymousClass6.this.g.setText("已全面停止（未发现第三方应用）");
                        } else {
                            AnonymousClass6.this.g.setText("已强制停止 " + i2 + " 个第三方应用");
                        }
                        AnonymousClass6.this.g.setTextColor(-11751600);
                        AnonymousClass6.this.g.setTextSize(16.0f);
                        AnonymousClass6 anonymousClass62 = AnonymousClass6.this;
                        if (!anonymousClass62.j) {
                            anonymousClass62.k.setText("已全面停止：" + AnonymousClass6.this.l);
                            AnonymousClass6.this.k.setTextColor(-11751600);
                            AnonymousClass6.this.m.setText("已全面停止，是否卸载前台应用 " + AnonymousClass6.this.l + " ？");
                            AnonymousClass6.this.m.setTextColor(-13312);
                            AnonymousClass6.this.h.setText("立即卸载");
                            AnonymousClass6.this.h.setEnabled(true);
                            AnonymousClass6.this.i.setText("不卸载，关闭");
                            AnonymousClass6.this.i.setTextColor(-1);
                            AnonymousClass6.this.i.setBackgroundColor(-13730510);
                            AnonymousClass6.this.i.setEnabled(true);
                            AnonymousClass6.this.i.setVisibility(0);
                            final AtomicInteger atomicInteger = new AtomicInteger(5);
                            Runnable runnable = new Runnable() { // from class: com.youlong.tool.ProtectService.6.1.1.1
                                @Override // java.lang.Runnable
                                public final void run() {
                                    int decrementAndGet = atomicInteger.decrementAndGet();
                                    RunnableC00141 runnableC00141 = RunnableC00141.this;
                                    if (decrementAndGet > 0) {
                                        AnonymousClass6.this.g.setText(decrementAndGet + " 秒后将自动卸载");
                                        if (decrementAndGet <= 2) {
                                            AnonymousClass6.this.g.setTextColor(-48060);
                                        }
                                        ProtectService.this.f.postDelayed(this, 1000L);
                                        return;
                                    }
                                    AnonymousClass6.this.g.setText("正在卸载...");
                                    AnonymousClass6 anonymousClass63 = AnonymousClass6.this;
                                    ProtectService protectService = ProtectService.this;
                                    String str2 = anonymousClass63.l;
                                    ProtectService.c(anonymousClass63.o, anonymousClass63.h, anonymousClass63.i, anonymousClass63.n, anonymousClass63.g, protectService, str2);
                                }
                            };
                            final Runnable[] runnableArr = {runnable};
                            AnonymousClass6 anonymousClass63 = AnonymousClass6.this;
                            anonymousClass63.c[0] = runnable;
                            ProtectService.this.f.postDelayed(runnableArr[0], 1000L);
                            AnonymousClass6.this.h.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.6.1.1.2
                                @Override // android.view.View.OnClickListener
                                public final void onClick(View view) {
                                    Runnable runnable2 = runnableArr[0];
                                    RunnableC00141 runnableC00141 = RunnableC00141.this;
                                    if (runnable2 != null) {
                                        ProtectService.this.f.removeCallbacks(runnable2);
                                    }
                                    AnonymousClass6.this.g.setText("正在卸载...");
                                    AnonymousClass6 anonymousClass64 = AnonymousClass6.this;
                                    ProtectService protectService = ProtectService.this;
                                    String str2 = anonymousClass64.l;
                                    LinearLayout linearLayout = anonymousClass64.n;
                                    ProtectService.c(anonymousClass64.o, anonymousClass64.h, anonymousClass64.i, linearLayout, anonymousClass64.g, protectService, str2);
                                }
                            });
                            AnonymousClass6.this.i.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.6.1.1.3
                                @Override // android.view.View.OnClickListener
                                public final void onClick(View view) {
                                    Runnable runnable2 = runnableArr[0];
                                    RunnableC00141 runnableC00141 = RunnableC00141.this;
                                    if (runnable2 != null) {
                                        ProtectService.this.f.removeCallbacks(runnable2);
                                    }
                                    AnonymousClass6 anonymousClass64 = AnonymousClass6.this;
                                    ProtectService.e(ProtectService.this, anonymousClass64.l, anonymousClass64.m, anonymousClass64.g, anonymousClass64.h, anonymousClass64.i, anonymousClass64.n, anonymousClass64.o);
                                }
                            });
                            return;
                        }
                        anonymousClass62.h.setText("关闭");
                        AnonymousClass6.this.h.setEnabled(true);
                        AnonymousClass6.this.h.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.6.1.1.4
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                RunnableC00141 runnableC00141 = RunnableC00141.this;
                                ProtectService.this.C = System.currentTimeMillis();
                                try {
                                    AnonymousClass6 anonymousClass64 = AnonymousClass6.this;
                                    anonymousClass64.o.removeView(anonymousClass64.n);
                                } catch (Exception unused) {
                                }
                            }
                        });
                        AnonymousClass6.this.i.setVisibility(8);
                    }
                });
            }
        }

        public AnonymousClass6(Runnable[] runnableArr, boolean[] zArr, TextView textView, Button button, Button button2, boolean z, TextView textView2, String str, TextView textView3, LinearLayout linearLayout, WindowManager windowManager) {
            this.c = runnableArr;
            this.f = zArr;
            this.g = textView;
            this.h = button;
            this.i = button2;
            this.j = z;
            this.k = textView2;
            this.l = str;
            this.m = textView3;
            this.n = linearLayout;
            this.o = windowManager;
        }

        @Override // java.lang.Runnable
        public final void run() {
            Runnable runnable = this.c[0];
            if (runnable != null) {
                ProtectService.this.f.removeCallbacks(runnable);
            }
            this.f[0] = true;
            TextView textView = this.g;
            textView.setText("正在获取全部第三方应用...");
            textView.setTextColor(-13312);
            this.h.setEnabled(false);
            this.i.setEnabled(false);
            new Thread(new AnonymousClass1()).start();
        }
    }

    public static String a(ProtectService protectService, String str) {
        protectService.getClass();
        try {
            Process exec = Runtime.getRuntime().exec(new String[]{"sh", "-c", str});
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(exec.getInputStream()));
            StringBuilder sb = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    sb.append(readLine);
                    sb.append("\n");
                } else {
                    exec.waitFor();
                    return sb.toString().trim();
                }
            }
        } catch (Exception e) {
            return "ERROR:" + e.getMessage();
        }
    }

    public static void b(WindowManager windowManager, Button button, Button button2, LinearLayout linearLayout, TextView textView, ProtectService protectService, String str) {
        protectService.getClass();
        button.setEnabled(false);
        button2.setEnabled(false);
        textView.setTextColor(-13312);
        new Thread(new AnonymousClass21(windowManager, button, button2, linearLayout, textView, protectService, str)).start();
    }

    public static void c(WindowManager windowManager, Button button, Button button2, LinearLayout linearLayout, TextView textView, ProtectService protectService, String str) {
        protectService.getClass();
        button.setEnabled(false);
        button2.setEnabled(false);
        textView.setTextColor(-13312);
        new Thread(new AnonymousClass17(windowManager, button, button2, linearLayout, textView, protectService, str)).start();
    }

    public static void d(ProtectService protectService, final String str, boolean z) {
        protectService.getClass();
        if (z) {
            try {
                Intent intent = new Intent("android.settings.MANAGE_APPLICATIONS_SETTINGS");
                intent.addFlags(343932932);
                protectService.startActivity(intent);
                return;
            } catch (Exception unused) {
                return;
            }
        }
        try {
            try {
                Intent intent2 = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                intent2.setData(Uri.parse("package:" + str));
                intent2.addFlags(343932932);
                protectService.startActivity(intent2);
            } catch (Exception unused2) {
                Intent intent3 = new Intent("android.settings.MANAGE_APPLICATIONS_SETTINGS");
                intent3.addFlags(343932932);
                protectService.startActivity(intent3);
            }
        } catch (Exception unused3) {
        }
        protectService.f.postDelayed(new Runnable() { // from class: com.youlong.tool.ProtectService.22
            @Override // java.lang.Runnable
            public final void run() {
                String str2 = str;
                ProtectService protectService2 = ProtectService.this;
                try {
                    protectService2.getPackageManager().getPackageInfo(str2, 0);
                    Intent intent4 = new Intent("android.intent.action.UNINSTALL_PACKAGE");
                    intent4.setData(Uri.parse("package:" + str2));
                    intent4.addFlags(268435456);
                    protectService2.startActivity(intent4);
                } catch (PackageManager.NameNotFoundException | Exception unused4) {
                } catch (Exception unused5) {
                    Intent intent5 = new Intent("android.intent.action.DELETE");
                    intent5.setData(Uri.parse("package:" + str2));
                    intent5.addFlags(268435456);
                    protectService2.startActivity(intent5);
                }
            }
        }, CoroutineLiveDataKt.DEFAULT_TIMEOUT);
    }

    public static void e(ProtectService protectService, final String str, TextView textView, final TextView textView2, final Button button, final Button button2, final LinearLayout linearLayout, final WindowManager windowManager) {
        protectService.getClass();
        textView.setText("是否冻结此应用 " + str + " ？（冻结后不可用，可在设置中解冻）");
        textView.setTextColor(-13312);
        textView2.setText("20 秒后将自动冻结");
        textView2.setTextColor(-13312);
        textView2.setTextSize(16.0f);
        button.setText("立即冻结");
        button.setEnabled(true);
        button2.setText("不冻结，关闭");
        button2.setTextColor(-1);
        button2.setBackgroundColor(-13730510);
        button2.setEnabled(true);
        button2.setVisibility(0);
        final AtomicInteger atomicInteger = new AtomicInteger(20);
        Runnable runnable = new Runnable() { // from class: com.youlong.tool.ProtectService.18
            @Override // java.lang.Runnable
            public final void run() {
                int decrementAndGet = atomicInteger.decrementAndGet();
                TextView textView3 = textView2;
                if (decrementAndGet > 0) {
                    textView3.setText(decrementAndGet + " 秒后将自动冻结");
                    if (decrementAndGet <= 3) {
                        textView3.setTextColor(-48060);
                    }
                    ProtectService.this.f.postDelayed(this, 1000L);
                    return;
                }
                textView3.setText("正在冻结...");
                ProtectService protectService2 = ProtectService.this;
                String str2 = str;
                ProtectService.b(windowManager, button, button2, linearLayout, textView2, protectService2, str2);
            }
        };
        final Runnable[] runnableArr = {runnable};
        protectService.f.postDelayed(runnable, 1000L);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Runnable runnable2 = runnableArr[0];
                if (runnable2 != null) {
                    ProtectService.this.f.removeCallbacks(runnable2);
                }
                textView2.setText("正在冻结...");
                ProtectService protectService2 = ProtectService.this;
                String str2 = str;
                TextView textView3 = textView2;
                ProtectService.b(windowManager, button, button2, linearLayout, textView3, protectService2, str2);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.ProtectService.20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                Runnable runnable2 = runnableArr[0];
                ProtectService protectService2 = ProtectService.this;
                if (runnable2 != null) {
                    protectService2.f.removeCallbacks(runnable2);
                }
                protectService2.C = System.currentTimeMillis();
                try {
                    windowManager.removeView(linearLayout);
                } catch (Exception unused) {
                }
            }
        });
    }

    public final Notification f(String str) {
        return new NotificationCompat.Builder(this, "shield_channel").setContentTitle("游龙安全护盾").setContentText(str).setSmallIcon(android.R.drawable.ic_menu_manage).setOngoing(true).setPriority(0).build();
    }

    public final void g() {
        if (getSharedPreferences("shield_prefs", 0).getBoolean("shake_trigger_on", false) || !getSharedPreferences("shield_prefs", 0).getBoolean("volume_trigger_on", false)) {
            return;
        }
        long currentTimeMillis = System.currentTimeMillis();
        ArrayList arrayList = this.n;
        if (!arrayList.isEmpty() && currentTimeMillis - ((Long) arrayList.get(arrayList.size() - 1)).longValue() < 500) {
            return;
        }
        arrayList.add(Long.valueOf(currentTimeMillis));
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            Long l = (Long) it.next();
            if (currentTimeMillis - l.longValue() > 2500) {
                arrayList2.add(l);
            }
        }
        arrayList.removeAll(arrayList2);
        arrayList.size();
        if (arrayList.size() >= 3) {
            arrayList.clear();
            n();
        }
    }

    public final String h() {
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses;
        String[] strArr;
        String substring;
        int indexOf;
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(new String[]{"sh", "-c", "dumpsys window windows 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp'"}).getInputStream(), "UTF-8"));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    String trim = readLine.trim();
                    int indexOf2 = trim.indexOf("u0 ");
                    if (indexOf2 >= 0 && (indexOf = (substring = trim.substring(indexOf2 + 3)).indexOf(47)) > 0) {
                        String trim2 = substring.substring(0, indexOf).trim();
                        if (trim2.contains(".")) {
                            bufferedReader.close();
                            return trim2;
                        }
                    }
                } else {
                    bufferedReader.close();
                    break;
                }
            }
        } catch (Exception unused) {
        }
        try {
            ActivityManager activityManager = (ActivityManager) getSystemService("activity");
            if (activityManager != null && (runningAppProcesses = activityManager.getRunningAppProcesses()) != null) {
                for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
                    if (!runningAppProcessInfo.processName.equals(getPackageName()) && runningAppProcessInfo.importance == 100 && (strArr = runningAppProcessInfo.pkgList) != null && strArr.length > 0) {
                        return strArr[0];
                    }
                }
                return null;
            }
            return null;
        } catch (Exception unused2) {
            return null;
        }
    }

    public final String i() {
        try {
            UsageStatsManager usageStatsManager = (UsageStatsManager) getSystemService("usagestats");
            if (usageStatsManager == null) {
                return null;
            }
            long currentTimeMillis = System.currentTimeMillis();
            List<UsageStats> queryUsageStats = usageStatsManager.queryUsageStats(0, currentTimeMillis - 10000, currentTimeMillis);
            if (queryUsageStats != null && !queryUsageStats.isEmpty()) {
                UsageStats usageStats = null;
                for (UsageStats usageStats2 : queryUsageStats) {
                    if (usageStats2.getLastTimeUsed() > 0 && (usageStats == null || usageStats2.getLastTimeUsed() > usageStats.getLastTimeUsed())) {
                        usageStats = usageStats2;
                    }
                }
                if (usageStats == null) {
                    return null;
                }
                usageStats.getPackageName();
                usageStats.getLastTimeUsed();
                return usageStats.getPackageName();
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }

    public final boolean j(String str) {
        if (str == null || str.equals(getPackageName())) {
            return true;
        }
        try {
            ApplicationInfo applicationInfo = getPackageManager().getApplicationInfo(str, 0);
            int i = applicationInfo.flags;
            if ((i & 1) != 0 || (i & 128) != 0) {
                return true;
            }
            String str2 = applicationInfo.sourceDir;
            if (str2 != null) {
                if (str2.startsWith("/system/")) {
                    return true;
                }
            }
            return false;
        } catch (Exception unused) {
            return true;
        }
    }

    public final void k() {
        HashSet hashSet = this.k;
        hashSet.clear();
        String string = getSharedPreferences("shield_prefs", 0).getString("blacklist_pkgs", "");
        if (!string.isEmpty()) {
            for (String str : string.split(",")) {
                String trim = str.trim();
                if (!trim.isEmpty()) {
                    hashSet.add(trim);
                }
            }
        }
    }

    public final void l() {
        HashSet hashSet = this.j;
        hashSet.clear();
        String string = getSharedPreferences("shield_prefs", 0).getString("whitelist_pkgs", "");
        if (!string.isEmpty()) {
            for (String str : string.split(",")) {
                String trim = str.trim();
                if (!trim.isEmpty()) {
                    hashSet.add(trim);
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0048 A[Catch: SecurityException | Exception -> 0x004c, TryCatch #0 {SecurityException | Exception -> 0x004c, blocks: (B:3:0x0004, B:7:0x0010, B:12:0x0026, B:16:0x0033, B:18:0x0048, B:20:0x0051, B:24:0x005b, B:27:0x0070, B:30:0x008e, B:32:0x00a8, B:33:0x00c0, B:36:0x00e0, B:39:0x00ea, B:41:0x0103, B:44:0x0134, B:51:0x0221, B:51:0x0221, B:56:0x0251, B:56:0x0251, B:77:0x010b, B:79:0x0113, B:80:0x012a, B:85:0x00b0, B:88:0x00bd), top: B:2:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0089  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00a8 A[Catch: SecurityException | Exception -> 0x004c, TryCatch #0 {SecurityException | Exception -> 0x004c, blocks: (B:3:0x0004, B:7:0x0010, B:12:0x0026, B:16:0x0033, B:18:0x0048, B:20:0x0051, B:24:0x005b, B:27:0x0070, B:30:0x008e, B:32:0x00a8, B:33:0x00c0, B:36:0x00e0, B:39:0x00ea, B:41:0x0103, B:44:0x0134, B:51:0x0221, B:51:0x0221, B:56:0x0251, B:56:0x0251, B:77:0x010b, B:79:0x0113, B:80:0x012a, B:85:0x00b0, B:88:0x00bd), top: B:2:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00db  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00e5  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0103 A[Catch: SecurityException | Exception -> 0x004c, TryCatch #0 {SecurityException | Exception -> 0x004c, blocks: (B:3:0x0004, B:7:0x0010, B:12:0x0026, B:16:0x0033, B:18:0x0048, B:20:0x0051, B:24:0x005b, B:27:0x0070, B:30:0x008e, B:32:0x00a8, B:33:0x00c0, B:36:0x00e0, B:39:0x00ea, B:41:0x0103, B:44:0x0134, B:51:0x0221, B:51:0x0221, B:56:0x0251, B:56:0x0251, B:77:0x010b, B:79:0x0113, B:80:0x012a, B:85:0x00b0, B:88:0x00bd), top: B:2:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x012f  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x01bf  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0246  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0132  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0030  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void m(final java.lang.String r30, java.lang.String r31, java.lang.String r32, boolean r33) {
        /*
            Method dump skipped, instructions count: 830
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.ProtectService.m(java.lang.String, java.lang.String, java.lang.String, boolean):void");
    }

    public final void n() {
        String str;
        boolean equals = "extreme".equals(getSharedPreferences("shield_prefs", 0).getString("shield_mode", "basic"));
        AdSkipService adSkipService = AdSkipService.q;
        if (adSkipService != null) {
            str = adSkipService.k;
        } else {
            str = null;
        }
        if (str == null || str.isEmpty()) {
            str = i();
        }
        if (str == null || str.isEmpty()) {
            str = h();
        }
        if ("com.youlong.tool".equals(str)) {
            return;
        }
        if (str != null && !str.isEmpty()) {
            HashSet hashSet = new HashSet();
            hashSet.add("com.larus.nova");
            hashSet.add("com.youlong.zoo");
            hashSet.add("com.smile.gifmaker");
            if (hashSet.contains(str) && !equals) {
                return;
            }
            if (j(str) && !equals) {
                return;
            }
        }
        o(str, 2, "逃生触发", true);
    }

    public final void o(final String str, int i, String str2, boolean z) {
        boolean z2;
        Notification build;
        String str3;
        this.o = str;
        this.p = System.currentTimeMillis();
        this.f.post(new l4(this, 3));
        SharedPreferences sharedPreferences = getSharedPreferences("shield_prefs", 0);
        String string = sharedPreferences.getString("shield_mode", "basic");
        boolean equals = "super".equals(string);
        boolean equals2 = "extreme".equals(string);
        if (!equals && !equals2) {
            z2 = false;
        } else {
            z2 = true;
        }
        m(str, str2, string, z);
        String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        try {
            JSONArray jSONArray = new JSONArray(sharedPreferences.getString("block_history", "[]"));
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("description", "拦截: " + str);
            jSONObject.put("packageName", str);
            jSONObject.put("time", format);
            if (str2.contains("黑名单")) {
                str3 = "blacklist_block";
            } else {
                str3 = "manual_block";
            }
            jSONObject.put("type", str3);
            jSONArray.put(jSONObject);
            if (jSONArray.length() > 50) {
                JSONArray jSONArray2 = new JSONArray();
                for (int length = jSONArray.length() - 50; length < jSONArray.length(); length++) {
                    jSONArray2.put(jSONArray.get(length));
                }
                jSONArray = jSONArray2;
            }
            sharedPreferences.edit().putString("block_history", jSONArray.toString()).apply();
        } catch (Exception unused) {
        }
        if (z2) {
            return;
        }
        try {
            Intent intent = new Intent(this, (Class<?>) ShieldWarnActivity.class);
            intent.putExtra("suspect_package", str);
            intent.putExtra("reason", str2);
            intent.putExtra("warn_count", i);
            intent.putExtra("is_volume_rescue", z);
            intent.putExtra("shield_mode", string);
            intent.addFlags(343932932);
            final PendingIntent activity = PendingIntent.getActivity(this, ((int) System.currentTimeMillis()) % AndroidComposeViewAccessibilityDelegateCompat.ParcelSafeTextLength, intent, 201326592);
            final PendingIntent activity2 = PendingIntent.getActivity(this, ((int) (System.currentTimeMillis() % 100000)) + 1, intent, 201326592);
            final NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
            Intent intent2 = new Intent(this, (Class<?>) NotifyUninstallReceiver.class);
            intent2.putExtra("target_pkg", str);
            final PendingIntent broadcast = PendingIntent.getBroadcast(this, ((int) (System.currentTimeMillis() % 100000)) + 1000, intent2, 201326592);
            if (z) {
                build = new NotificationCompat.Builder(this, "shield_warn_channel").setContentTitle("⚠️ 紧急救援 — 请尽快卸载").setContentText("点击「卸载软件」按钮 → 系统卸载 → 自动跳转设置页").setSmallIcon(android.R.drawable.ic_dialog_alert).setPriority(1).setCategory(NotificationCompat.CATEGORY_ALARM).setFullScreenIntent(activity, true).setContentIntent(activity2).addAction(android.R.drawable.ic_menu_delete, "卸载软件", broadcast).addAction(android.R.drawable.ic_menu_info_details, "打开拦截面板", activity2).setAutoCancel(false).setOngoing(true).build();
            } else {
                build = new NotificationCompat.Builder(this, "shield_warn_channel").setContentTitle("检测到需拦截应用").setContentText(str + " — " + str2).setSmallIcon(android.R.drawable.ic_dialog_alert).setPriority(1).setCategory(NotificationCompat.CATEGORY_ALARM).setFullScreenIntent(activity, true).setContentIntent(activity2).addAction(android.R.drawable.ic_menu_delete, "卸载软件", broadcast).addAction(android.R.drawable.ic_menu_info_details, "打开拦截面板", activity2).setAutoCancel(true).setOngoing(false).setTimeoutAfter(15000L).build();
            }
            final int currentTimeMillis = ((int) (System.currentTimeMillis() % 1000)) + 2000;
            if (notificationManager != null) {
                notificationManager.notify(currentTimeMillis, build);
            }
            if (z) {
                this.t = currentTimeMillis;
                Runnable runnable = new Runnable() { // from class: com.youlong.tool.ProtectService.23
                    @Override // java.lang.Runnable
                    public final void run() {
                        PendingIntent pendingIntent = activity2;
                        String str4 = str;
                        int i2 = currentTimeMillis;
                        NotificationManager notificationManager2 = notificationManager;
                        ProtectService protectService = ProtectService.this;
                        try {
                            SharedPreferences sharedPreferences2 = protectService.getSharedPreferences("shield_prefs", 0);
                            boolean z3 = sharedPreferences2.getBoolean("protect_on", false);
                            boolean z4 = sharedPreferences2.getBoolean("shake_trigger_on", false);
                            boolean z5 = sharedPreferences2.getBoolean("volume_trigger_on", false);
                            if (!z3 && !z4 && !z5) {
                                if (notificationManager2 != null) {
                                    notificationManager2.cancel(i2);
                                    return;
                                }
                                return;
                            }
                            protectService.getPackageManager().getPackageInfo(str4, 0);
                            if (notificationManager2 != null) {
                                notificationManager2.notify(i2, new NotificationCompat.Builder(protectService, "shield_warn_channel").setContentTitle("⚠️ 紧急救援 — 请尽快卸载").setContentText("应用 " + str4 + " 仍未卸载，点击下方按钮操作").setSmallIcon(android.R.drawable.ic_dialog_alert).setPriority(1).setCategory(NotificationCompat.CATEGORY_ALARM).setFullScreenIntent(activity, true).setContentIntent(pendingIntent).addAction(android.R.drawable.ic_menu_delete, "卸载软件", broadcast).addAction(android.R.drawable.ic_menu_info_details, "打开拦截面板", pendingIntent).setAutoCancel(false).setOngoing(true).build());
                            }
                            protectService.f.postDelayed(this, CoroutineLiveDataKt.DEFAULT_TIMEOUT);
                        } catch (PackageManager.NameNotFoundException unused2) {
                            if (notificationManager2 != null) {
                                notificationManager2.cancel(i2);
                            }
                        } catch (Exception unused3) {
                        }
                    }
                };
                this.s = runnable;
                this.f.postDelayed(runnable, CoroutineLiveDataKt.DEFAULT_TIMEOUT);
            }
            try {
                startActivity(intent);
            } catch (Exception unused2) {
            }
            this.f.postDelayed(new Runnable(intent, str) { // from class: com.youlong.tool.ProtectService.24
                public final /* synthetic */ Intent c;

                @Override // java.lang.Runnable
                public final void run() {
                    try {
                        ProtectService.this.startActivity(this.c);
                    } catch (Exception unused3) {
                    }
                }
            }, 500L);
        } catch (Exception unused3) {
        }
    }

    @Override // android.hardware.SensorEventListener
    public final void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        Sensor defaultSensor;
        super.onCreate();
        SharedPreferences sharedPreferences = getSharedPreferences("shield_prefs", 0);
        boolean z = sharedPreferences.getBoolean("protect_on", false);
        boolean z2 = sharedPreferences.getBoolean("shake_trigger_on", false);
        boolean z3 = sharedPreferences.getBoolean("volume_trigger_on", false);
        if (!z && !z2 && !z3) {
            stopSelf();
            return;
        }
        this.c = System.currentTimeMillis();
        getSharedPreferences("shield_prefs", 0).edit().putLong("protect_start_time", this.c).apply();
        this.f = new Handler(Looper.getMainLooper());
        AudioManager audioManager = (AudioManager) getSystemService("audio");
        this.q = audioManager;
        if (audioManager != null) {
            for (int i : this.D) {
                this.E.put(i, this.q.getStreamVolume(i));
            }
        }
        l();
        k();
        NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
        if (notificationManager != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel t = d4.t();
            t.setDescription("游龙安全护盾正在后台守护中");
            j0.v(t);
            j0.q(notificationManager, t);
            NotificationChannel x = d4.x();
            x.setDescription("黑名单应用拦截弹窗");
            x.setBypassDnd(true);
            j0.q(notificationManager, x);
        }
        startForeground(PointerIconCompat.TYPE_CONTEXT_MENU, f("正在守护中 · 0分钟"));
        PowerManager powerManager = (PowerManager) getSystemService("power");
        if (powerManager != null) {
            PowerManager.WakeLock newWakeLock = powerManager.newWakeLock(1, "ProtectService:WakeLock");
            this.i = newWakeLock;
            if (newWakeLock != null) {
                newWakeLock.acquire();
            }
        }
        PendingIntent broadcast = PendingIntent.getBroadcast(this, 0, new Intent(this, (Class<?>) KeepAliveReceiver.class), 201326592);
        AlarmManager alarmManager = (AlarmManager) getSystemService(NotificationCompat.CATEGORY_ALARM);
        if (alarmManager != null) {
            try {
                alarmManager.setInexactRepeating(2, 120000 + SystemClock.elapsedRealtime(), 120000L, broadcast);
            } catch (Exception unused) {
            }
        }
        l4 l4Var = new l4(this, 1);
        this.h = l4Var;
        this.f.postDelayed(l4Var, 60000L);
        AdSkipService.s = new AdSkipService.VolumeChangeListener() { // from class: com.youlong.tool.ProtectService.1
            @Override // com.youlong.tool.AdSkipService.VolumeChangeListener
            public final void a() {
                int i2 = ProtectService.F;
                ProtectService.this.g();
            }
        };
        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() { // from class: com.youlong.tool.ProtectService.2
            @Override // android.content.BroadcastReceiver
            public final void onReceive(Context context, Intent intent) {
                int i2 = ProtectService.F;
                ProtectService.this.g();
            }
        };
        this.l = broadcastReceiver;
        registerReceiver(broadcastReceiver, new IntentFilter("android.media.VOLUME_CHANGED_ACTION"));
        Runnable runnable = new Runnable() { // from class: com.youlong.tool.ProtectService.3
            @Override // java.lang.Runnable
            public final void run() {
                ProtectService protectService = ProtectService.this;
                try {
                    if (protectService.q != null) {
                        boolean z4 = false;
                        for (int i2 : protectService.D) {
                            int streamVolume = protectService.q.getStreamVolume(i2);
                            SparseIntArray sparseIntArray = protectService.E;
                            int i3 = sparseIntArray.get(i2, -1);
                            if (i3 >= 0 && streamVolume < i3) {
                                int i4 = ProtectService.F;
                                z4 = true;
                            }
                            sparseIntArray.put(i2, streamVolume);
                        }
                        if (z4) {
                            protectService.g();
                        }
                    }
                } catch (Exception unused2) {
                }
                protectService.f.removeCallbacks(this);
                protectService.f.postDelayed(this, 120L);
            }
        };
        this.r = runnable;
        this.f.postDelayed(runnable, 120L);
        AdSkipService.r = new AdSkipService.ForegroundChangeListener() { // from class: yl.m4
            @Override // com.youlong.tool.AdSkipService.ForegroundChangeListener
            public final void a(String str) {
                int i2 = ProtectService.F;
                ProtectService protectService = ProtectService.this;
                if (str != null) {
                    if (!str.equals(protectService.getPackageName()) && !protectService.j(str) && !protectService.j.contains(str) && protectService.k.contains(str)) {
                        if (!str.equals(protectService.o) || System.currentTimeMillis() - protectService.p >= 60000) {
                            protectService.o(str, 1, l0.e("检测到黑名单应用（", str, "）"), false);
                            return;
                        }
                        return;
                    }
                    return;
                }
                protectService.getClass();
            }
        };
        this.m = new AnonymousClass4();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.PACKAGE_ADDED");
        intentFilter.addAction("android.intent.action.PACKAGE_REPLACED");
        intentFilter.addDataScheme("package");
        registerReceiver(this.m, intentFilter);
        Runnable runnable2 = new Runnable() { // from class: com.youlong.tool.ProtectService.5
            /* JADX WARN: Code restructure failed: missing block: B:21:0x004a, code lost:
            
                r1 = "检测到黑名单应用（" + r3 + "）";
             */
            /* JADX WARN: Code restructure failed: missing block: B:22:0x0066, code lost:
            
                if (r3.equals(r0.o) == false) goto L24;
             */
            /* JADX WARN: Code restructure failed: missing block: B:24:0x0074, code lost:
            
                if ((java.lang.System.currentTimeMillis() - r0.p) >= 60000) goto L24;
             */
            /* JADX WARN: Code restructure failed: missing block: B:29:0x0077, code lost:
            
                r0.o(r3, 1, r1, false);
             */
            @Override // java.lang.Runnable
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct add '--show-bad-code' argument
            */
            public final void run() {
                /*
                    r8 = this;
                    int r0 = com.youlong.tool.ProtectService.F
                    com.youlong.tool.ProtectService r0 = com.youlong.tool.ProtectService.this
                    r0.l()
                    r0.k()
                    android.content.pm.PackageManager r1 = r0.getPackageManager()     // Catch: java.lang.Exception -> L7b
                    r2 = 0
                    java.util.List r1 = r1.getInstalledApplications(r2)     // Catch: java.lang.Exception -> L7b
                    java.util.Iterator r1 = r1.iterator()     // Catch: java.lang.Exception -> L7b
                L17:
                    boolean r3 = r1.hasNext()     // Catch: java.lang.Exception -> L7b
                    if (r3 == 0) goto L7b
                    java.lang.Object r3 = r1.next()     // Catch: java.lang.Exception -> L7b
                    android.content.pm.ApplicationInfo r3 = (android.content.pm.ApplicationInfo) r3     // Catch: java.lang.Exception -> L7b
                    java.lang.String r3 = r3.packageName     // Catch: java.lang.Exception -> L7b
                    if (r3 == 0) goto L17
                    java.lang.String r4 = r0.getPackageName()     // Catch: java.lang.Exception -> L7b
                    boolean r4 = r3.equals(r4)     // Catch: java.lang.Exception -> L7b
                    if (r4 == 0) goto L32
                    goto L17
                L32:
                    boolean r4 = r0.j(r3)     // Catch: java.lang.Exception -> L7b
                    if (r4 == 0) goto L39
                    goto L17
                L39:
                    java.util.HashSet r4 = r0.j     // Catch: java.lang.Exception -> L7b
                    boolean r4 = r4.contains(r3)     // Catch: java.lang.Exception -> L7b
                    if (r4 == 0) goto L42
                    goto L17
                L42:
                    java.util.HashSet r4 = r0.k     // Catch: java.lang.Exception -> L7b
                    boolean r4 = r4.contains(r3)     // Catch: java.lang.Exception -> L7b
                    if (r4 == 0) goto L17
                    java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L7b
                    r1.<init>()     // Catch: java.lang.Exception -> L7b
                    java.lang.String r4 = "检测到黑名单应用（"
                    r1.append(r4)     // Catch: java.lang.Exception -> L7b
                    r1.append(r3)     // Catch: java.lang.Exception -> L7b
                    java.lang.String r4 = "）"
                    r1.append(r4)     // Catch: java.lang.Exception -> L7b
                    java.lang.String r1 = r1.toString()     // Catch: java.lang.Exception -> L7b
                    java.lang.String r4 = r0.o     // Catch: java.lang.Exception -> L7b
                    boolean r4 = r3.equals(r4)     // Catch: java.lang.Exception -> L7b
                    if (r4 == 0) goto L77
                    long r4 = java.lang.System.currentTimeMillis()     // Catch: java.lang.Exception -> L7b
                    long r6 = r0.p     // Catch: java.lang.Exception -> L7b
                    long r4 = r4 - r6
                    r6 = 60000(0xea60, double:2.9644E-319)
                    int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
                    if (r4 >= 0) goto L77
                    goto L7b
                L77:
                    r4 = 1
                    r0.o(r3, r4, r1, r2)     // Catch: java.lang.Exception -> L7b
                L7b:
                    android.os.Handler r0 = r0.f
                    r1 = 4000(0xfa0, double:1.9763E-320)
                    r0.postDelayed(r8, r1)
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.ProtectService.AnonymousClass5.run():void");
            }
        };
        this.g = runnable2;
        this.f.postDelayed(runnable2, 2000L);
        this.v = (SensorManager) getSystemService("sensor");
        this.w = (Vibrator) getSystemService("vibrator");
        SensorManager sensorManager = this.v;
        if (sensorManager != null && (defaultSensor = sensorManager.getDefaultSensor(1)) != null) {
            this.v.registerListener(this, defaultSensor, 1);
        }
        Shizuku.addBinderDeadListener(this.u);
    }

    @Override // android.app.Service
    public final void onDestroy() {
        super.onDestroy();
        PowerManager.WakeLock wakeLock = this.i;
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                this.i.release();
            } catch (Exception unused) {
            }
        }
        PendingIntent broadcast = PendingIntent.getBroadcast(this, 0, new Intent(this, (Class<?>) KeepAliveReceiver.class), 201326592);
        AlarmManager alarmManager = (AlarmManager) getSystemService(NotificationCompat.CATEGORY_ALARM);
        if (alarmManager != null) {
            alarmManager.cancel(broadcast);
        }
        l4 l4Var = this.h;
        if (l4Var != null) {
            this.f.removeCallbacks(l4Var);
        }
        Runnable runnable = this.g;
        if (runnable != null) {
            this.f.removeCallbacks(runnable);
        }
        Runnable runnable2 = this.r;
        if (runnable2 != null) {
            this.f.removeCallbacks(runnable2);
        }
        Runnable runnable3 = this.s;
        if (runnable3 != null) {
            this.f.removeCallbacks(runnable3);
        }
        if (this.t >= 0) {
            try {
                NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
                if (notificationManager != null) {
                    notificationManager.cancel(this.t);
                }
            } catch (Exception unused2) {
            }
        }
        try {
            unregisterReceiver(this.l);
        } catch (Exception unused3) {
        }
        try {
            unregisterReceiver(this.m);
        } catch (Exception unused4) {
        }
        AdSkipService.s = null;
        SensorManager sensorManager = this.v;
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        try {
            Shizuku.removeBinderDeadListener(this.u);
        } catch (Exception unused5) {
        }
        stopForeground(true);
    }

    @Override // android.hardware.SensorEventListener
    public final void onSensorChanged(SensorEvent sensorEvent) {
        VibrationEffect createOneShot;
        if (sensorEvent.sensor.getType() != 1 || !getSharedPreferences("shield_prefs", 0).getBoolean("shake_trigger_on", false)) {
            return;
        }
        float[] fArr = sensorEvent.values;
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float abs = Math.abs(f - this.x);
        float abs2 = Math.abs(f2 - this.y);
        float abs3 = Math.abs(f3 - this.z);
        this.x = f;
        this.y = f2;
        this.z = f3;
        if (((float) Math.sqrt((abs3 * abs3) + (abs2 * abs2) + (abs * abs))) < 10.0f) {
            return;
        }
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.A < 1500) {
            this.B++;
        } else {
            this.B = 1;
        }
        this.A = currentTimeMillis;
        if (this.B >= 3) {
            this.B = 0;
            if (currentTimeMillis - this.C < 6000) {
                return;
            }
            this.C = currentTimeMillis;
            Vibrator vibrator = this.w;
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    Vibrator vibrator2 = this.w;
                    createOneShot = VibrationEffect.createOneShot(100L, -1);
                    vibrator2.vibrate(createOneShot);
                } else {
                    this.w.vibrate(100L);
                }
            }
            this.f.post(new l4(this, 2));
        }
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        SharedPreferences sharedPreferences = getSharedPreferences("shield_prefs", 0);
        boolean z = sharedPreferences.getBoolean("protect_on", false);
        boolean z2 = sharedPreferences.getBoolean("shake_trigger_on", false);
        boolean z3 = sharedPreferences.getBoolean("volume_trigger_on", false);
        if (!z && !z2 && !z3) {
            try {
                stopForeground(true);
            } catch (Exception unused) {
            }
            stopSelf();
            return 2;
        }
        if (intent != null && "com.youlong.tool.SHAKE_TRIGGER".equals(intent.getAction()) && sharedPreferences.getBoolean("shake_trigger_on", false)) {
            this.f.postDelayed(new l4(this, 0), 200L);
        }
        return 1;
    }
}
