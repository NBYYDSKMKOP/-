package com.youlong.tool;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final /* synthetic */ class d implements Runnable {
    public final /* synthetic */ int c;
    public final /* synthetic */ Object f;

    public /* synthetic */ d(Object obj, int i) {
        this.c = i;
        this.f = obj;
    }

    /* JADX WARN: Code restructure failed: missing block: B:144:0x0234, code lost:
    
        r2.l = r3;
        r2.m = r2.k;
        r2.j();
     */
    /* JADX WARN: Type inference failed for: r0v22, types: [com.youlong.tool.MainActivity, java.lang.Object, android.app.Activity] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 672
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.d.run():void");
    }
}
