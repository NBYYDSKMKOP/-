package com.youlong.tool;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.CoroutineLiveDataKt;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class NotifyUninstallReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(final Context context, Intent intent) {
        final String stringExtra = intent.getStringExtra("target_pkg");
        if (stringExtra != null && !stringExtra.isEmpty()) {
            try {
                Intent intent2 = new Intent("android.intent.action.UNINSTALL_PACKAGE");
                intent2.setData(Uri.parse("package:".concat(stringExtra)));
                intent2.putExtra("android.intent.extra.RETURN_RESULT", true);
                intent2.addFlags(268435456);
                context.startActivity(intent2);
            } catch (Exception unused) {
            }
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.youlong.tool.NotifyUninstallReceiver.1
                @Override // java.lang.Runnable
                public final void run() {
                    try {
                        Intent intent3 = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                        intent3.setData(Uri.parse("package:" + stringExtra));
                        intent3.addFlags(268435456);
                        context.startActivity(intent3);
                    } catch (Exception unused2) {
                    }
                }
            }, CoroutineLiveDataKt.DEFAULT_TIMEOUT);
        }
    }
}
