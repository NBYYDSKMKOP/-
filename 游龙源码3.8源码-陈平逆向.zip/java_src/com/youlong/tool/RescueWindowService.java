package com.youlong.tool;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.app.NotificationCompat;
import androidx.core.view.PointerIconCompat;
import androidx.lifecycle.CoroutineLiveDataKt;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import yl.d4;
import yl.i2;
import yl.j0;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class RescueWindowService extends Service {
    public static final /* synthetic */ int j = 0;
    public WindowManager c;
    public FrameLayout f;
    public CountDownTimer h;
    public String g = "";
    public boolean i = false;

    public static void a(RescueWindowService rescueWindowService) {
        Object[] objArr;
        String str;
        String str2;
        if (!rescueWindowService.i) {
            rescueWindowService.i = true;
            CountDownTimer countDownTimer = rescueWindowService.h;
            if (countDownTimer != null) {
                countDownTimer.cancel();
                rescueWindowService.h = null;
            }
            if (!rescueWindowService.g.isEmpty()) {
                try {
                    Intent intent = new Intent("android.intent.action.DELETE");
                    intent.setData(Uri.parse("package:" + rescueWindowService.g));
                    intent.addFlags(268435456);
                    rescueWindowService.startActivity(intent);
                } catch (Exception unused) {
                }
            }
            if (!rescueWindowService.g.isEmpty()) {
                try {
                    ActivityManager activityManager = (ActivityManager) rescueWindowService.getSystemService("activity");
                    if (activityManager != null) {
                        activityManager.killBackgroundProcesses(rescueWindowService.g);
                    }
                } catch (Exception unused2) {
                }
            }
            if (!rescueWindowService.g.isEmpty()) {
                try {
                    Intent intent2 = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent2.setData(Uri.parse("package:" + rescueWindowService.g));
                    intent2.addFlags(268435456);
                    Notification build = new NotificationCompat.Builder(rescueWindowService, "rescue_channel").setContentTitle("🛡️ 强制停止 " + rescueWindowService.g).setContentText("点击跳转应用详情 → 强制停止").setSmallIcon(android.R.drawable.ic_dialog_alert).setPriority(2).setContentIntent(PendingIntent.getActivity(rescueWindowService, 3, intent2, 201326592)).setAutoCancel(true).build();
                    NotificationManager notificationManager = (NotificationManager) rescueWindowService.getSystemService("notification");
                    if (notificationManager != null) {
                        notificationManager.notify(PointerIconCompat.TYPE_HELP, build);
                    }
                } catch (Exception unused3) {
                }
            }
            FrameLayout frameLayout = rescueWindowService.f;
            if (frameLayout != null && (objArr = (Object[]) frameLayout.getTag()) != null) {
                View view = (View) objArr[0];
                View view2 = (View) objArr[1];
                View view3 = (View) objArr[2];
                View view4 = (View) objArr[3];
                TextView textView = (TextView) objArr[4];
                View view5 = (View) objArr[5];
                if (view != null) {
                    view.setVisibility(8);
                }
                if (view2 != null) {
                    view2.setVisibility(8);
                }
                if (view3 != null) {
                    view3.setVisibility(8);
                }
                String str3 = Build.MANUFACTURER;
                if (str3 != null) {
                    str = str3.toLowerCase();
                } else {
                    str = "";
                }
                HashMap<String, String> hashMap = new HashMap<String, String>() { // from class: com.youlong.tool.RescueWindowService.5
                    {
                        put("samsung", "关机 → 按 音量上+Bixby+电源键 → logo后松开");
                        put("xiaomi", "关机 → 音量下+电源键 → Fastboot → 安全模式");
                        put("redmi", "关机 → 音量下+电源键 → Fastboot → 安全模式");
                        put("oppo", "关机 → 开机时连续按音量下");
                        put("oneplus", "关机 → 开机时连续按音量下");
                        put("vivo", "关机 → 同时按电源键+音量上 → logo后松电源");
                        put("huawei", "关机 → 长按电源键 → 长按「关机」→ 安全模式");
                        put("honor", "关机 → 长按电源键 → 长按「关机」→ 安全模式");
                    }
                };
                String str4 = hashMap.get(str);
                if (str4 == null) {
                    Iterator<Map.Entry<String, String>> it = hashMap.entrySet().iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            break;
                        }
                        Map.Entry<String, String> next = it.next();
                        if (str.contains(next.getKey())) {
                            str4 = next.getValue();
                            break;
                        }
                    }
                }
                if (str4 == null) {
                    str4 = "关机后开机时连续按音量下键";
                }
                if (rescueWindowService.g.isEmpty()) {
                    str2 = "【包名】";
                } else {
                    str2 = rescueWindowService.g;
                }
                String str5 = "🔴 步骤1：进入安全模式\n    " + str4 + "\n\n\u1f7e0 步骤2：强制停止\n    设置 → 应用 → " + str2 + " → 强制停止\n\n\u1f7e1 步骤3：卸载\n    设置 → 应用 → " + str2 + " → 卸载\n\n\u1f7e2 步骤4：ADB 卸载（需电脑）\n    adb uninstall " + str2 + "\n\n🔵 步骤5：检查权限\n    设备管理器：设置 → 安全 → 取消可疑管理器\n    无障碍服务：设置 → 无障碍 → 关闭\n    拨号 *#*#1234#*#* 可中断覆盖层";
                if (textView != null) {
                    textView.setText(str5);
                }
                if (view4 != null) {
                    view4.setVisibility(0);
                }
                if (view5 != null) {
                    view5.setVisibility(0);
                }
            }
        }
    }

    public final void b() {
        WindowManager windowManager;
        CountDownTimer countDownTimer = this.h;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            this.h = null;
        }
        FrameLayout frameLayout = this.f;
        if (frameLayout != null && (windowManager = this.c) != null) {
            try {
                windowManager.removeView(frameLayout);
            } catch (Exception unused) {
            }
            this.f = null;
        }
        stopSelf();
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        this.c = (WindowManager) getSystemService("window");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel A = d4.A();
            NotificationManager notificationManager = (NotificationManager) getSystemService("notification");
            if (notificationManager != null) {
                j0.q(notificationManager, A);
            }
        }
    }

    @Override // android.app.Service
    public final void onDestroy() {
        b();
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        int i3;
        String f;
        if (intent != null) {
            String stringExtra = intent.getStringExtra("malicious_package");
            this.g = stringExtra;
            if (stringExtra == null) {
                this.g = "";
            }
        }
        if (this.f == null) {
            int i4 = Build.VERSION.SDK_INT;
            if (i4 >= 26) {
                i3 = 2038;
            } else {
                i3 = 2002;
            }
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, i3, 2622880, -1);
            if (i4 >= 28) {
                layoutParams.layoutInDisplayCutoutMode = 3;
            }
            FrameLayout frameLayout = new FrameLayout(this);
            this.f = frameLayout;
            frameLayout.setBackgroundColor(-15921894);
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(1);
            linearLayout.setGravity(17);
            linearLayout.setPadding(40, 60, 40, 60);
            TextView textView = new TextView(this);
            textView.setText("🛡️ 紧急救援模式");
            textView.setTextColor(-1);
            textView.setTextSize(22.0f);
            textView.setGravity(17);
            textView.setPadding(0, 0, 0, 16);
            linearLayout.addView(textView);
            TextView textView2 = new TextView(this);
            if (this.g.isEmpty()) {
                f = "已检测到锁机软件正在运行！";
            } else {
                f = i2.f(new StringBuilder("恶意应用："), this.g, "\n正在覆盖您的屏幕！");
            }
            textView2.setText(f);
            textView2.setTextColor(-39322);
            textView2.setTextSize(15.0f);
            textView2.setGravity(17);
            textView2.setPadding(0, 0, 0, 24);
            linearLayout.addView(textView2);
            Button button = new Button(this);
            button.setText("🔧 立即救援（卸载 + 强制停止）");
            button.setTextColor(-1);
            button.setTextSize(17.0f);
            button.setBackgroundColor(-2937041);
            button.setPadding(30, 20, 30, 20);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.bottomMargin = 12;
            button.setLayoutParams(layoutParams2);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.RescueWindowService.1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    RescueWindowService.a(RescueWindowService.this);
                }
            });
            linearLayout.addView(button);
            Button button2 = new Button(this);
            button2.setText("我没事，关闭");
            button2.setTextColor(-7829368);
            button2.setTextSize(14.0f);
            button2.setBackgroundColor(-14540220);
            button2.setPadding(30, 14, 30, 14);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams3.bottomMargin = 20;
            button2.setLayoutParams(layoutParams3);
            button2.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.RescueWindowService.2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i5 = RescueWindowService.j;
                    RescueWindowService.this.b();
                }
            });
            linearLayout.addView(button2);
            final TextView textView3 = new TextView(this);
            textView3.setText("10 秒后自动救援");
            textView3.setTextColor(-13312);
            textView3.setTextSize(13.0f);
            textView3.setGravity(17);
            textView3.setPadding(0, 0, 0, 20);
            linearLayout.addView(textView3);
            ScrollView scrollView = new ScrollView(this);
            scrollView.setVisibility(8);
            scrollView.setPadding(0, 10, 0, 0);
            TextView textView4 = new TextView(this);
            textView4.setTextColor(-3355444);
            textView4.setTextSize(13.0f);
            textView4.setLineSpacing(4.0f, 1.0f);
            scrollView.addView(textView4);
            linearLayout.addView(scrollView);
            Button button3 = new Button(this);
            button3.setText("✅ 我已脱险，关闭窗口");
            button3.setTextColor(-1);
            button3.setTextSize(16.0f);
            button3.setBackgroundColor(-13730510);
            button3.setPadding(30, 16, 30, 16);
            button3.setVisibility(8);
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams4.topMargin = 16;
            button3.setLayoutParams(layoutParams4);
            button3.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.RescueWindowService.3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    int i5 = RescueWindowService.j;
                    RescueWindowService.this.b();
                }
            });
            linearLayout.addView(button3);
            this.f.addView(linearLayout);
            this.c.addView(this.f, layoutParams);
            this.f.setTag(new Object[]{button, button2, textView3, scrollView, textView4, button3});
            this.h = new CountDownTimer() { // from class: com.youlong.tool.RescueWindowService.4
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(10000L, 1000L);
                }

                @Override // android.os.CountDownTimer
                public final void onFinish() {
                    RescueWindowService rescueWindowService = RescueWindowService.this;
                    if (!rescueWindowService.i) {
                        RescueWindowService.a(rescueWindowService);
                    }
                }

                @Override // android.os.CountDownTimer
                public final void onTick(long j2) {
                    if (!RescueWindowService.this.i) {
                        TextView textView5 = textView3;
                        textView5.setText((j2 / 1000) + " 秒后自动救援");
                        if (j2 <= CoroutineLiveDataKt.DEFAULT_TIMEOUT) {
                            textView5.setTextColor(-48060);
                        }
                    }
                }
            }.start();
            return 2;
        }
        return 2;
    }
}
