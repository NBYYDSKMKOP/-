package com.youlong.tool;

import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class DeviceAdminReceiver extends BroadcastReceiver {
    public static final String[] a = {"com.android.settings", "com.google.android.gms", "com.google.android.apps.work.clouddpc", "com.samsung.android.knox", "com.samsung.android.securitymanager", "com.eg.android.AlipayGphone", "com.tencent.mm", "com.xunmeng.pinduoduo", "com.youlong.zoo", "com.tencent.mobileqq"};

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        List<ComponentName> activeAdmins;
        String str;
        if (intent == null || !"android.app.action.DEVICE_ADMIN_ENABLED".equals(intent.getAction())) {
            return;
        }
        try {
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager) context.getSystemService("device_policy");
            if (devicePolicyManager == null || (activeAdmins = devicePolicyManager.getActiveAdmins()) == null) {
                return;
            }
            Iterator<ComponentName> it = activeAdmins.iterator();
            loop0: while (true) {
                if (it.hasNext()) {
                    str = it.next().getPackageName();
                    String[] strArr = a;
                    for (int i = 0; i < 10; i++) {
                        if (strArr[i].equals(str)) {
                            break;
                        }
                    }
                    break loop0;
                }
                str = null;
                break;
            }
            if (str == null) {
                return;
            }
            String format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            SharedPreferences sharedPreferences = context.getSharedPreferences("shield_prefs", 0);
            JSONArray jSONArray = new JSONArray(sharedPreferences.getString("block_history", "[]"));
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("description", "检测到非白名单应用激活设备管理器");
            jSONObject.put("packageName", str);
            jSONObject.put("time", format);
            jSONObject.put("type", "device_admin");
            jSONArray.put(jSONObject);
            if (jSONArray.length() > 50) {
                JSONArray jSONArray2 = new JSONArray();
                for (int length = jSONArray.length() - 50; length < jSONArray.length(); length++) {
                    jSONArray2.put(jSONArray.get(length));
                }
                jSONArray = jSONArray2;
            }
            sharedPreferences.edit().putString("block_history", jSONArray.toString()).apply();
            Intent intent2 = new Intent(context, (Class<?>) ShieldWarnActivity.class);
            intent2.putExtra("suspect_package", str);
            intent2.addFlags(268435456);
            context.startActivity(intent2);
        } catch (Exception unused) {
        }
    }
}
