package com.youlong.tool;

import android.content.ContentResolver;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class ColorModeUtils {
    public static void a(Context context) {
        if (!Settings.System.canWrite(context)) {
            return;
        }
        ContentResolver contentResolver = context.getContentResolver();
        String lowerCase = Build.BRAND.toLowerCase();
        String lowerCase2 = Build.MANUFACTURER.toLowerCase();
        d(contentResolver, "screen_color_mode", 0);
        d(contentResolver, "color_mode", 0);
        d(contentResolver, "color_temperature", 0);
        if (lowerCase.contains("samsung") || lowerCase2.contains("samsung")) {
            d(contentResolver, "screen_mode_setting", 2);
        }
        if (lowerCase.contains("xiaomi") || lowerCase2.contains("xiaomi")) {
            d(contentResolver, "screen_color_mode", 0);
            c(contentResolver, "display_color_mode", 0);
        }
        if (lowerCase.contains("oppo") || lowerCase.contains("realme") || lowerCase2.contains("oppo") || lowerCase2.contains("realme")) {
            d(contentResolver, "oppo_display_color_mode", 0);
        }
        if (lowerCase.contains("oneplus") || lowerCase2.contains("oneplus")) {
            d(contentResolver, "oneplus_screen_color_mode", 0);
        }
        if (lowerCase.contains("vivo") || lowerCase2.contains("vivo")) {
            d(contentResolver, "vivo_screen_color_mode", 0);
        }
        if (lowerCase.contains("google") || lowerCase2.contains("google")) {
            try {
                Settings.Secure.putInt(contentResolver, "night_display_activated", 0);
            } catch (Exception unused) {
            }
            d(contentResolver, "display_color_mode", 0);
        }
        c(contentResolver, "display_color_enhance", 0);
        c(contentResolver, "vivid_mode", 0);
        c(contentResolver, "color_mode_vivid", 0);
        c(contentResolver, "color_vivid_enabled", 0);
    }

    public static void b(Context context) {
        if (!Settings.System.canWrite(context)) {
            return;
        }
        ContentResolver contentResolver = context.getContentResolver();
        String lowerCase = Build.BRAND.toLowerCase();
        String lowerCase2 = Build.MANUFACTURER.toLowerCase();
        d(contentResolver, "screen_color_mode", 1);
        d(contentResolver, "color_mode", 1);
        d(contentResolver, "color_temperature", 1);
        if (lowerCase.contains("samsung") || lowerCase2.contains("samsung")) {
            d(contentResolver, "screen_mode_setting", 1);
        }
        if (lowerCase.contains("xiaomi") || lowerCase2.contains("xiaomi")) {
            d(contentResolver, "screen_color_mode", 1);
            c(contentResolver, "display_color_mode", 1);
        }
        if (lowerCase.contains("oppo") || lowerCase.contains("realme") || lowerCase2.contains("oppo") || lowerCase2.contains("realme")) {
            d(contentResolver, "oppo_display_color_mode", 1);
        }
        if (lowerCase.contains("oneplus") || lowerCase2.contains("oneplus")) {
            d(contentResolver, "oneplus_screen_color_mode", 1);
        }
        if (lowerCase.contains("vivo") || lowerCase2.contains("vivo")) {
            d(contentResolver, "vivo_screen_color_mode", 1);
        }
        if (lowerCase.contains("google") || lowerCase2.contains("google")) {
            try {
                Settings.Secure.putInt(contentResolver, "night_display_activated", 0);
            } catch (Exception unused) {
            }
            d(contentResolver, "display_color_mode", 1);
        }
        c(contentResolver, "display_color_enhance", 1);
        c(contentResolver, "vivid_mode", 1);
        c(contentResolver, "color_mode_vivid", 1);
        c(contentResolver, "color_vivid_enabled", 1);
    }

    public static void c(ContentResolver contentResolver, String str, int i) {
        try {
            Settings.Global.putInt(contentResolver, str, i);
        } catch (Exception unused) {
        }
    }

    public static void d(ContentResolver contentResolver, String str, int i) {
        try {
            Settings.System.putInt(contentResolver, str, i);
        } catch (Exception unused) {
        }
    }
}
