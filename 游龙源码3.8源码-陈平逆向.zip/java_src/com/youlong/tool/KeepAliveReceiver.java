package com.youlong.tool;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;
import java.util.Iterator;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class KeepAliveReceiver extends BroadcastReceiver {
    public static boolean a(Context context, Class cls) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
        if (activityManager != null) {
            Iterator<ActivityManager.RunningServiceInfo> it = activityManager.getRunningServices(Integer.MAX_VALUE).iterator();
            while (it.hasNext()) {
                if (cls.getName().equals(it.next().service.getClassName())) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        if (!context.getSharedPreferences("shield_prefs", 0).getBoolean("protect_on", false)) {
            return;
        }
        if (!a(context, ProtectService.class)) {
            ContextCompat.startForegroundService(context, new Intent(context, (Class<?>) ProtectService.class));
        }
        if (!a(context, ForegroundService.class)) {
            ContextCompat.startForegroundService(context, new Intent(context, (Class<?>) ForegroundService.class));
        }
    }
}
