package com.youlong.tool;

import java.util.Arrays;
import java.util.HashSet;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final class BlacklistConstants {
    public static final HashSet a = new HashSet(Arrays.asList("com.cange.wd", "com.mycompany.application", "com.liangcheng.mini", "c18.dhmgbup.pgmt.tnecnet.moc.abef971.m0", "com.huge.p34366425", "com.i6b401775ea8ced552", "com.i9236f23a6f538c44", "com.i838d322f2a6b750a", "com.Tsc", "com.my.evil.tim", "com.zz166666556", "com.Qinjian", "com.qq2973357235.wzasj", "com.nancisancongsuoji", "com.Mixo.XiaoBao", "com.Tong.nb"));
}
