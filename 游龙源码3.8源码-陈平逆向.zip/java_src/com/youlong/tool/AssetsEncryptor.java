package com.youlong.tool;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class AssetsEncryptor {
    private static final String a = "AES/GCM/NoPadding";
    private static final int b = 128;
    private static final int c = 12;
    private static final int d = 32;
    private static volatile byte[] e;

    public static byte[] a(byte[] bArr) {
        if (bArr.length > 28) {
            byte[] bArr2 = new byte[12];
            System.arraycopy(bArr, 0, bArr2, 0, 12);
            int length = bArr.length - 12;
            byte[] bArr3 = new byte[length];
            System.arraycopy(bArr, 12, bArr3, 0, length);
            if (NativeCrypto.isNativeLoaded()) {
                byte[] decrypt = NativeCrypto.decrypt(bArr2, bArr3, e);
                if (decrypt != null) {
                    return decrypt;
                }
                throw new IllegalArgumentException("native decrypt failed");
            }
            byte[] b2 = b();
            SecretKeySpec secretKeySpec = new SecretKeySpec(b2, "AES");
            GCMParameterSpec gCMParameterSpec = new GCMParameterSpec(128, bArr2);
            Cipher cipher = Cipher.getInstance(a);
            cipher.init(2, secretKeySpec, gCMParameterSpec);
            byte[] doFinal = cipher.doFinal(bArr3);
            Arrays.fill(b2, (byte) 0);
            return doFinal;
        }
        throw new IllegalArgumentException("data too short or corrupted");
    }

    private static byte[] b() {
        byte[] deriveKey;
        byte[] bArr = e;
        if (NativeCrypto.isNativeLoaded() && (deriveKey = NativeCrypto.deriveKey(bArr)) != null && deriveKey.length == 32) {
            return deriveKey;
        }
        return f(bArr);
    }

    public static byte[] c(byte[] bArr) {
        byte[] bArr2 = new byte[12];
        new SecureRandom().nextBytes(bArr2);
        byte[] b2 = b();
        SecretKeySpec secretKeySpec = new SecretKeySpec(b2, "AES");
        GCMParameterSpec gCMParameterSpec = new GCMParameterSpec(128, bArr2);
        Cipher cipher = Cipher.getInstance(a);
        cipher.init(1, secretKeySpec, gCMParameterSpec);
        byte[] doFinal = cipher.doFinal(bArr);
        Arrays.fill(b2, (byte) 0);
        byte[] bArr3 = new byte[doFinal.length + 12];
        System.arraycopy(bArr2, 0, bArr3, 0, 12);
        System.arraycopy(doFinal, 0, bArr3, 12, doFinal.length);
        return bArr3;
    }

    public static String d(String str) {
        String lowerCase = str.toLowerCase();
        if (!lowerCase.endsWith(".html") && !lowerCase.endsWith(".htm")) {
            if (lowerCase.endsWith(".css")) {
                return "text/css";
            }
            if (lowerCase.endsWith(".js")) {
                return "application/javascript";
            }
            if (lowerCase.endsWith(".json")) {
                return "application/json";
            }
            if (lowerCase.endsWith(".png")) {
                return "image/png";
            }
            if (!lowerCase.endsWith(".jpg") && !lowerCase.endsWith(".jpeg")) {
                if (lowerCase.endsWith(".gif")) {
                    return "image/gif";
                }
                if (lowerCase.endsWith(".svg")) {
                    return "image/svg+xml";
                }
                if (lowerCase.endsWith(".ico")) {
                    return "image/x-icon";
                }
                if (lowerCase.endsWith(".webp")) {
                    return "image/webp";
                }
                if (lowerCase.endsWith(".mp4")) {
                    return "video/mp4";
                }
                if (lowerCase.endsWith(".webm")) {
                    return "video/webm";
                }
                if (lowerCase.endsWith(".mp3")) {
                    return "audio/mpeg";
                }
                if (lowerCase.endsWith(".wav")) {
                    return "audio/wav";
                }
                if (lowerCase.endsWith(".woff")) {
                    return "font/woff";
                }
                if (lowerCase.endsWith(".woff2")) {
                    return "font/woff2";
                }
                if (lowerCase.endsWith(".ttf")) {
                    return "font/ttf";
                }
                if (lowerCase.endsWith(".txt")) {
                    return "text/plain";
                }
                if (lowerCase.endsWith(".xml")) {
                    return "text/xml";
                }
                if (lowerCase.endsWith(".pdf")) {
                    return "application/pdf";
                }
                return "application/octet-stream";
            }
            return "image/jpeg";
        }
        return "text/html";
    }

    public static boolean e() {
        byte[] bArr = e;
        if (bArr != null && bArr.length == 32) {
            return true;
        }
        return false;
    }

    private static byte[] f(byte[] bArr) {
        int i;
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        if (bArr != null) {
            i = bArr.length;
        } else {
            i = 0;
        }
        byte[] bArr2 = new byte[i + 32];
        byte[] deriveSeedForFallback = NativeCrypto.deriveSeedForFallback();
        byte[] deriveSaltForFallback = NativeCrypto.deriveSaltForFallback();
        System.arraycopy(deriveSeedForFallback, 0, bArr2, 0, 16);
        System.arraycopy(deriveSaltForFallback, 0, bArr2, 16, 16);
        if (bArr != null && bArr.length > 0) {
            System.arraycopy(bArr, 0, bArr2, 32, bArr.length);
        }
        byte[] digest = messageDigest.digest(bArr2);
        Arrays.fill(deriveSeedForFallback, (byte) 0);
        Arrays.fill(deriveSaltForFallback, (byte) 0);
        return digest;
    }

    public static byte[] g(InputStream inputStream) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[8192];
        while (true) {
            int read = inputStream.read(bArr);
            if (read != -1) {
                byteArrayOutputStream.write(bArr, 0, read);
            } else {
                byteArrayOutputStream.flush();
                return byteArrayOutputStream.toByteArray();
            }
        }
    }

    public static void h(byte[] bArr) {
        e = bArr;
    }
}
