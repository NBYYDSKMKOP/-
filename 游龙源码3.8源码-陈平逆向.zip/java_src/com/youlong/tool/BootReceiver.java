package com.youlong.tool;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class BootReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        if (intent == null || !"android.intent.action.BOOT_COMPLETED".equals(intent.getAction())) {
            return;
        }
        if (context.getSharedPreferences("shield_prefs", 0).getBoolean("protect_on", false)) {
            ContextCompat.startForegroundService(context, new Intent(context, (Class<?>) ProtectService.class));
            PendingIntent broadcast = PendingIntent.getBroadcast(context, 0, new Intent(context, (Class<?>) KeepAliveReceiver.class), 201326592);
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM);
            if (alarmManager != null) {
                try {
                    alarmManager.setInexactRepeating(2, SystemClock.elapsedRealtime() + 60000, 120000L, broadcast);
                    return;
                } catch (Exception unused) {
                    return;
                }
            }
            return;
        }
        PendingIntent broadcast2 = PendingIntent.getBroadcast(context, 0, new Intent(context, (Class<?>) KeepAliveReceiver.class), 201326592);
        AlarmManager alarmManager2 = (AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM);
        if (alarmManager2 != null) {
            alarmManager2.cancel(broadcast2);
        }
    }
}
