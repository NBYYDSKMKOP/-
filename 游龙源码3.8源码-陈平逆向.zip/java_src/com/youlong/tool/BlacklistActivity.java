package com.youlong.tool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class BlacklistActivity extends Activity {
    public static final /* synthetic */ int l = 0;
    public PackageManager c;
    public SharedPreferences f;
    public final HashSet g = new HashSet();
    public final ArrayList h = new ArrayList();
    public LinearLayout i;
    public LinearLayout j;
    public TextView k;

    /* renamed from: com.youlong.tool.BlacklistActivity$4, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    class AnonymousClass4 implements Comparator<AppItem> {
        @Override // java.util.Comparator
        public final int compare(AppItem appItem, AppItem appItem2) {
            return appItem.b.compareToIgnoreCase(appItem2.b);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.youlong.tool.BlacklistActivity$8, reason: invalid class name */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass8 implements Comparator<AppItem> {
        @Override // java.util.Comparator
        public final int compare(AppItem appItem, AppItem appItem2) {
            return appItem.b.compareToIgnoreCase(appItem2.b);
        }
    }

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public static class AppItem {
        public String a;
        public String b;
    }

    public static void a(BlacklistActivity blacklistActivity) {
        StringBuilder sb = new StringBuilder();
        Iterator it = blacklistActivity.g.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            if (sb.length() > 0) {
                sb.append(",");
            }
            sb.append(str);
        }
        blacklistActivity.f.edit().putString("blacklist_pkgs", sb.toString()).apply();
    }

    public final int b(int i) {
        return (int) ((i * getResources().getDisplayMetrics().density) + 0.5f);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v2, types: [android.widget.TextView, android.view.View] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.Object, java.util.Comparator] */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v13, types: [com.youlong.tool.BlacklistActivity$AppItem, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v21 */
    /* JADX WARN: Type inference failed for: r4v7, types: [android.widget.LinearLayout, android.view.View, android.view.ViewGroup] */
    /* JADX WARN: Type inference failed for: r4v8, types: [android.widget.TextView, android.widget.Button, android.view.View] */
    /* JADX WARN: Type inference failed for: r8v2, types: [android.widget.LinearLayout, android.view.ViewGroup] */
    /* JADX WARN: Type inference failed for: r9v0, types: [android.widget.LinearLayout, android.view.View, android.view.ViewGroup] */
    public final void c() {
        Typeface typeface;
        String upperCase;
        String str;
        this.i.removeAllViews();
        TextView textView = this.k;
        HashSet hashSet = this.g;
        if (textView != null) {
            StringBuilder sb = new StringBuilder("我都很信任");
            if (hashSet.isEmpty()) {
                str = "";
            } else {
                str = "（清空" + hashSet.size() + "个管控）";
            }
            sb.append(str);
            textView.setText(sb.toString());
        }
        ArrayList arrayList = new ArrayList();
        Iterator it = hashSet.iterator();
        while (true) {
            typeface = null;
            ?? r4 = 0;
            if (!it.hasNext()) {
                break;
            }
            String str2 = (String) it.next();
            Iterator it2 = this.h.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    break;
                }
                AppItem appItem = (AppItem) it2.next();
                if (appItem.a.equals(str2)) {
                    r4 = appItem;
                    break;
                }
            }
            if (r4 == 0) {
                r4 = new Object();
                r4.a = str2;
                r4.b = str2;
            }
            arrayList.add(r4);
        }
        Collections.sort(arrayList, new Object());
        if (arrayList.isEmpty()) {
            this.j.setVisibility(0);
            this.i.setVisibility(8);
            return;
        }
        this.j.setVisibility(8);
        this.i.setVisibility(0);
        TextView textView2 = new TextView(this);
        textView2.setText("已加入管控 (" + arrayList.size() + ")");
        textView2.setTextColor(-13421773);
        textView2.setTextSize(14.0f);
        textView2.setTypeface(null, 1);
        textView2.setPadding(0, 0, 0, b(8));
        this.i.addView(textView2);
        Iterator it3 = arrayList.iterator();
        while (it3.hasNext()) {
            final AppItem appItem2 = (AppItem) it3.next();
            ?? r8 = this.i;
            ?? linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(0);
            linearLayout.setGravity(16);
            linearLayout.setPadding(b(14), b(12), b(14), b(12));
            linearLayout.setBackgroundColor(-1);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(0);
            gradientDrawable.setCornerRadius(b(12));
            gradientDrawable.setColor(-1);
            gradientDrawable.setStroke(b(1), -1754827);
            linearLayout.setBackground(gradientDrawable);
            ?? textView3 = new TextView(this);
            if (appItem2.b.isEmpty()) {
                upperCase = "?";
            } else {
                upperCase = appItem2.b.substring(0, 1).toUpperCase();
            }
            textView3.setText(upperCase);
            textView3.setTextColor(-1);
            textView3.setTextSize(15.0f);
            textView3.setTypeface(typeface, 1);
            textView3.setGravity(17);
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setShape(1);
            gradientDrawable2.setColor(new int[]{-2937041, -3790808, -4776932, -1754827, -9823334, -1683200, -11652050, -13154481}[Math.abs(appItem2.a.hashCode()) % 8]);
            int b = b(38);
            textView3.setBackground(gradientDrawable2);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(b, b);
            layoutParams.rightMargin = b(12);
            textView3.setLayoutParams(layoutParams);
            linearLayout.addView(textView3);
            ?? linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(1);
            linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            TextView textView4 = new TextView(this);
            textView4.setText(appItem2.b);
            textView4.setTextColor(-14540254);
            textView4.setTextSize(14.0f);
            textView4.setSingleLine(true);
            linearLayout2.addView(textView4);
            TextView textView5 = new TextView(this);
            textView5.setText(appItem2.a);
            textView5.setTextColor(-5592406);
            textView5.setTextSize(11.0f);
            textView5.setSingleLine(true);
            linearLayout2.addView(textView5);
            linearLayout.addView(linearLayout2);
            ?? button = new Button(this);
            button.setText("移出");
            button.setTextColor(-13730510);
            button.setTextSize(13.0f);
            GradientDrawable gradientDrawable3 = new GradientDrawable();
            gradientDrawable3.setShape(0);
            gradientDrawable3.setCornerRadius(b(16));
            gradientDrawable3.setColor(-1509911);
            button.setBackground(gradientDrawable3);
            button.setPadding(b(14), b(6), b(14), b(6));
            button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.BlacklistActivity.9
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    BlacklistActivity blacklistActivity = BlacklistActivity.this;
                    blacklistActivity.g.remove(appItem2.a);
                    BlacklistActivity.a(blacklistActivity);
                    blacklistActivity.c();
                }
            });
            linearLayout.addView(button);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.bottomMargin = b(8);
            linearLayout.setLayoutParams(layoutParams2);
            r8.addView(linearLayout);
            typeface = null;
        }
    }

    /* JADX WARN: Type inference failed for: r14v9, types: [java.lang.Object, java.util.Comparator] */
    /* JADX WARN: Type inference failed for: r2v10, types: [com.youlong.tool.BlacklistActivity$AppItem, java.lang.Object] */
    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        int i;
        String str;
        super.onCreate(bundle);
        this.c = getPackageManager();
        this.f = getSharedPreferences("shield_prefs", 0);
        HashSet hashSet = this.g;
        hashSet.clear();
        String string = this.f.getString("blacklist_pkgs", "");
        if (!string.isEmpty()) {
            for (String str2 : string.split(",")) {
                String trim = str2.trim();
                if (!trim.isEmpty()) {
                    hashSet.add(trim);
                }
            }
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(-657670);
        linearLayout.setFitsSystemWindows(true);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setBackgroundColor(-2937041);
        int b = b(12);
        int identifier = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (identifier > 0) {
            i = getResources().getDimensionPixelSize(identifier);
        } else {
            i = 0;
        }
        linearLayout2.setPadding(24, b + i, 24, b(12));
        TextView textView = new TextView(this);
        textView.setText("←");
        textView.setTextColor(-1);
        textView.setTextSize(22.0f);
        textView.setPadding(0, 0, b(16), 0);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.BlacklistActivity.1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                BlacklistActivity.this.finish();
            }
        });
        linearLayout2.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText("管控应用的列表");
        textView2.setTextColor(-1);
        textView2.setTextSize(20.0f);
        textView2.setTypeface(null, 1);
        linearLayout2.addView(textView2);
        linearLayout.addView(linearLayout2);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(1);
        linearLayout3.setGravity(1);
        linearLayout3.setPadding(b(24), b(40), b(24), b(40));
        TextView textView3 = new TextView(this);
        textView3.setText("⚠️");
        textView3.setTextSize(40.0f);
        textView3.setGravity(17);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(-5138);
        int b2 = b(80);
        gradientDrawable.setSize(b2, b2);
        textView3.setBackground(gradientDrawable);
        textView3.setMinWidth(b2);
        textView3.setMinHeight(b2);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(b2, b2);
        layoutParams.gravity = 1;
        textView3.setLayoutParams(layoutParams);
        linearLayout3.addView(textView3);
        Button button = new Button(this);
        button.setText("添加要管控的应用");
        button.setTextColor(-1);
        button.setTextSize(17.0f);
        button.setTypeface(null, 1);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setShape(0);
        gradientDrawable2.setCornerRadius(b(28));
        gradientDrawable2.setColor(-15374912);
        button.setBackground(gradientDrawable2);
        button.setPadding(b(48), b(14), b(48), b(14));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = b(24);
        layoutParams2.gravity = 1;
        button.setLayoutParams(layoutParams2);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.BlacklistActivity.2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                int i2 = BlacklistActivity.l;
                final BlacklistActivity blacklistActivity = BlacklistActivity.this;
                blacklistActivity.getClass();
                final ArrayList arrayList = new ArrayList();
                Iterator it = blacklistActivity.h.iterator();
                while (it.hasNext()) {
                    AppItem appItem = (AppItem) it.next();
                    if (!blacklistActivity.g.contains(appItem.a)) {
                        arrayList.add(appItem);
                    }
                }
                if (arrayList.isEmpty()) {
                    new AlertDialog.Builder(blacklistActivity).setTitle("提示").setMessage("所有已安装应用都已在管控中").setPositiveButton("确定", (DialogInterface.OnClickListener) null).show();
                    return;
                }
                String[] strArr = new String[arrayList.size()];
                final boolean[] zArr = new boolean[arrayList.size()];
                for (int i3 = 0; i3 < arrayList.size(); i3++) {
                    strArr[i3] = ((AppItem) arrayList.get(i3)).b + "\n" + ((AppItem) arrayList.get(i3)).a;
                    zArr[i3] = false;
                }
                new AlertDialog.Builder(blacklistActivity).setTitle("选择要加入管控的应用（可多选）").setMultiChoiceItems(strArr, zArr, new DialogInterface.OnMultiChoiceClickListener() { // from class: com.youlong.tool.BlacklistActivity.6
                    @Override // android.content.DialogInterface.OnMultiChoiceClickListener
                    public final void onClick(DialogInterface dialogInterface, int i4, boolean z) {
                        zArr[i4] = z;
                    }
                }).setPositiveButton("确定加入", new DialogInterface.OnClickListener() { // from class: com.youlong.tool.BlacklistActivity.5
                    @Override // android.content.DialogInterface.OnClickListener
                    public final void onClick(DialogInterface dialogInterface, int i4) {
                        int i5 = 0;
                        while (true) {
                            List list = arrayList;
                            int size = list.size();
                            BlacklistActivity blacklistActivity2 = BlacklistActivity.this;
                            if (i5 < size) {
                                if (zArr[i5]) {
                                    blacklistActivity2.g.add(((AppItem) list.get(i5)).a);
                                }
                                i5++;
                            } else {
                                BlacklistActivity.a(blacklistActivity2);
                                blacklistActivity2.c();
                                return;
                            }
                        }
                    }
                }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
            }
        });
        linearLayout3.addView(button);
        TextView textView4 = new TextView(this);
        this.k = textView4;
        textView4.setText("我都很信任");
        this.k.setTextColor(-10066330);
        this.k.setTextSize(14.0f);
        this.k.setGravity(17);
        this.k.setPadding(0, b(16), 0, b(8));
        this.k.setTypeface(null, 1);
        this.k.setOnClickListener(new View.OnClickListener() { // from class: com.youlong.tool.BlacklistActivity.3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                final BlacklistActivity blacklistActivity = BlacklistActivity.this;
                if (blacklistActivity.g.isEmpty()) {
                    new AlertDialog.Builder(blacklistActivity).setTitle("提示").setMessage("当前没有管控应用").setPositiveButton("确定", (DialogInterface.OnClickListener) null).show();
                } else {
                    new AlertDialog.Builder(blacklistActivity).setTitle("确认清空").setMessage("确定要清空所有管控吗？\n所有应用将不再被拦截。").setPositiveButton("确定清空", new DialogInterface.OnClickListener() { // from class: com.youlong.tool.BlacklistActivity.7
                        @Override // android.content.DialogInterface.OnClickListener
                        public final void onClick(DialogInterface dialogInterface, int i2) {
                            BlacklistActivity blacklistActivity2 = BlacklistActivity.this;
                            blacklistActivity2.g.clear();
                            BlacklistActivity.a(blacklistActivity2);
                            blacklistActivity2.c();
                        }
                    }).setNegativeButton("取消", (DialogInterface.OnClickListener) null).show();
                }
            }
        });
        linearLayout3.addView(this.k);
        TextView textView5 = new TextView(this);
        textView5.setText("管控中的应用将启动安全护盾拦截\n不显示系统应用");
        textView5.setTextColor(-6710887);
        textView5.setTextSize(13.0f);
        textView5.setGravity(17);
        textView5.setPadding(0, b(4), 0, b(24));
        linearLayout3.addView(textView5);
        LinearLayout linearLayout4 = new LinearLayout(this);
        this.j = linearLayout4;
        linearLayout4.setOrientation(1);
        this.j.setGravity(17);
        this.j.setPadding(0, b(20), 0, 0);
        TextView textView6 = new TextView(this);
        textView6.setText("暂无管控应用\n所有应用都不会被拦截");
        textView6.setTextColor(-4473925);
        textView6.setTextSize(15.0f);
        textView6.setGravity(17);
        this.j.addView(textView6);
        linearLayout3.addView(this.j);
        LinearLayout linearLayout5 = new LinearLayout(this);
        this.i = linearLayout5;
        linearLayout5.setOrientation(1);
        this.i.setPadding(0, b(16), 0, 0);
        linearLayout3.addView(this.i);
        scrollView.addView(linearLayout3);
        linearLayout.addView(scrollView);
        setContentView(linearLayout);
        List<ApplicationInfo> installedApplications = this.c.getInstalledApplications(0);
        ArrayList arrayList = this.h;
        arrayList.clear();
        for (ApplicationInfo applicationInfo : installedApplications) {
            if (!applicationInfo.packageName.equals(getPackageName())) {
                int i2 = applicationInfo.flags;
                if ((i2 & 1) == 0 && (i2 & 128) == 0 && ((str = applicationInfo.sourceDir) == null || !str.startsWith("/system/"))) {
                    ?? obj = new Object();
                    obj.a = applicationInfo.packageName;
                    obj.b = applicationInfo.loadLabel(this.c).toString();
                    arrayList.add(obj);
                }
            }
        }
        Collections.sort(arrayList, new Object());
        c();
    }
}
