package com.youlong.tool;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.os.Build;
import android.os.IBinder;
import android.view.View;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import yl.d4;
import yl.d6;
import yl.j0;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class ScreenFilterService extends Service {
    public static WindowManager c = null;
    public static OverlayView f = null;
    public static volatile boolean g = false;
    public static volatile int h = 0;
    public static volatile float i = 100.0f;
    public static volatile float j = 100.0f;
    public static volatile float k = 100.0f;
    public static volatile float l = 50.0f;
    public static final float[] m = {1.05f, 0.0f, 0.0f, 0.0f, 8.0f, 0.0f, 1.05f, 0.0f, 0.0f, 8.0f, 0.0f, 0.0f, 1.04f, 0.0f, 6.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f};
    public static final float[] n = {1.06f, 0.0f, 0.0f, 0.0f, 5.0f, 0.0f, 1.05f, 0.0f, 0.0f, 5.0f, 0.0f, 0.0f, 1.07f, 0.0f, 4.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f};

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public static class OverlayView extends View {
        public final ColorMatrix c;
        public final Paint f;
        public float g;

        public OverlayView(Context context) {
            super(context);
            ColorMatrix colorMatrix = new ColorMatrix();
            this.c = colorMatrix;
            Paint paint = new Paint();
            this.f = paint;
            this.g = 0.0f;
            setFocusable(false);
            setFocusableInTouchMode(false);
            setClickable(false);
            setEnabled(false);
            paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
            setLayerType(2, paint);
        }

        @Override // android.view.View
        public final void onDraw(Canvas canvas) {
            float f = this.g;
            if (f < 2.0f) {
                return;
            }
            canvas.drawColor(Color.argb(Math.max(0, Math.min(255, Math.round(f))), 245, 245, 245));
        }
    }

    public static void a() {
        float[] fArr;
        OverlayView overlayView = f;
        if (overlayView == null) {
            return;
        }
        if (h == 1) {
            fArr = n;
        } else {
            fArr = m;
        }
        float f2 = i;
        float f3 = j;
        float f4 = k;
        float f5 = l;
        overlayView.getClass();
        float f6 = (f2 - 100.0f) / 100.0f;
        float f7 = (f5 - 50.0f) / 50.0f;
        float[] fArr2 = (float[]) fArr.clone();
        float f8 = f6 * 10.0f;
        float f9 = fArr2[4] + f8;
        fArr2[4] = f9;
        fArr2[9] = fArr2[9] + f8;
        float f10 = (8.0f * f6) + fArr2[14];
        fArr2[14] = f10;
        float f11 = 16.0f * f7;
        fArr2[4] = f9 + f11;
        fArr2[14] = f10 - f11;
        ColorMatrix colorMatrix = overlayView.c;
        colorMatrix.set(fArr2);
        Paint paint = overlayView.f;
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        overlayView.setLayerType(2, paint);
        float abs = (((Math.abs(f7) * 0.5f) + (Math.abs((f4 - 100.0f) / 100.0f) * 0.25f) + (Math.abs((f3 - 100.0f) / 100.0f) * 0.25f) + (Math.abs(f6) * 0.5f)) * 10.0f) + 6.0f;
        overlayView.g = abs;
        overlayView.g = Math.max(0.0f, Math.min(20.0f, abs));
        overlayView.invalidate();
    }

    public static float b(float f2, float f3) {
        return Math.max(0.0f, Math.min(f3, f2));
    }

    public static void c() {
        OverlayView overlayView = f;
        if (overlayView != null) {
            overlayView.post(new d6(1));
        }
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        String str;
        int i2;
        super.onCreate();
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26) {
            NotificationChannel C = d4.C();
            C.setDescription("屏幕滤镜运行中，点击通知可停止");
            j0.v(C);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                j0.q(notificationManager, C);
            }
        }
        Intent intent = new Intent(this, (Class<?>) MainActivity.class);
        intent.setFlags(603979776);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, 201326592);
        Intent intent2 = new Intent(this, (Class<?>) ScreenFilterService.class);
        intent2.setAction("com.youlong.tool.action.STOP_FILTER");
        PendingIntent service = PendingIntent.getService(this, 1, intent2, 201326592);
        NotificationCompat.Builder contentTitle = new NotificationCompat.Builder(this, "screen_filter_channel").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("屏幕滤镜运行中");
        if (h == 1) {
            str = "冷色高清款";
        } else {
            str = "标准清晰款";
        }
        startForeground(2001, contentTitle.setContentText(str.concat(" · 亮度/对比度/饱和度/冷暖色")).setPriority(-1).setOngoing(true).setContentIntent(activity).addAction(android.R.drawable.ic_menu_close_clear_cancel, "停止滤镜", service).build());
        if (f == null) {
            c = (WindowManager) getSystemService("window");
            f = new OverlayView(this);
            a();
            if (i3 >= 26) {
                i2 = 2038;
            } else {
                i2 = 2006;
            }
            WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, i2, 280, -3);
            if (i3 >= 28) {
                layoutParams.layoutInDisplayCutoutMode = 1;
            }
            try {
                c.addView(f, layoutParams);
            } catch (Exception unused) {
            }
        }
        g = true;
    }

    @Override // android.app.Service
    public final void onDestroy() {
        OverlayView overlayView;
        g = false;
        WindowManager windowManager = c;
        if (windowManager != null && (overlayView = f) != null) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception unused) {
            }
        }
        f = null;
        c = null;
        stopForeground(true);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i2, int i3) {
        if (intent != null && "com.youlong.tool.action.STOP_FILTER".equals(intent.getAction())) {
            stopSelf();
            return 2;
        }
        return 1;
    }
}
