package com.youlong.tool;

import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.Display;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class ScreenFilterBridge {
    public final Context a;

    public ScreenFilterBridge(Context context) {
        this.a = context.getApplicationContext();
    }

    @JavascriptInterface
    public boolean canWriteSettings() {
        return Settings.System.canWrite(this.a);
    }

    @JavascriptInterface
    public boolean cleanBackground() {
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses;
        Context context = this.a;
        try {
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            if (activityManager == null || (runningAppProcesses = activityManager.getRunningAppProcesses()) == null) {
                return false;
            }
            String packageName = context.getPackageName();
            int i = 0;
            for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
                if (runningAppProcessInfo.importance > 200 && !runningAppProcessInfo.processName.startsWith("com.android") && !runningAppProcessInfo.processName.startsWith("android") && !runningAppProcessInfo.processName.startsWith("system") && !runningAppProcessInfo.processName.contains("huawei") && !runningAppProcessInfo.processName.contains("hmos") && !runningAppProcessInfo.processName.equals(packageName)) {
                    activityManager.killBackgroundProcesses(runningAppProcessInfo.processName.split(":")[0]);
                    i++;
                }
            }
            if (i <= 0) {
                return false;
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    @JavascriptInterface
    public String getAvailableMemory() {
        Context context = this.a;
        boolean z = PerformanceService.l;
        try {
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            if (activityManager != null) {
                ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
                activityManager.getMemoryInfo(memoryInfo);
                return (memoryInfo.availMem / 1048576) + "MB / " + (memoryInfo.totalMem / 1048576) + "MB";
            }
        } catch (Exception unused) {
        }
        return "--";
    }

    @JavascriptInterface
    public int getBatteryTemp() {
        BufferedReader bufferedReader;
        String readLine;
        boolean z = PerformanceService.l;
        try {
            bufferedReader = new BufferedReader(new FileReader("/sys/class/power_supply/battery/temp"));
            try {
                readLine = bufferedReader.readLine();
            } finally {
            }
        } catch (Exception unused) {
        }
        if (readLine != null) {
            int parseInt = Integer.parseInt(readLine.trim()) / 10;
            bufferedReader.close();
            return parseInt;
        }
        bufferedReader.close();
        return -1;
    }

    @JavascriptInterface
    public int getBrightness() {
        return Math.round(ScreenFilterService.i);
    }

    @JavascriptInterface
    public int getContrast() {
        return Math.round(ScreenFilterService.j);
    }

    @JavascriptInterface
    public String getCurrentColorMode() {
        int i;
        int i2;
        int i3;
        int i4;
        ContentResolver contentResolver = this.a.getContentResolver();
        int i5 = -1;
        try {
            i = Settings.System.getInt(contentResolver, "screen_color_mode");
        } catch (Exception unused) {
            i = -1;
        }
        if (i >= 0) {
            if (i != 1) {
                return "Standard";
            }
        } else {
            try {
                i2 = Settings.System.getInt(contentResolver, "color_mode");
            } catch (Exception unused2) {
                i2 = -1;
            }
            if (i2 >= 0) {
                if (i2 != 1) {
                    return "Standard";
                }
            } else {
                try {
                    i3 = Settings.System.getInt(contentResolver, "screen_mode_setting");
                } catch (Exception unused3) {
                    i3 = -1;
                }
                if (i3 != 1) {
                    if (i3 == 2 || i3 == 3) {
                        return "Standard";
                    }
                    try {
                        i4 = Settings.System.getInt(contentResolver, "screen_color_mode");
                    } catch (Exception unused4) {
                        i4 = -1;
                    }
                    if (i4 != 1) {
                        if (i4 == 0 || i4 == 2) {
                            return "Standard";
                        }
                        try {
                            i5 = Settings.Global.getInt(contentResolver, "display_color_enhance");
                        } catch (Exception unused5) {
                        }
                        if (i5 != 1) {
                            if (i5 == 0) {
                                return "Standard";
                            }
                            return "Unknown";
                        }
                    }
                }
            }
        }
        return "Vivid";
    }

    @JavascriptInterface
    public int getPreset() {
        return ScreenFilterService.h;
    }

    @JavascriptInterface
    public String getPresetName() {
        if (ScreenFilterService.h == 1) {
            return "冷色高清款";
        }
        return "标准清晰款";
    }

    @JavascriptInterface
    public int getRefreshRate() {
        Display display;
        Context context = this.a;
        boolean z = PerformanceService.l;
        try {
            DisplayManager displayManager = (DisplayManager) context.getSystemService("display");
            if (displayManager != null && (display = displayManager.getDisplay(0)) != null) {
                return Math.round(display.getRefreshRate());
            }
        } catch (Exception unused) {
        }
        return 60;
    }

    @JavascriptInterface
    public int getSaturation() {
        return Math.round(ScreenFilterService.k);
    }

    @JavascriptInterface
    public int getScreenBrightness() {
        Context context = this.a;
        boolean z = PerformanceService.l;
        try {
            return Settings.System.getInt(context.getContentResolver(), "screen_brightness");
        } catch (Exception unused) {
            return 128;
        }
    }

    @JavascriptInterface
    public int getTemperature() {
        return Math.round(ScreenFilterService.l);
    }

    @JavascriptInterface
    public boolean isFpsMonitorRunning() {
        return FpsMonitorService.g;
    }

    @JavascriptInterface
    public boolean isPerformanceModeRunning() {
        return PerformanceService.l;
    }

    @JavascriptInterface
    public boolean isServiceRunning() {
        return ScreenFilterService.g;
    }

    @JavascriptInterface
    public void openOverlaySettings() {
        Context context = this.a;
        try {
            Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + context.getPackageName()));
            intent.addFlags(268435456);
            context.startActivity(intent);
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void openWriteSettings() {
        Context context = this.a;
        try {
            Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS", Uri.parse("package:" + context.getPackageName()));
            intent.addFlags(268435456);
            context.startActivity(intent);
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public boolean requestPermission() {
        return Settings.canDrawOverlays(this.a);
    }

    @JavascriptInterface
    public void setBrightness(int i) {
        try {
            ScreenFilterService.i = ScreenFilterService.b(i, 200.0f);
            ScreenFilterService.c();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setContrast(int i) {
        try {
            ScreenFilterService.j = ScreenFilterService.b(i, 200.0f);
            ScreenFilterService.c();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setFilter(int i, int i2, int i3, int i4) {
        float f = i2;
        float f2 = i3;
        float f3 = i4;
        try {
            ScreenFilterService.i = ScreenFilterService.b(i, 200.0f);
            ScreenFilterService.j = ScreenFilterService.b(f, 200.0f);
            ScreenFilterService.k = ScreenFilterService.b(f2, 200.0f);
            ScreenFilterService.l = ScreenFilterService.b(f3, 100.0f);
            ScreenFilterService.c();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setPreset(int i) {
        try {
            WindowManager windowManager = ScreenFilterService.c;
            int i2 = 1;
            if (i != 1) {
                i2 = 0;
            }
            ScreenFilterService.h = i2;
            ScreenFilterService.a();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setRefreshRate(int i) {
        if (i > 0) {
            try {
                if (!PerformanceService.l) {
                    startPerformanceMode();
                }
            } catch (Exception unused) {
                return;
            }
        }
        if (i == 0 && PerformanceService.l) {
            stopPerformanceMode();
        }
    }

    @JavascriptInterface
    public void setRenderMode(String str) {
        try {
            if ("save".equals(str) && !PerformanceService.l) {
                startPerformanceMode();
            } else if ("normal".equals(str) && PerformanceService.l) {
                stopPerformanceMode();
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setSaturation(int i) {
        try {
            ScreenFilterService.k = ScreenFilterService.b(i, 200.0f);
            ScreenFilterService.c();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setScreenBrightness(int i) {
        Context context = this.a;
        try {
            if (Settings.System.canWrite(context) && i >= 0) {
                Settings.System.putInt(context.getContentResolver(), "screen_brightness", Math.min(255, i));
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setStandardMode() {
        try {
            ColorModeUtils.a(this.a);
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setTemperature(int i) {
        try {
            ScreenFilterService.l = ScreenFilterService.b(i, 100.0f);
            ScreenFilterService.c();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setVividMode() {
        try {
            ColorModeUtils.b(this.a);
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void startFilterService() {
        int i = Build.VERSION.SDK_INT;
        Context context = this.a;
        if (!Settings.canDrawOverlays(context)) {
            return;
        }
        Intent intent = new Intent(context, (Class<?>) ScreenFilterService.class);
        try {
            if (i >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void startFpsMonitor() {
        int i = Build.VERSION.SDK_INT;
        Context context = this.a;
        if (!Settings.canDrawOverlays(context)) {
            return;
        }
        Intent intent = new Intent(context, (Class<?>) FpsMonitorService.class);
        try {
            if (i >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void startPerformanceMode() {
        Context context = this.a;
        try {
            int i = Build.VERSION.SDK_INT;
            if (!Settings.canDrawOverlays(context)) {
                return;
            }
            Intent intent = new Intent(context, (Class<?>) PerformanceService.class);
            if (i >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void stopFilterService() {
        try {
            Context context = this.a;
            WindowManager windowManager = ScreenFilterService.c;
            Intent intent = new Intent(context, (Class<?>) ScreenFilterService.class);
            intent.setAction("com.youlong.tool.action.STOP_FILTER");
            context.startService(intent);
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void stopFpsMonitor() {
        try {
            Context context = this.a;
            WindowManager windowManager = FpsMonitorService.c;
            Intent intent = new Intent(context, (Class<?>) FpsMonitorService.class);
            intent.setAction("com.youlong.tool.action.STOP_FPS");
            context.startService(intent);
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void stopPerformanceMode() {
        try {
            Context context = this.a;
            boolean z = PerformanceService.l;
            Intent intent = new Intent(context, (Class<?>) PerformanceService.class);
            intent.setAction("com.youlong.tool.action.STOP_PERF");
            context.startService(intent);
        } catch (Exception unused) {
        }
    }
}
