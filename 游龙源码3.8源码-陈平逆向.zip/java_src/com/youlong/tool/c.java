package com.youlong.tool;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final /* synthetic */ class c implements Runnable {
    public final /* synthetic */ int c;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;

    public /* synthetic */ c(int i, Object obj, Object obj2) {
        this.c = i;
        this.f = obj;
        this.g = obj2;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(12:(3:17|18|19)|(10:20|21|22|23|24|(1:26)(1:81)|27|(8:67|68|69|70|71|72|73|74)(1:29)|30|31)|(2:32|33)|(3:48|49|(10:51|52|(3:54|55|56)|57|36|37|38|39|41|42))|35|36|37|38|39|41|42|15) */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void run() {
        /*
            Method dump skipped, instructions count: 896
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.youlong.tool.c.run():void");
    }
}
