package com.youlong.tool;

import android.app.ActivityManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;
import java.io.File;
import yl.d4;
import yl.j0;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class PerformanceService extends Service {
    public static volatile boolean l = false;
    public static volatile int m = -1;
    public static volatile int n = -1;
    public PowerManager.WakeLock c;
    public PowerManager f;
    public WindowManager g;
    public View h;
    public View i;
    public Handler j;
    public Runnable k;

    public static void b(File file) {
        String[] list;
        if (file != null && file.exists()) {
            if (file.isDirectory() && (list = file.list()) != null) {
                for (String str : list) {
                    b(new File(file, str));
                }
            }
            file.delete();
        }
    }

    public static boolean c(ActivityManager.RunningAppProcessInfo runningAppProcessInfo, String str) {
        if (runningAppProcessInfo.importance > 200 && !runningAppProcessInfo.processName.startsWith("com.android") && !runningAppProcessInfo.processName.startsWith("android") && !runningAppProcessInfo.processName.startsWith("system") && !runningAppProcessInfo.processName.contains("huawei") && !runningAppProcessInfo.processName.contains("hmos") && !runningAppProcessInfo.processName.equals(str)) {
            return false;
        }
        return true;
    }

    public final void a() {
        if (this.f == null) {
            return;
        }
        try {
            PowerManager.WakeLock wakeLock = this.c;
            if (wakeLock != null && wakeLock.isHeld()) {
                this.c.release();
            }
            PowerManager.WakeLock newWakeLock = this.f.newWakeLock(268435457, "YouLongTool:PerfWakeLock");
            this.c = newWakeLock;
            newWakeLock.acquire(600000L);
        } catch (Exception unused) {
        }
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onCreate() {
        int i;
        Display display;
        Display.Mode[] supportedModes;
        int i2;
        super.onCreate();
        this.j = new Handler(Looper.getMainLooper());
        this.g = (WindowManager) getSystemService("window");
        this.f = (PowerManager) getSystemService("power");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel a = d4.a();
            a.setDescription("Performance mode: 120Hz + Max Brightness + Auto Clean every 3 min");
            j0.v(a);
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                j0.q(notificationManager, a);
            }
        }
        Intent intent = new Intent(this, (Class<?>) MainActivity.class);
        intent.setFlags(603979776);
        PendingIntent activity = PendingIntent.getActivity(this, 0, intent, 201326592);
        Intent intent2 = new Intent(this, (Class<?>) PerformanceService.class);
        intent2.setAction("com.youlong.tool.action.STOP_PERF");
        PendingIntent service = PendingIntent.getService(this, 2, intent2, 201326592);
        Intent intent3 = new Intent(this, (Class<?>) PerformanceService.class);
        intent3.setAction("com.youlong.tool.action.CLEAN");
        startForeground(3001, new NotificationCompat.Builder(this, "perf_mode_channel").setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("Performance Mode ON").setContentText("120Hz | Max Brightness | Auto-clean every 3 min").setPriority(-1).setOngoing(true).setContentIntent(activity).addAction(android.R.drawable.ic_menu_delete, "Clean Now", PendingIntent.getService(this, 3, intent3, 201326592)).addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", service).build());
        a();
        try {
            m = Settings.System.getInt(getContentResolver(), "screen_brightness");
            n = Settings.System.getInt(getContentResolver(), "screen_brightness_mode");
        } catch (Exception unused) {
        }
        try {
            DisplayManager displayManager = (DisplayManager) getSystemService("display");
            if (displayManager != null && (display = displayManager.getDisplay(0)) != null && (supportedModes = display.getSupportedModes()) != null && supportedModes.length != 0) {
                Display.Mode mode = display.getMode();
                float refreshRate = mode.getRefreshRate();
                for (Display.Mode mode2 : supportedModes) {
                    float refreshRate2 = mode2.getRefreshRate();
                    if (refreshRate2 > refreshRate && refreshRate2 >= 90.0f) {
                        mode = mode2;
                        refreshRate = refreshRate2;
                    }
                }
                int modeId = mode.getModeId();
                WindowManager windowManager = this.g;
                if (windowManager != null) {
                    if (windowManager != null) {
                        try {
                            View view = this.h;
                            if (view != null) {
                                try {
                                    windowManager.removeView(view);
                                } catch (Exception unused2) {
                                }
                            }
                        } catch (Exception unused3) {
                        }
                    }
                    this.h = null;
                    View view2 = new View(this);
                    this.h = view2;
                    view2.setBackgroundColor(0);
                    if (Build.VERSION.SDK_INT >= 26) {
                        i2 = 2038;
                    } else {
                        i2 = 2006;
                    }
                    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(1, 1, i2, 568, -2);
                    layoutParams.preferredDisplayModeId = modeId;
                    layoutParams.alpha = 0.0f;
                    this.g.addView(this.h, layoutParams);
                }
                mode.getRefreshRate();
                mode.getModeId();
            }
        } catch (Exception unused4) {
        }
        try {
            if (Settings.System.canWrite(this)) {
                Settings.System.putInt(getContentResolver(), "screen_brightness_mode", 0);
                Settings.System.putInt(getContentResolver(), "screen_brightness", 255);
            }
        } catch (Exception unused5) {
        }
        WindowManager windowManager2 = this.g;
        if (windowManager2 != null) {
            if (windowManager2 != null) {
                try {
                    View view3 = this.i;
                    if (view3 != null) {
                        try {
                            windowManager2.removeView(view3);
                        } catch (Exception unused6) {
                        }
                    }
                } catch (Exception unused7) {
                }
            }
            this.i = null;
            View view4 = new View(this);
            this.i = view4;
            view4.setBackgroundColor(0);
            int i3 = Build.VERSION.SDK_INT;
            if (i3 >= 26) {
                i = 2038;
            } else {
                i = 2006;
            }
            WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams(-1, -1, i, 952, -2);
            layoutParams2.screenBrightness = 1.0f;
            layoutParams2.alpha = 0.0f;
            if (i3 >= 28) {
                layoutParams2.layoutInDisplayCutoutMode = 1;
            }
            this.g.addView(this.i, layoutParams2);
        }
        Runnable runnable = new Runnable() { // from class: com.youlong.tool.PerformanceService.1
            @Override // java.lang.Runnable
            public final void run() {
                if (!PerformanceService.l) {
                    return;
                }
                PerformanceService performanceService = PerformanceService.this;
                performanceService.getClass();
                AsyncTask.execute(new d(performanceService, 3));
                PerformanceService.this.j.postDelayed(this, 180000L);
            }
        };
        this.k = runnable;
        this.j.postDelayed(runnable, 180000L);
        l = true;
    }

    @Override // android.app.Service
    public final void onDestroy() {
        View view;
        View view2;
        l = false;
        Runnable runnable = this.k;
        if (runnable != null) {
            this.j.removeCallbacks(runnable);
            this.k = null;
        }
        WindowManager windowManager = this.g;
        if (windowManager != null && (view2 = this.h) != null) {
            try {
                windowManager.removeView(view2);
            } catch (Exception unused) {
            }
        }
        this.h = null;
        WindowManager windowManager2 = this.g;
        if (windowManager2 != null && (view = this.i) != null) {
            try {
                windowManager2.removeView(view);
            } catch (Exception unused2) {
            }
        }
        this.i = null;
        try {
            if (Settings.System.canWrite(this)) {
                if (n >= 0) {
                    Settings.System.putInt(getContentResolver(), "screen_brightness_mode", n);
                }
                if (m >= 0) {
                    Settings.System.putInt(getContentResolver(), "screen_brightness", m);
                }
            }
        } catch (Exception unused3) {
        }
        PowerManager.WakeLock wakeLock = this.c;
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                this.c.release();
            } catch (Exception unused4) {
            }
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null) {
            if ("com.youlong.tool.action.STOP_PERF".equals(intent.getAction())) {
                stopSelf();
                return 2;
            }
            if ("com.youlong.tool.action.CLEAN".equals(intent.getAction())) {
                AsyncTask.execute(new d(this, 3));
            }
        }
        return 1;
    }
}
