package com.youlong.tool;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import java.security.MessageDigest;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class SignatureVerifier {
    private static String bytesToHex(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bArr) {
            sb.append(String.format("%02X", Integer.valueOf(b & 255)));
        }
        return sb.toString();
    }

    public static byte[] getCertSha256Fingerprint(Context context) {
        try {
            byte[] certificateBytes = getCertificateBytes(context);
            if (certificateBytes == null) {
                return null;
            }
            return MessageDigest.getInstance("SHA-256").digest(certificateBytes);
        } catch (Exception unused) {
            return null;
        }
    }

    private static byte[] getCertificateBytes(Context context) {
        SigningInfo signingInfo;
        SigningInfo signingInfo2;
        Signature[] signingCertificateHistory;
        if (Build.VERSION.SDK_INT >= 28) {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 134217728);
            signingInfo = packageInfo.signingInfo;
            if (signingInfo != null) {
                signingInfo2 = packageInfo.signingInfo;
                signingCertificateHistory = signingInfo2.getSigningCertificateHistory();
                if (signingCertificateHistory == null || signingCertificateHistory.length == 0) {
                    return null;
                }
                return signingCertificateHistory[0].toByteArray();
            }
            return null;
        }
        Signature[] signatureArr = context.getPackageManager().getPackageInfo(context.getPackageName(), 64).signatures;
        if (signatureArr == null || signatureArr.length == 0) {
            return null;
        }
        return signatureArr[0].toByteArray();
    }

    private static String rebuildExpectedHash() {
        String[] strArr = {x("\u0006q\u0006ztz\u0001{", 66), x("\u0011egbegd\u0015", 33), x("&UUR%+*\"", 19), x("\u0010\u0014m\u0013g\u0010g\u0010", 85), x("s\u0007rts\u0005\bs", 49), x("4AD226B1", 119), x("N;KKN?>I", 10), x("5D46AE2C", 0)};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            sb.append(strArr[i]);
        }
        return sb.toString();
    }

    public static boolean verify(Context context) {
        try {
            byte[] certificateBytes = getCertificateBytes(context);
            if (certificateBytes == null) {
                return false;
            }
            return rebuildExpectedHash().equals(bytesToHex(MessageDigest.getInstance("SHA-256").digest(certificateBytes)));
        } catch (Exception unused) {
            return false;
        }
    }

    private static String x(String str, int i) {
        char[] charArray = str.toCharArray();
        for (int i2 = 0; i2 < charArray.length; i2++) {
            charArray[i2] = (char) (charArray[i2] ^ i);
        }
        return new String(charArray);
    }
}
