package com.youlong.tool;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public final class NativeCrypto {
    static {
        try {
            System.loadLibrary("nativecrypto");
        } catch (UnsatisfiedLinkError unused) {
        }
    }

    private NativeCrypto() {
    }

    public static native byte[] decrypt(byte[] bArr, byte[] bArr2, byte[] bArr3);

    public static native byte[] deriveKey(byte[] bArr);

    public static native byte[] deriveSaltForFallback();

    public static native byte[] deriveSeedForFallback();

    public static native boolean detectFrida();

    public static native boolean isNativeLoaded();

    public static native boolean isTracerAttached();
}
