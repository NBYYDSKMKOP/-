package com.youlong.tool;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.view.GravityCompat;
import java.security.MessageDigest;
import yl.h3;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class PiracyWarningActivity extends Activity {
    private static final long RECHECK_INTERVAL = 2000;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private boolean mIsFinishing = false;
    private final Runnable mRecheckRunnable = new Runnable() { // from class: com.youlong.tool.PiracyWarningActivity.1
        public AnonymousClass1() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            PiracyWarningActivity piracyWarningActivity = PiracyWarningActivity.this;
            if (piracyWarningActivity.mIsFinishing) {
                return;
            }
            if (piracyWarningActivity.checkSignatureIndependently()) {
                piracyWarningActivity.forceExit();
            } else {
                piracyWarningActivity.mHandler.postDelayed(this, PiracyWarningActivity.RECHECK_INTERVAL);
            }
        }
    };

    /* renamed from: com.youlong.tool.PiracyWarningActivity$1 */
    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class AnonymousClass1 implements Runnable {
        public AnonymousClass1() {
        }

        @Override // java.lang.Runnable
        public final void run() {
            PiracyWarningActivity piracyWarningActivity = PiracyWarningActivity.this;
            if (piracyWarningActivity.mIsFinishing) {
                return;
            }
            if (piracyWarningActivity.checkSignatureIndependently()) {
                piracyWarningActivity.forceExit();
            } else {
                piracyWarningActivity.mHandler.postDelayed(this, PiracyWarningActivity.RECHECK_INTERVAL);
            }
        }
    }

    private static String bytesToHex(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bArr) {
            sb.append(String.format("%02X", Integer.valueOf(b & 255)));
        }
        return sb.toString();
    }

    public boolean checkSignatureIndependently() {
        try {
            byte[] certBytes = getCertBytes();
            if (certBytes == null) {
                return false;
            }
            return rebuildHashInline().equals(bytesToHex(MessageDigest.getInstance("SHA-256").digest(certBytes)));
        } catch (Exception unused) {
            return false;
        }
    }

    public void forceExit() {
        if (this.mIsFinishing) {
            return;
        }
        this.mIsFinishing = true;
        this.mHandler.removeCallbacks(this.mRecheckRunnable);
        finishAffinity();
        Process.killProcess(Process.myPid());
        System.exit(0);
    }

    private byte[] getCertBytes() {
        SigningInfo signingInfo;
        SigningInfo signingInfo2;
        Signature[] signingCertificateHistory;
        if (Build.VERSION.SDK_INT >= 28) {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 134217728);
            signingInfo = packageInfo.signingInfo;
            if (signingInfo != null) {
                signingInfo2 = packageInfo.signingInfo;
                signingCertificateHistory = signingInfo2.getSigningCertificateHistory();
                if (signingCertificateHistory == null || signingCertificateHistory.length == 0) {
                    return null;
                }
                return signingCertificateHistory[0].toByteArray();
            }
            return null;
        }
        Signature[] signatureArr = getPackageManager().getPackageInfo(getPackageName(), 64).signatures;
        if (signatureArr == null || signatureArr.length == 0) {
            return null;
        }
        return signatureArr[0].toByteArray();
    }

    public /* synthetic */ void lambda$onCreate$0(View view) {
        forceExit();
    }

    private static String rebuildHashInline() {
        String[] strArr = {xorStr("\u0006q\u0006ztz\u0001{", 66), xorStr("\u0011egbegd\u0015", 33), xorStr("&UUR%+*\"", 19), xorStr("\u0010\u0014m\u0013g\u0010g\u0010", 85), xorStr("s\u0007rts\u0005\bs", 49), xorStr("4AD226B1", 119), xorStr("N;KKN?>I", 10), xorStr("5D46AE2C", 0)};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            sb.append(strArr[i]);
        }
        return sb.toString();
    }

    private static String xorStr(String str, int i) {
        char[] charArray = str.toCharArray();
        for (int i2 = 0; i2 < charArray.length; i2++) {
            charArray[i2] = (char) (charArray[i2] ^ i);
        }
        return new String(charArray);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(8192);
        requestWindowFeature(1);
        Window window = getWindow();
        window.setFlags(1024, 1024);
        window.addFlags(32);
        window.addFlags(128);
        window.addFlags(524288);
        window.addFlags(2097152);
        window.addFlags(4194304);
        if (Build.VERSION.SDK_INT >= 26) {
            window.setType(2038);
        }
        window.getDecorView().setSystemUiVisibility(4870);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setBackgroundColor(-15064194);
        linearLayout.setPadding(40, 60, 40, 40);
        TextView textView = new TextView(this);
        textView.setText("⚠️");
        textView.setTextSize(68.0f);
        textView.setGravity(17);
        textView.setTextColor(-3722);
        TextView textView2 = new TextView(this);
        textView2.setText("警告：盗版软件");
        textView2.setTextSize(24.0f);
        textView2.setTextColor(-3722);
        textView2.setGravity(17);
        textView2.setPadding(0, 20, 0, 10);
        View view = new View(this);
        view.setBackgroundColor(1157627903);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 1);
        layoutParams.setMargins(20, 10, 20, 10);
        view.setLayoutParams(layoutParams);
        TextView textView3 = new TextView(this);
        textView3.setText("你使用的软件为盗版，请通过官方渠道下载：\n\n官网1：youlong.pages.dev\n官网2：https://iill392.github.io/download-youlong");
        textView3.setTextSize(17.0f);
        textView3.setTextColor(-1);
        textView3.setGravity(17);
        textView3.setPadding(10, 16, 10, 30);
        textView3.setLineSpacing(8.0f, 1.0f);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(GravityCompat.END);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        Button button = new Button(this);
        button.setText("确认退出");
        button.setTextSize(16.0f);
        button.setTextColor(-1);
        button.setBackgroundColor(-2937041);
        button.setPadding(36, 14, 36, 14);
        button.setGravity(17);
        button.setOnClickListener(new h3(this, 1));
        linearLayout2.addView(button);
        linearLayout.addView(textView);
        linearLayout.addView(textView2);
        linearLayout.addView(view);
        linearLayout.addView(textView3);
        linearLayout.addView(linearLayout2);
        scrollView.addView(linearLayout);
        setContentView(scrollView);
        this.mHandler.postDelayed(this.mRecheckRunnable, RECHECK_INTERVAL);
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.mHandler.removeCallbacks(this.mRecheckRunnable);
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        if (!this.mIsFinishing) {
            checkSignatureIndependently();
        }
    }
}
