package com.youlong.tool;

import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import androidx.core.app.NotificationCompat;
import androidx.core.view.PointerIconCompat;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import yl.l0;

/* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
public class DownloadManager {
    public Activity a;
    public NotificationManager b;
    public ExecutorService c;
    public HashMap d;
    public String e;
    public String f;
    public Uri g;
    public String h;

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class BlobDownloadTask implements Runnable {
        public final String c;
        public final String f;
        public final Uri g;

        public BlobDownloadTask(String str, String str2, Uri uri) {
            this.c = str;
            this.f = str2;
            this.g = uri;
        }

        @Override // java.lang.Runnable
        public final void run() {
            byte[] decode;
            OutputStream openOutputStream;
            String str = this.f;
            DownloadManager downloadManager = DownloadManager.this;
            OutputStream outputStream = null;
            try {
                try {
                    try {
                        String str2 = this.c;
                        int indexOf = str2.indexOf(44);
                        if (indexOf >= 0) {
                            str2 = str2.substring(indexOf + 1);
                        }
                        decode = Base64.decode(str2, 0);
                        openOutputStream = downloadManager.a.getContentResolver().openOutputStream(this.g);
                    } catch (Throwable th) {
                        if (0 != 0) {
                            try {
                                outputStream.close();
                            } catch (Exception unused) {
                            }
                        }
                        downloadManager.d.remove(str);
                        throw th;
                    }
                } catch (Exception e) {
                    DownloadManager.b(downloadManager, str, e.getMessage());
                    if (0 != 0) {
                        outputStream.close();
                    }
                }
            } catch (Exception unused2) {
            }
            if (openOutputStream == null) {
                DownloadManager.b(downloadManager, str, "无法创建文件");
                if (openOutputStream != null) {
                    try {
                        openOutputStream.close();
                    } catch (Exception unused3) {
                    }
                }
                downloadManager.d.remove(str);
                return;
            }
            openOutputStream.write(decode);
            openOutputStream.flush();
            DownloadManager.a(downloadManager, str);
            openOutputStream.close();
            downloadManager.d.remove(str);
        }
    }

    /* loaded from: /sandboxdata/workspace/file/reverse_youlong/extracted_root/classes2.dex */
    public class DownloadTask implements Runnable {
        public final String c;
        public final String f;
        public final Uri g;

        public DownloadTask(String str, String str2, Uri uri) {
            this.c = str;
            this.f = str2;
            this.g = uri;
        }

        @Override // java.lang.Runnable
        public final void run() {
            InputStream inputStream;
            HttpURLConnection httpURLConnection;
            InputStream inputStream2;
            int contentLength;
            OutputStream openOutputStream;
            int i;
            String str = this.f;
            DownloadManager downloadManager = DownloadManager.this;
            OutputStream outputStream = null;
            try {
                try {
                    try {
                        httpURLConnection = (HttpURLConnection) new URL(this.c).openConnection();
                    } catch (Exception unused) {
                    }
                } catch (Exception e) {
                    e = e;
                    httpURLConnection = null;
                    inputStream2 = null;
                } catch (Throwable th) {
                    th = th;
                    httpURLConnection = null;
                    inputStream = null;
                }
            } catch (Throwable th2) {
                th = th2;
            }
            try {
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setConnectTimeout(30000);
                httpURLConnection.setReadTimeout(30000);
                httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36");
                httpURLConnection.connect();
                contentLength = httpURLConnection.getContentLength();
                inputStream2 = httpURLConnection.getInputStream();
                try {
                    openOutputStream = downloadManager.a.getContentResolver().openOutputStream(this.g);
                } catch (Exception e2) {
                    e = e2;
                    DownloadManager.b(downloadManager, str, e.getMessage());
                    if (0 != 0) {
                        outputStream.close();
                    }
                    if (inputStream2 != null) {
                        inputStream2.close();
                    }
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    downloadManager.d.remove(str);
                }
            } catch (Exception e3) {
                e = e3;
                inputStream2 = null;
            } catch (Throwable th3) {
                th = th3;
                inputStream = null;
                if (0 != 0) {
                    try {
                        outputStream.close();
                    } catch (Exception unused2) {
                        downloadManager.d.remove(str);
                        throw th;
                    }
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                downloadManager.d.remove(str);
                throw th;
            }
            if (openOutputStream == null) {
                DownloadManager.b(downloadManager, str, "无法创建文件");
                if (openOutputStream != null) {
                    try {
                        openOutputStream.close();
                    } catch (Exception unused3) {
                    }
                }
                if (inputStream2 != null) {
                    inputStream2.close();
                }
                httpURLConnection.disconnect();
                downloadManager.d.remove(str);
                return;
            }
            byte[] bArr = new byte[8192];
            long j = 0;
            int i2 = 0;
            while (true) {
                int read = inputStream2.read(bArr);
                if (read == -1) {
                    break;
                }
                j += read;
                openOutputStream.write(bArr, 0, read);
                if (contentLength > 0 && (i = (int) ((100 * j) / contentLength)) != i2) {
                    DownloadManager.c(downloadManager, str, i);
                    i2 = i;
                }
            }
            openOutputStream.flush();
            DownloadManager.a(downloadManager, str);
            openOutputStream.close();
            inputStream2.close();
            httpURLConnection.disconnect();
            downloadManager.d.remove(str);
        }
    }

    public static void a(DownloadManager downloadManager, String str) {
        downloadManager.getClass();
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(downloadManager.g, "*/*");
        intent.addFlags(1);
        Activity activity = downloadManager.a;
        downloadManager.b.notify(PointerIconCompat.TYPE_HAND, new NotificationCompat.Builder(activity, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("下载完成").setContentText(str + " - 点击打开文件").setPriority(0).setAutoCancel(true).setContentIntent(PendingIntent.getActivity(activity, 0, intent, 201326592)).build());
    }

    public static void b(DownloadManager downloadManager, String str, String str2) {
        String str3;
        NotificationCompat.Builder contentTitle = new NotificationCompat.Builder(downloadManager.a, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("下载失败");
        StringBuilder f = l0.f(str);
        if (str2 != null) {
            str3 = " - ".concat(str2);
        } else {
            str3 = "";
        }
        f.append(str3);
        downloadManager.b.notify(PointerIconCompat.TYPE_HAND, contentTitle.setContentText(f.toString()).setPriority(0).setAutoCancel(true).build());
    }

    public static void c(DownloadManager downloadManager, String str, int i) {
        downloadManager.b.notify(PointerIconCompat.TYPE_HAND, new NotificationCompat.Builder(downloadManager.a, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("正在下载").setContentText(str + " - " + i + "%").setPriority(-1).setOngoing(true).setProgress(100, i, false).build());
    }

    public static String d(String str) {
        int lastIndexOf;
        try {
            String path = new URL(str).getPath();
            if (path != null && !path.isEmpty() && (lastIndexOf = path.lastIndexOf(47)) >= 0 && lastIndexOf < path.length() - 1) {
                String substring = path.substring(lastIndexOf + 1);
                if (!substring.isEmpty()) {
                    if (substring.contains(".")) {
                        return substring;
                    }
                }
            }
        } catch (Exception unused) {
        }
        return "download_" + System.currentTimeMillis() + ".bin";
    }

    public final void e(String str) {
        this.b.notify(PointerIconCompat.TYPE_HAND, new NotificationCompat.Builder(this.a, "download_channel").setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("开始下载").setContentText(str + " - 准备中...").setPriority(-1).setOngoing(true).setProgress(0, 0, true).build());
    }

    public final void f() {
        Intent intent = new Intent("android.intent.action.CREATE_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("*/*");
        intent.putExtra("android.intent.extra.TITLE", this.f);
        intent.addFlags(3);
        this.a.startActivityForResult(intent, 2002);
    }
}
