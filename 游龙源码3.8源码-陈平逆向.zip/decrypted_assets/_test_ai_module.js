
    (function(){
        // ------------------- 配置参数 -------------------
        const BOARD_SIZE = 15;
        let board = Array(BOARD_SIZE).fill().map(() => Array(BOARD_SIZE).fill(0)); // 0空 1玩家(黑) 2AI(白)
        let gameActive = false;
        let currentTurn = 'player';   // 'player' 或 'ai'
        let currentDifficulty = 'normal';
        let isAIPlaying = false;
        
        // DOM 元素
        const canvas = document.getElementById('gobangCanvas');
        const ctx = canvas.getContext('2d');
        const statusDiv = document.getElementById('gameStatusText');
        const overlay = document.getElementById('victoryOverlay');
        const popupMessageSpan = document.getElementById('popupMessageText');
        const announcementOverlay = document.getElementById('announcementOverlay');
        
        // 棋盘绘制参数 (画布实际像素尺寸 540x540)
        const cellSize = canvas.width / BOARD_SIZE;  // 36px
        const radius = cellSize * 0.38;
        let lastMove = null;
        
        // ---------- 辅助函数 ----------
        function clearBoardArray() {
            board = Array(BOARD_SIZE).fill().map(() => Array(BOARD_SIZE).fill(0));
            lastMove = null;
        }
        
        // 绘制棋盘 & 棋子 (优雅渲染)
        function drawBoard() {
            ctx.fillStyle = '#e0b87a';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            // 绘制网格线
            ctx.beginPath();
            ctx.lineWidth = 1.6;
            ctx.strokeStyle = '#4b2f14';
            ctx.shadowBlur = 0;
            for (let i = 0; i < BOARD_SIZE; i++) {
                const pos = i * cellSize;
                ctx.moveTo(cellSize/2, pos + cellSize/2);
                ctx.lineTo(canvas.width - cellSize/2, pos + cellSize/2);
                ctx.stroke();
                ctx.moveTo(pos + cellSize/2, cellSize/2);
                ctx.lineTo(pos + cellSize/2, canvas.height - cellSize/2);
                ctx.stroke();
            }
            // 画星位 (天元/小目)
            const starPoints = [3, 7, 11];
            for (let r of starPoints) {
                for (let c of starPoints) {
                    if ((r===3||r===7||r===11) && (c===3||c===7||c===11)) {
                        ctx.fillStyle = '#d4a259';
                        ctx.beginPath();
                        ctx.arc(cellSize/2 + r*cellSize, cellSize/2 + c*cellSize, cellSize*0.1, 0, 2*Math.PI);
                        ctx.fill();
                        ctx.fillStyle = '#b87c2e';
                        ctx.beginPath();
                        ctx.arc(cellSize/2 + r*cellSize, cellSize/2 + c*cellSize, cellSize*0.06, 0, 2*Math.PI);
                        ctx.fill();
                    }
                }
            }
            // 画所有棋子
            for (let i = 0; i < BOARD_SIZE; i++) {
                for (let j = 0; j < BOARD_SIZE; j++) {
                    const val = board[i][j];
                    if (val === 0) continue;
                    const x = j * cellSize + cellSize/2;
                    const y = i * cellSize + cellSize/2;
                    const gradient = ctx.createRadialGradient(x-4, y-4, 5, x, y, radius);
                    if (val === 1) {
                        gradient.addColorStop(0, '#2b2b2b');
                        gradient.addColorStop(1, '#111111');
                        ctx.fillStyle = gradient;
                    } else {
                        gradient.addColorStop(0, '#f9f9fc');
                        gradient.addColorStop(1, '#cfcfcf');
                        ctx.fillStyle = gradient;
                    }
                    ctx.shadowBlur = 2;
                    ctx.shadowColor = "rgba(0,0,0,0.3)";
                    ctx.beginPath();
                    ctx.arc(x, y, radius-1, 0, 2*Math.PI);
                    ctx.fill();
                    ctx.shadowBlur = 0;
                    ctx.beginPath();
                    ctx.arc(x, y, radius-1, 0, 2*Math.PI);
                    ctx.strokeStyle = '#6b4c2c';
                    ctx.lineWidth = 0.8;
                    ctx.stroke();
                }
            }
            // 高亮最后一步
            if (lastMove) {
                const {x, y} = lastMove;
                const cx = y * cellSize + cellSize/2;
                const cy = x * cellSize + cellSize/2;
                ctx.beginPath();
                ctx.arc(cx, cy, radius+3, 0, 2*Math.PI);
                ctx.strokeStyle = '#ffd966';
                ctx.lineWidth = 2.5;
                ctx.shadowBlur = 5;
                ctx.stroke();
                ctx.beginPath();
                ctx.arc(cx, cy, radius-4, 0, 2*Math.PI);
                ctx.strokeStyle = '#f5bc70';
                ctx.lineWidth = 1.5;
                ctx.stroke();
                ctx.shadowBlur = 0;
            }
        }
        
        // ---------- 胜负判定 ----------
        function checkWin(boardState, row, col, playerVal) {
            const dirs = [[0,1],[1,0],[1,1],[1,-1]];
            for (let [dx, dy] of dirs) {
                let count = 1;
                for (let step = 1; step <= 5; step++) {
                    const nr = row + dx*step, nc = col + dy*step;
                    if (nr<0 || nr>=BOARD_SIZE || nc<0 || nc>=BOARD_SIZE) break;
                    if (boardState[nr][nc] === playerVal) count++;
                    else break;
                }
                for (let step = 1; step <= 5; step++) {
                    const nr = row - dx*step, nc = col - dy*step;
                    if (nr<0 || nr>=BOARD_SIZE || nc<0 || nc>=BOARD_SIZE) break;
                    if (boardState[nr][nc] === playerVal) count++;
                    else break;
                }
                if (count >= 5) return true;
            }
            return false;
        }
        
        function isFullBoard() {
            for(let i=0;i<BOARD_SIZE;i++)
                for(let j=0;j<BOARD_SIZE;j++)
                    if(board[i][j]===0) return false;
            return true;
        }
        
        // 显示弹窗 (淡化页面)
        function showGameOverPopup(winner) {
            if (!gameActive && winner) {
                let msg = '';
                if (winner === 'player') msg = '✨ 你赢了 ✨';
                else if (winner === 'ai') msg = '😭 你输了 小菜鸡 😭';
                else msg = '平局';
                popupMessageSpan.innerText = msg;
                overlay.classList.add('active');
            }
        }
        
        // 结束游戏并触发弹窗
        function endGame(winner) {
            if (!gameActive) return;
            gameActive = false;
            if (winner === 'player') {
                updateStatusText('player');
                showGameOverPopup('player');
                // 记录胜利
                recordWin(currentDifficulty);
            } else if (winner === 'ai') {
                updateStatusText('ai');
                showGameOverPopup('ai');
            } else if (winner === 'draw') {
                updateStatusText('draw');
                popupMessageSpan.innerText = '🤝 平局 🤝';
                overlay.classList.add('active');
            }
        }
        
        // 记录胜利
        function recordWin(difficulty) {
            let wuziqiData = JSON.parse(localStorage.getItem('wuziqiData') || '{}');
            if (!wuziqiData.wins) {
                wuziqiData.wins = {
                    easy: 0,
                    normal: 0,
                    hard: 0
                };
            }
            wuziqiData.wins[difficulty] = (wuziqiData.wins[difficulty] || 0) + 1;
            wuziqiData.lastPlayed = new Date().toISOString();
            localStorage.setItem('wuziqiData', JSON.stringify(wuziqiData));
        }
        
        // 获取游戏记录
        window.getWuziqiRecord = function() {
            return JSON.parse(localStorage.getItem('wuziqiData') || '{}');
        };
        
        function updateStatusText(winner = null) {
            if(!gameActive) {
                if(winner === 'player') statusDiv.innerText = '🏆 玩家胜利！🏆';
                else if(winner === 'ai') statusDiv.innerText = '🤖 AI胜利！🤖';
                else if(winner === 'draw') statusDiv.innerText = '🤝 平局 🤝';
                else statusDiv.innerText = '⚙ 请点击开始游戏';
                return;
            }
            if(currentTurn === 'player') statusDiv.innerText = '⚫ 黑棋 (你) 落子';
            else statusDiv.innerText = '⚪ AI 思考中 ...';
        }
        
        // 落子并检测结局
        function placePiece(row, col, playerType) {
            if(!gameActive) return false;
            if(board[row][col] !== 0) return false;
            const val = (playerType === 'player') ? 1 : 2;
            board[row][col] = val;
            lastMove = {x: row, y: col};
            drawBoard();
            
            if(checkWin(board, row, col, val)) {
                drawBoard();
                endGame(playerType);
                return true;
            }
            if(isFullBoard()) {
                endGame('draw');
                return true;
            }
            return false;
        }
        
        // ---------------- AI 智能评分引擎 (升级版) ----------------
        // 棋型分值表 - 用于所有难度
        const SHAPE_SCORES = {
            WIN5:    10000000,  // 五连（必胜）
            ALIVE4:   1000000,  // 活四  _XXXX_  必胜
            DEAD4:     200000,  // 冲四  XXXX_ / _XXXX 必防
            ALIVE3:     50000,  // 活三  __XXX__ 高威胁
            DEAD3:       5000,  // 眠三  _XXX_*
            ALIVE2:       500,  // 活二  __XX__
            DEAD2:        100,  // 眠二
            ALIVE1:         10
        };
        
        // 获取某方向上的连线信息 (空位处的虚拟评估)
        function getLineType(boardState, row, col, dx, dy, playerVal) {
            let count = 1;
            let leftEmpty = false, rightEmpty = false;
            // 正向扫描
            let step = 1;
            while(true) {
                const nr = row + dx*step, nc = col + dy*step;
                if(nr<0 || nr>=BOARD_SIZE || nc<0 || nc>=BOARD_SIZE) break;
                if(boardState[nr][nc] === playerVal) { count++; step++; }
                else { if(boardState[nr][nc] === 0) rightEmpty = true; break; }
            }
            // 反向扫描
            step = 1;
            while(true) {
                const nr = row - dx*step, nc = col - dy*step;
                if(nr<0 || nr>=BOARD_SIZE || nc<0 || nc>=BOARD_SIZE) break;
                if(boardState[nr][nc] === playerVal) { count++; step++; }
                else { if(boardState[nr][nc] === 0) leftEmpty = true; break; }
            }
            return {count, leftEmpty, rightEmpty};
        }
        
        // 棋型基础分
        function shapeScore(count, leftEmpty, rightEmpty) {
            if(count >= 5) return SHAPE_SCORES.WIN5;
            if(count === 4) {
                if(leftEmpty && rightEmpty) return SHAPE_SCORES.ALIVE4;
                if(leftEmpty || rightEmpty) return SHAPE_SCORES.DEAD4;
                return 0;
            }
            if(count === 3) {
                if(leftEmpty && rightEmpty) return SHAPE_SCORES.ALIVE3;
                if(leftEmpty || rightEmpty) return SHAPE_SCORES.DEAD3;
                return 0;
            }
            if(count === 2) {
                if(leftEmpty && rightEmpty) return SHAPE_SCORES.ALIVE2;
                if(leftEmpty || rightEmpty) return SHAPE_SCORES.DEAD2;
                return 0;
            }
            if(count === 1) {
                if(leftEmpty || rightEmpty) return SHAPE_SCORES.ALIVE1;
            }
            return 0;
        }
        
        // 单点评估 - 考虑组合威胁（双三/双四/四三）
        function evaluatePositionValue(boardState, row, col, playerVal) {
            if(boardState[row][col] !== 0) return 0;
            const dirs = [[0,1],[1,0],[1,1],[1,-1]];
            let total = 0;
            let alive3 = 0, dead4 = 0, alive4 = 0, alive2 = 0;
            for(const [dx, dy] of dirs) {
                const info = getLineType(boardState, row, col, dx, dy, playerVal);
                const s = shapeScore(info.count, info.leftEmpty, info.rightEmpty);
                total += s;
                if(s === SHAPE_SCORES.ALIVE3) alive3++;
                else if(s === SHAPE_SCORES.DEAD4) dead4++;
                else if(s === SHAPE_SCORES.ALIVE4) alive4++;
                else if(s === SHAPE_SCORES.ALIVE2) alive2++;
            }
            // 组合加分
            if(alive4 >= 1) total += SHAPE_SCORES.ALIVE4;          // 已有活四 再成活四无意义 加权保持
            if(dead4 >= 2) total += SHAPE_SCORES.DEAD4;            // 双冲四 -> 必胜
            if(dead4 >= 1 && alive3 >= 1) total += SHAPE_SCORES.DEAD4; // 冲四+活三 -> 必胜
            if(alive3 >= 2) total += SHAPE_SCORES.ALIVE3;          // 双活三 -> 必胜
            if(alive3 >= 1 && alive2 >= 1) total += SHAPE_SCORES.ALIVE2; // 活三+活二 -> 强攻
            return total;
        }
        
        // 全局棋盘评估（用于 minimax 叶子节点）
        function evaluateBoardState(boardState, playerVal) {
            const oppVal = playerVal === 1 ? 2 : 1;
            let myScore = 0, oppScore = 0;
            // 扫描所有空位的影响（缩小权重）
            for(let i=0; i<BOARD_SIZE; i++) {
                for(let j=0; j<BOARD_SIZE; j++) {
                    if(boardState[i][j] === 0) {
                        myScore += evaluatePositionValue(boardState, i, j, playerVal);
                        oppScore += evaluatePositionValue(boardState, i, j, oppVal);
                    }
                }
            }
            // 防守权重略高于进攻（避免漏防）
            return myScore - oppScore * 1.05;
        }
        
        // 旧接口兼容（保留以防其他地方调用）
        function getDirectionInfo(boardState, row, col, dx, dy, playerVal) {
            const r = getLineType(boardState, row, col, dx, dy, playerVal);
            return {count: r.count, leftOpen: r.leftEmpty, rightOpen: r.rightEmpty};
        }
        function evaluatePattern(count, leftOpen, rightOpen) {
            return shapeScore(count, leftOpen, rightOpen);
        }
        function getPositionScore(row, col, playerVal) {
            return evaluatePositionValue(board, row, col, playerVal);
        }
        
        // 获取所有空位
        function getEmptyCells(boardState) {
            const cells = [];
            for(let i=0;i<BOARD_SIZE;i++)
                for(let j=0;j<BOARD_SIZE;j++)
                    if(boardState[i][j] === 0) cells.push([i,j]);
            return cells;
        }
        
        // 候选落子点 - 限制在已有棋子2格内（提升搜索效率）
        function getCandidateMoves(boardState, radius) {
            radius = radius || 2;
            const moves = [];
            const seen = new Set();
            let hasPiece = false;
            for(let i=0; i<BOARD_SIZE; i++) {
                for(let j=0; j<BOARD_SIZE; j++) {
                    if(boardState[i][j] !== 0) {
                        hasPiece = true;
                        for(let di=-radius; di<=radius; di++) {
                            for(let dj=-radius; dj<=radius; dj++) {
                                const r = i+di, c = j+dj;
                                if(r>=0 && r<BOARD_SIZE && c>=0 && c<BOARD_SIZE && boardState[r][c] === 0) {
                                    const key = r*BOARD_SIZE + c;
                                    if(!seen.has(key)) {
                                        seen.add(key);
                                        moves.push({row: r, col: c});
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if(!hasPiece) return [{row: 7, col: 7}];
            return moves;
        }
        
        // 候选点排序：高分在前，便于alpha-beta剪枝
        function orderMoves(boardState, moves, playerVal) {
            const scored = moves.map(m => ({
                row: m.row, col: m.col,
                score: evaluatePositionValue(boardState, m.row, m.col, playerVal)
            }));
            scored.sort((a, b) => b.score - a.score);
            // 仅保留前 N 个高分点，控制搜索宽度
            return scored.slice(0, 12).map(s => ({row: s.row, col: s.col}));
        }
        
        // ============== 简单模式 AI ==============
        function getEasyAIMove() {
            const empty = getEmptyCells(board);
            if(empty.length === 0) return null;
            
            // 1) 必胜机会
            for(const [r, c] of empty) {
                board[r][c] = 2;
                if(checkWin(board, r, c, 2)) { board[r][c] = 0; return {row: r, col: c}; }
                board[r][c] = 0;
            }
            // 2) 必须防守（对方4连）
            for(const [r, c] of empty) {
                board[r][c] = 1;
                if(checkWin(board, r, c, 1)) { board[r][c] = 0; return {row: r, col: c}; }
                board[r][c] = 0;
            }
            // 3) 35% 概率犯错：随机走（让玩家有赢面）
            if(Math.random() < 0.35) {
                return {row: empty[Math.floor(Math.random()*empty.length)][0],
                        col: empty[Math.floor(Math.random()*empty.length)][1]};
            }
            // 4) 简单评估：只考虑4个方向的基础形状（不看组合威胁）
            let best = null, bestScore = -Infinity;
            for(const [r, c] of empty) {
                let s = 0;
                const dirs = [[0,1],[1,0],[1,1],[1,-1]];
                for(const [dx,dy] of dirs) {
                    const info = getLineType(board, r, c, dx, dy, 2);
                    s += shapeScore(info.count, info.leftEmpty, info.rightEmpty);
                    const info2 = getLineType(board, r, c, dx, dy, 1);
                    s += shapeScore(info2.count, info2.leftEmpty, info2.rightEmpty) * 0.8;
                }
                if(s > bestScore) { bestScore = s; best = {row: r, col: c}; }
            }
            // 5) 10% 概率走次优点
            if(Math.random() < 0.1 && best) {
                let alt = null;
                for(const [r,c] of empty) {
                    if(r !== best.row || c !== best.col) { alt = {row: r, col: c}; break; }
                }
                if(alt) best = alt;
            }
            return best;
        }
        
        // ============== 普通模式 AI ==============
        function getNormalAIMove() {
            const empty = getEmptyCells(board);
            if(empty.length === 0) return null;
            // 1) 必胜
            for(const [r, c] of empty) {
                board[r][c] = 2;
                if(checkWin(board, r, c, 2)) { board[r][c] = 0; return {row: r, col: c}; }
                board[r][c] = 0;
            }
            // 2) 必防
            for(const [r, c] of empty) {
                board[r][c] = 1;
                if(checkWin(board, r, c, 1)) { board[r][c] = 0; return {row: r, col: c}; }
                board[r][c] = 0;
            }
            // 3) 完整启发式：组合威胁 + 攻守平衡
            let best = null, bestScore = -Infinity;
            for(const [r, c] of empty) {
                const myScore = evaluatePositionValue(board, r, c, 2);
                const oppScore = evaluatePositionValue(board, r, c, 1);
                // 防守权重高于进攻（避免被双杀）
                const total = myScore * 1.0 + oppScore * 1.15;
                if(total > bestScore) { bestScore = total; best = {row: r, col: c}; }
            }
            return best;
        }
        
        // ============== 困难模式 AI (Minimax + Alpha-Beta) ==============
        const HARD_MAX_DEPTH = 4;        // 搜索深度
        const HARD_TOP_K = 8;            // 每层保留的高分候选点
        let aiThinking = false;          // 思考锁
        
        function alphaBeta(boardState, depth, alpha, beta, isMax) {
            // 终止条件：深度为0 或 胜负已分
            if(depth === 0) {
                return evaluateBoardState(boardState, 2);
            }
            // 胜负快查
            for(let i=0;i<BOARD_SIZE;i++) for(let j=0;j<BOARD_SIZE;j++) {
                if(boardState[i][j] === 2 && checkWin(boardState, i, j, 2)) return 100000000 + depth;
                if(boardState[i][j] === 1 && checkWin(boardState, i, j, 1)) return -100000000 - depth;
            }
            
            const playerVal = isMax ? 2 : 1;
            const moves = orderMoves(boardState, getCandidateMoves(boardState, 2), playerVal);
            if(moves.length === 0) return 0;
            
            if(isMax) {
                let value = -Infinity;
                for(const m of moves) {
                    boardState[m.row][m.col] = 2;
                    const v = alphaBeta(boardState, depth - 1, alpha, beta, false);
                    boardState[m.row][m.col] = 0;
                    if(v > value) value = v;
                    if(value > alpha) alpha = value;
                    if(alpha >= beta) break; // 剪枝
                }
                return value;
            } else {
                let value = Infinity;
                for(const m of moves) {
                    boardState[m.row][m.col] = 1;
                    const v = alphaBeta(boardState, depth - 1, alpha, beta, true);
                    boardState[m.row][m.col] = 0;
                    if(v < value) value = v;
                    if(value < beta) beta = value;
                    if(alpha >= beta) break; // 剪枝
                }
                return value;
            }
        }
        
        function getHardAIMove() {
            // 必胜
            for(let i=0;i<BOARD_SIZE;i++) for(let j=0;j<BOARD_SIZE;j++) {
                if(board[i][j] === 0) {
                    board[i][j] = 2;
                    if(checkWin(board, i, j, 2)) { board[i][j] = 0; return {row: i, col: j}; }
                    board[i][j] = 0;
                }
            }
            // 必防
            for(let i=0;i<BOARD_SIZE;i++) for(let j=0;j<BOARD_SIZE;j++) {
                if(board[i][j] === 0) {
                    board[i][j] = 1;
                    if(checkWin(board, i, j, 1)) { board[i][j] = 0; return {row: i, col: j}; }
                    board[i][j] = 0;
                }
            }
            // Minimax 搜索
            const moves = orderMoves(board, getCandidateMoves(board, 2), 2);
            let best = moves[0];
            let bestVal = -Infinity;
            let alpha = -Infinity, beta = Infinity;
            for(const m of moves) {
                board[m.row][m.col] = 2;
                const v = alphaBeta(board, HARD_MAX_DEPTH - 1, alpha, beta, false);
                board[m.row][m.col] = 0;
                if(v > bestVal) { bestVal = v; best = m; }
                if(bestVal > alpha) alpha = bestVal;
            }
            return best;
        }
        
        // AI 走步
        async function aiMove() {
            if(!gameActive || currentTurn !== 'ai') return;
            if(isAIPlaying) return;
            isAIPlaying = true;
            updateStatusText();
            drawBoard();
            // 给UI一点反应时间
            await new Promise(resolve => setTimeout(resolve, 60));
            
            let move = null;
            try {
                if(currentDifficulty === 'easy') {
                    move = getEasyAIMove();
                } else if(currentDifficulty === 'normal') {
                    move = getNormalAIMove();
                } else if(currentDifficulty === 'hard') {
                    move = getHardAIMove();
                } else {
                    move = getNormalAIMove();
                }
            } catch(err) {
                console.error('AI 出错，使用兜底策略：', err);
                // 兜底：选第一个空位
                const empty = getEmptyCells(board);
                if(empty.length > 0) move = {row: empty[0][0], col: empty[0][1]};
            }
            
            if(!move) {
                if(isFullBoard()) endGame('draw');
                isAIPlaying = false;
                return;
            }
            
            const {row, col} = move;
            const finished = placePiece(row, col, 'ai');
            drawBoard();
            if(finished) {
                isAIPlaying = false;
                return;
            }
            currentTurn = 'player';
            updateStatusText();
            drawBoard();
            isAIPlaying = false;
        }
        
        // 玩家落子
        function playerMove(row, col) {
            if(!gameActive || currentTurn !== 'player') return false;
            if(board[row][col] !== 0) return false;
            const finished = placePiece(row, col, 'player');
            drawBoard();
            if(finished) return true;
            currentTurn = 'ai';
            updateStatusText();
            drawBoard();
            aiMove();
            return true;
        }
        
        // ---------- 重置游戏 ----------
        function resetGame(keepMode = true) {
            if(isAIPlaying) return;
            clearBoardArray();
            gameActive = true;
            currentTurn = 'player';
            lastMove = null;
            drawBoard();
            updateStatusText();
        }
        
        function startNewGame() {
            if(isAIPlaying) return;
            resetGame();
            gameActive = true;
            currentTurn = 'player';
            updateStatusText();
            drawBoard();
        }
        
        // 关闭弹窗并重置游戏 (确保新对局)
        function closePopupAndRestart() {
            overlay.classList.remove('active');
            startNewGame();
        }
        
        // ---------- 画布点击事件(适配移动触摸) ----------
        function handleCanvasClick(e) {
            if(!gameActive) return;
            if(currentTurn !== 'player') return;
            const rect = canvas.getBoundingClientRect();
            const scaleX = canvas.width / rect.width;
            const scaleY = canvas.height / rect.height;
            
            let clientX, clientY;
            if(e.touches) {
                clientX = e.touches[0].clientX;
                clientY = e.touches[0].clientY;
                e.preventDefault();
            } else {
                clientX = e.clientX;
                clientY = e.clientY;
            }
            
            let mouseX = (clientX - rect.left) * scaleX;
            let mouseY = (clientY - rect.top) * scaleY;
            let row = Math.round((mouseY - cellSize/2) / cellSize);
            let col = Math.round((mouseX - cellSize/2) / cellSize);
            if(row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) return;
            if(board[row][col] !== 0) return;
            playerMove(row, col);
        }
        
        // 触摸与鼠标双兼容
        function bindEvents() {
            canvas.addEventListener('click', handleCanvasClick);
            canvas.addEventListener('touchstart', (e) => {
                e.preventDefault();
                const rect = canvas.getBoundingClientRect();
                const touch = e.touches[0];
                const scaleX = canvas.width / rect.width;
                const scaleY = canvas.height / rect.height;
                let mouseX = (touch.clientX - rect.left) * scaleX;
                let mouseY = (touch.clientY - rect.top) * scaleY;
                let row = Math.round((mouseY - cellSize/2) / cellSize);
                let col = Math.round((mouseX - cellSize/2) / cellSize);
                if(row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE && board[row][col] === 0 && gameActive && currentTurn === 'player') {
                    playerMove(row, col);
                }
            });

            document.getElementById('resetBoardBtn').addEventListener('click', () => {
                if(isAIPlaying) return;
                startNewGame();
            });
            document.getElementById('popupRestartBtn').addEventListener('click', closePopupAndRestart);
            // 模式切换时直接重置游戏
            document.querySelectorAll('.mode-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const mode = btn.getAttribute('data-mode');
                    setDifficulty(mode);
                    startNewGame();
                });
            });
        }
        
        function setDifficulty(level) {
            currentDifficulty = level;
            document.querySelectorAll('.mode-btn').forEach(btn => {
                if(btn.getAttribute('data-mode') === level) btn.classList.add('active');
                else btn.classList.remove('active');
            });
        }
        
        // 显示公告弹窗
        window.showAnnouncement = function() {
            announcementOverlay.classList.add('active');
        };
        
        // 关闭公告弹窗
        window.closeAnnouncement = function() {
            announcementOverlay.classList.remove('active');
        };
        
        function init() {
            bindEvents();
            clearBoardArray();
            gameActive = true;
            currentTurn = 'player';
            drawBoard();
            updateStatusText();
            setDifficulty('normal');
            // 确保弹窗初始隐藏
            overlay.classList.remove('active');
            announcementOverlay.classList.remove('active');
            
            // 检查是否第一次进入，显示公告
            checkFirstTime();
        }
        
        // 检查是否第一次进入，显示公告
        function checkFirstTime() {
            const hasSeenAnnouncement = localStorage.getItem('wuziqi_announcement_seen');
            if (!hasSeenAnnouncement) {
                // 第一次进入，显示公告
                showAnnouncement();
                // 记录用户已经看过公告
                localStorage.setItem('wuziqi_announcement_seen', 'true');
            }
        }
})();

// 暴露测试函数
module.exports = { getEasyAIMove, getNormalAIMove, getHardAIMove, evaluatePositionValue, board: () => board, setBoard: (b) => { board = b; }, setDifficulty: (d) => { currentDifficulty = d; } };
