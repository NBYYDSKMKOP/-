MODDIR=${0%/*}
#!/system/bin/sh



ENCODED_SCRIPT="base64填入所需"


echo "$ENCODED_SCRIPT" | base64 -d | sh
